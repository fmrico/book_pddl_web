;; The courier world, third encoding: one action takes the robot
;; to any room it can reach, however far. The problem lists which
;; rooms are reachable from which; the route is not in the plan.
(define (domain courier-goto)
  (:requirements :strips)

  (:predicates
    (robot ?x) (location ?x) (item ?x)
    (reachable ?from ?to)     ; some route leads from ?from to ?to
    (robot-at ?r ?l) (item-at ?i ?l)
    (carrying ?r ?i) (free ?r))

  (:action go
    :parameters (?r ?from ?to)
    :precondition (and (robot ?r) (location ?from) (location ?to)
                       (robot-at ?r ?from) (reachable ?from ?to))
    :effect (and (not (robot-at ?r ?from))
                 (robot-at ?r ?to)))

  (:action pick
    :parameters (?r ?i ?l)
    :precondition (and (robot ?r) (item ?i) (location ?l)
                       (robot-at ?r ?l) (item-at ?i ?l) (free ?r))
    :effect (and (not (item-at ?i ?l)) (not (free ?r))
                 (carrying ?r ?i)))

  (:action drop
    :parameters (?r ?i ?l)
    :precondition (and (robot ?r) (item ?i) (location ?l)
                       (robot-at ?r ?l) (carrying ?r ?i))
    :effect (and (not (carrying ?r ?i))
                 (item-at ?i ?l) (free ?r))))
