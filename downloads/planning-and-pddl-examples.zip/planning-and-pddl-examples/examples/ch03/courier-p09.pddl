;; A dead end on the way: the icu is a trap, so the delivery
;; to the icu must be the last thing the robot does.
(define (problem courier-p09)
  (:domain courier)
  (:objects r1 meds1 sample1
            lobby corridor pharmacy lab ward-a ward-b icu dock)
  (:init
    (robot r1)
    (item meds1) (item sample1)
    (location lobby) (location corridor) (location pharmacy)
    (location lab) (location ward-a) (location ward-b)
    (location icu) (location dock)
    (connected lobby corridor) (connected corridor lobby)
    (connected lobby pharmacy) (connected pharmacy lobby)
    (connected lobby dock) (connected dock lobby)
    (connected corridor lab) (connected lab corridor)
    (connected corridor ward-a) (connected ward-a corridor)
    (connected corridor ward-b) (connected ward-b corridor)
    ; the door of the icu opens only from outside
    (connected ward-b icu)
    (robot-at r1 dock) (free r1)
    (item-at meds1 pharmacy)
    (item-at sample1 lab))
  (:goal (and (item-at meds1 icu)
              (item-at sample1 ward-a))))
