;; The courier world, second encoding: an item stays "at" the room
;; of the robot that carries it, so moving with an item is another
;; action, with the item as a parameter.
(define (domain courier-loaded)
  (:requirements :strips)

  (:predicates
    (robot ?x) (location ?x) (item ?x)
    (connected ?from ?to)
    (robot-at ?r ?l) (item-at ?i ?l)
    (carrying ?r ?i) (free ?r))

  (:action move-empty
    :parameters (?r ?from ?to)
    :precondition (and (robot ?r) (location ?from) (location ?to)
                       (robot-at ?r ?from) (connected ?from ?to)
                       (free ?r))
    :effect (and (not (robot-at ?r ?from))
                 (robot-at ?r ?to)))

  (:action move-with
    :parameters (?r ?i ?from ?to)
    :precondition (and (robot ?r) (item ?i)
                       (location ?from) (location ?to)
                       (robot-at ?r ?from) (connected ?from ?to)
                       (carrying ?r ?i))
    :effect (and (not (robot-at ?r ?from)) (robot-at ?r ?to)
                 (not (item-at ?i ?from)) (item-at ?i ?to)))

  (:action pick
    :parameters (?r ?i ?l)
    :precondition (and (robot ?r) (item ?i) (location ?l)
                       (robot-at ?r ?l) (item-at ?i ?l) (free ?r))
    :effect (and (not (free ?r)) (carrying ?r ?i)))

  (:action drop
    :parameters (?r ?i ?l)
    :precondition (and (robot ?r) (item ?i) (location ?l)
                       (robot-at ?r ?l) (carrying ?r ?i))
    :effect (and (not (carrying ?r ?i)) (free ?r))))
