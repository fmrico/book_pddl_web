;; The tiny problem of chapter 3: three rooms in a row, one robot,
;; one item. Small enough to draw its whole state space.
(define (problem courier-p01)
  (:domain courier)
  (:objects r1 meds1 pharmacy lobby corridor)
  (:init
    (robot r1) (item meds1)
    (location pharmacy) (location lobby) (location corridor)
    (connected pharmacy lobby) (connected lobby pharmacy)
    (connected lobby corridor) (connected corridor lobby)
    (robot-at r1 lobby) (free r1)
    (item-at meds1 pharmacy))
  (:goal (item-at meds1 corridor)))
