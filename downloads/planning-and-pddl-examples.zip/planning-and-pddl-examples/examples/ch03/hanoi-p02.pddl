;; Towers of Hanoi, 3 discs (d1 is the smallest):
;; the whole tower goes from peg1 to peg3.
(define (problem hanoi-p02)
  (:domain hanoi)
  (:objects peg1 peg2 peg3 d1 d2 d3)
  (:init
    (disc d1) (disc d2) (disc d3)
    ; every disc is smaller than the pegs
    (smaller d1 peg1) (smaller d1 peg2) (smaller d1 peg3)
    (smaller d2 peg1) (smaller d2 peg2) (smaller d2 peg3)
    (smaller d3 peg1) (smaller d3 peg2) (smaller d3 peg3)
    ; and than the discs after it
    (smaller d1 d2) (smaller d1 d3)
    (smaller d2 d3)
    ; the tower on peg1
    (on d1 d2) (on d2 d3) (on d3 peg1)
    (clear d1) (clear peg2) (clear peg3))
  (:goal (and
    (on d1 d2) (on d2 d3) (on d3 peg3))))
