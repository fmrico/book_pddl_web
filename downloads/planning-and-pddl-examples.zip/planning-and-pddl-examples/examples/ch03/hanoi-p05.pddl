;; Towers of Hanoi, 8 discs (d1 is the smallest):
;; the whole tower goes from peg1 to peg3.
(define (problem hanoi-p05)
  (:domain hanoi)
  (:objects peg1 peg2 peg3
            d1 d2 d3 d4 d5 d6 d7 d8)
  (:init
    (disc d1) (disc d2) (disc d3) (disc d4) (disc d5) (disc d6)
    (disc d7) (disc d8)
    ; every disc is smaller than the pegs
    (smaller d1 peg1) (smaller d1 peg2) (smaller d1 peg3)
    (smaller d2 peg1) (smaller d2 peg2) (smaller d2 peg3)
    (smaller d3 peg1) (smaller d3 peg2) (smaller d3 peg3)
    (smaller d4 peg1) (smaller d4 peg2) (smaller d4 peg3)
    (smaller d5 peg1) (smaller d5 peg2) (smaller d5 peg3)
    (smaller d6 peg1) (smaller d6 peg2) (smaller d6 peg3)
    (smaller d7 peg1) (smaller d7 peg2) (smaller d7 peg3)
    (smaller d8 peg1) (smaller d8 peg2) (smaller d8 peg3)
    ; and than the discs after it
    (smaller d1 d2) (smaller d1 d3) (smaller d1 d4)
    (smaller d1 d5) (smaller d1 d6) (smaller d1 d7)
    (smaller d1 d8)
    (smaller d2 d3) (smaller d2 d4) (smaller d2 d5)
    (smaller d2 d6) (smaller d2 d7) (smaller d2 d8)
    (smaller d3 d4) (smaller d3 d5) (smaller d3 d6)
    (smaller d3 d7) (smaller d3 d8)
    (smaller d4 d5) (smaller d4 d6) (smaller d4 d7)
    (smaller d4 d8)
    (smaller d5 d6) (smaller d5 d7) (smaller d5 d8)
    (smaller d6 d7) (smaller d6 d8)
    (smaller d7 d8)
    ; the tower on peg1
    (on d1 d2) (on d2 d3) (on d3 d4) (on d4 d5) (on d5 d6)
    (on d6 d7) (on d7 d8) (on d8 peg1)
    (clear d1) (clear peg2) (clear peg3))
  (:goal (and
    (on d1 d2) (on d2 d3) (on d3 d4) (on d4 d5) (on d5 d6)
    (on d6 d7) (on d7 d8) (on d8 peg3))))
