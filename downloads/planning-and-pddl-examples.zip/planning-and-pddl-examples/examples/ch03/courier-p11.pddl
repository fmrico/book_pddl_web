;; Symmetry: one delivery and three robots that nothing
;; tells apart.
(define (problem courier-p11)
  (:domain courier)
  (:objects r1 r2 r3 meds1
            lobby corridor pharmacy lab ward-a ward-b icu dock)
  (:init
    (robot r1) (robot r2) (robot r3)
    (item meds1)
    (location lobby) (location corridor) (location pharmacy)
    (location lab) (location ward-a) (location ward-b)
    (location icu) (location dock)
    (connected lobby corridor) (connected corridor lobby)
    (connected lobby pharmacy) (connected pharmacy lobby)
    (connected lobby dock) (connected dock lobby)
    (connected corridor lab) (connected lab corridor)
    (connected corridor ward-a) (connected ward-a corridor)
    (connected corridor ward-b) (connected ward-b corridor)
    (connected ward-b icu) (connected icu ward-b)
    (robot-at r1 dock) (free r1) (robot-at r2 dock) (free r2)
    (robot-at r3 dock) (free r3)
    (item-at meds1 pharmacy))
  (:goal (item-at meds1 ward-a)))
