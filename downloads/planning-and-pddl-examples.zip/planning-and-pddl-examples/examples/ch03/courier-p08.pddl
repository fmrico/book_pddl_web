;; No plan, but only search shows it: the robot can enter the
;; icu and cannot leave it.
(define (problem courier-p08)
  (:domain courier)
  (:objects r1 sample1
            lobby corridor pharmacy lab ward-a ward-b icu dock)
  (:init
    (robot r1)
    (item sample1)
    (location lobby) (location corridor) (location pharmacy)
    (location lab) (location ward-a) (location ward-b)
    (location icu) (location dock)
    (connected lobby corridor) (connected corridor lobby)
    (connected lobby pharmacy) (connected pharmacy lobby)
    (connected lobby dock) (connected dock lobby)
    (connected corridor lab) (connected lab corridor)
    (connected corridor ward-a) (connected ward-a corridor)
    (connected corridor ward-b) (connected ward-b corridor)
    ; the door of the icu opens only from outside
    (connected ward-b icu)
    (robot-at r1 dock) (free r1)
    (item-at sample1 icu))
  (:goal (item-at sample1 lab)))
