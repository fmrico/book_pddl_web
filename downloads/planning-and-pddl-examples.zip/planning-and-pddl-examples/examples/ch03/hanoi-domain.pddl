;; Towers of Hanoi: discs on three pegs. Only the top disc of a
;; peg moves, and never onto a smaller one.
(define (domain hanoi)
  (:requirements :strips)

  (:predicates
    (disc ?x)             ; ?x is a disc (pegs are not)
    (smaller ?x ?y)       ; ?x may rest on ?y (larger disc or peg)
    (on ?x ?y)            ; disc ?x rests on ?y (a disc or a peg)
    (clear ?x))           ; nothing rests on ?x

  (:action move
    :parameters (?d ?from ?to)
    :precondition (and (disc ?d) (smaller ?d ?to)
                       (on ?d ?from) (clear ?d) (clear ?to))
    :effect (and (not (on ?d ?from)) (not (clear ?to))
                 (on ?d ?to) (clear ?from))))
