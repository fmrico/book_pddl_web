;; Exercise 3.8.3: the robot starts inside the icu, whose door
;; opens only from outside.
(define (problem courier-trapped)
  (:domain courier)
  (:objects r1 meds1
            lobby corridor pharmacy lab ward-a ward-b icu dock)
  (:init
    (robot r1)
    (item meds1)
    (location lobby) (location corridor) (location pharmacy)
    (location lab) (location ward-a) (location ward-b)
    (location icu) (location dock)
    (connected lobby corridor) (connected corridor lobby)
    (connected lobby pharmacy) (connected pharmacy lobby)
    (connected lobby dock) (connected dock lobby)
    (connected corridor lab) (connected lab corridor)
    (connected corridor ward-a) (connected ward-a corridor)
    (connected corridor ward-b) (connected ward-b corridor)
    ; the door of the icu opens only from outside
    (connected ward-b icu)
    (robot-at r1 icu) (free r1)
    (item-at meds1 pharmacy))
  (:goal (item-at meds1 icu)))
