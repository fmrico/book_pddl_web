;; Exercise 3.2.3: gripper. A robot with two grippers carries
;; balls from one room to another.
(define (domain gripper)
  (:requirements :strips)

  (:predicates
    (room ?x) (ball ?x) (gripper ?x)
    (at-robot ?r)           ; the robot is in room ?r
    (at ?b ?r)              ; ball ?b is in room ?r
    (free ?g)               ; gripper ?g holds nothing
    (holding ?g ?b))        ; gripper ?g holds ball ?b

  (:action move
    :parameters (?from ?to)
    :precondition (and (room ?from) (room ?to) (at-robot ?from))
    :effect (and (not (at-robot ?from)) (at-robot ?to)))

  (:action pick
    :parameters (?b ?r ?g)
    :precondition (and (ball ?b) (room ?r) (gripper ?g)
                       (at ?b ?r) (at-robot ?r) (free ?g))
    :effect (and (not (at ?b ?r)) (not (free ?g))
                 (holding ?g ?b)))

  (:action drop
    :parameters (?b ?r ?g)
    :precondition (and (ball ?b) (room ?r) (gripper ?g)
                       (holding ?g ?b) (at-robot ?r))
    :effect (and (not (holding ?g ?b))
                 (at ?b ?r) (free ?g))))
