;; Exercise 3.6.2: a board of our own.
;;   1 3 6
;;   5 . 2
;;   4 7 8
(define (problem puzzle-p04)
  (:domain puzzle)
  (:objects t1 t2 t3 t4 t5 t6 t7 t8
            c11 c12 c13 c21 c22 c23 c31 c32 c33)
  (:init
    (tile t1) (tile t2) (tile t3) (tile t4)
    (tile t5) (tile t6) (tile t7) (tile t8)
    (cell c11) (cell c12) (cell c13)
    (cell c21) (cell c22) (cell c23)
    (cell c31) (cell c32) (cell c33)
    ; cells in the same row
    (adjacent c11 c12) (adjacent c12 c11)
    (adjacent c12 c13) (adjacent c13 c12)
    (adjacent c21 c22) (adjacent c22 c21)
    (adjacent c22 c23) (adjacent c23 c22)
    (adjacent c31 c32) (adjacent c32 c31)
    (adjacent c32 c33) (adjacent c33 c32)
    ; cells in the same column
    (adjacent c11 c21) (adjacent c21 c11)
    (adjacent c21 c31) (adjacent c31 c21)
    (adjacent c12 c22) (adjacent c22 c12)
    (adjacent c22 c32) (adjacent c32 c22)
    (adjacent c13 c23) (adjacent c23 c13)
    (adjacent c23 c33) (adjacent c33 c23)
    ; the board, row by row
    (tile-at t1 c11) (tile-at t3 c12) (tile-at t6 c13)
    (tile-at t5 c21) (empty c22) (tile-at t2 c23)
    (tile-at t4 c31) (tile-at t7 c32) (tile-at t8 c33))
  (:goal (and
    (tile-at t1 c11) (tile-at t2 c12) (tile-at t3 c13)
    (tile-at t4 c21) (tile-at t5 c22) (tile-at t6 c23)
    (tile-at t7 c31) (tile-at t8 c32))))
