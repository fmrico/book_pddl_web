;; The courier world with a mistake made on purpose: move does
;; not ask for a connection, so the robot goes from any room to
;; any other.
(define (domain courier-anywhere)
  (:requirements :strips)

  (:predicates
    (robot ?x) (location ?x) (item ?x)
    (connected ?from ?to)
    (robot-at ?r ?l) (item-at ?i ?l)
    (carrying ?r ?i) (free ?r))

  (:action move                ; (connected ?from ?to) is missing
    :parameters (?r ?from ?to)
    :precondition (and (robot ?r) (location ?from) (location ?to)
                       (robot-at ?r ?from))
    :effect (and (not (robot-at ?r ?from))
                 (robot-at ?r ?to)))

  (:action pick
    :parameters (?r ?i ?l)
    :precondition (and (robot ?r) (item ?i) (location ?l)
                       (robot-at ?r ?l) (item-at ?i ?l) (free ?r))
    :effect (and (not (item-at ?i ?l)) (not (free ?r))
                 (carrying ?r ?i)))

  (:action drop
    :parameters (?r ?i ?l)
    :precondition (and (robot ?r) (item ?i) (location ?l)
                       (robot-at ?r ?l) (carrying ?r ?i))
    :effect (and (not (carrying ?r ?i))
                 (item-at ?i ?l) (free ?r))))
