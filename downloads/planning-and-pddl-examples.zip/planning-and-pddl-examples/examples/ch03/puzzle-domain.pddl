;; The sliding puzzle (8-puzzle): eight tiles on a 3x3 board and
;; one empty cell. A tile next to the empty cell slides into it.
(define (domain puzzle)
  (:requirements :strips)

  (:predicates
    (tile ?x)               ; ?x is a tile
    (cell ?x)               ; ?x is a cell of the board
    (adjacent ?c1 ?c2)      ; the cells share a side
    (tile-at ?t ?c)         ; tile ?t is on cell ?c
    (empty ?c))             ; no tile is on cell ?c

  (:action slide
    :parameters (?t ?from ?to)
    :precondition (and (tile ?t) (cell ?from) (cell ?to)
                       (adjacent ?from ?to)
                       (tile-at ?t ?from) (empty ?to))
    :effect (and (not (tile-at ?t ?from)) (not (empty ?to))
                 (tile-at ?t ?to) (empty ?from))))
