;; A wrong walking robot: both effects of move happen at the
;; end, so the robot is still in ?from while it moves.
(define (domain courier-walk)
  (:requirements :strips :typing :durative-actions)

  (:types robot location)

  (:predicates
    (connected ?from ?to - location)
    (robot-at ?r - robot ?l - location))

  (:durative-action move
    :parameters (?r - robot ?from ?to - location)
    :duration (= ?duration 10)
    :condition (and (at start (robot-at ?r ?from))
                    (at start (connected ?from ?to)))
    :effect (and (at end (not (robot-at ?r ?from)))
                 (at end (robot-at ?r ?to)))))
