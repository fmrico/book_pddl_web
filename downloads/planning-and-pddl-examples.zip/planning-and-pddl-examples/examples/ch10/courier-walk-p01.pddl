;; Walk from the dock to ward A: three moves of 10 seconds.
(define (problem courier-walk-p01)
  (:domain courier-walk)
  (:objects
    r1 - robot
    lobby corridor pharmacy ward-a dock - location)
  (:init
    (connected lobby corridor) (connected corridor lobby)
    (connected lobby pharmacy) (connected pharmacy lobby)
    (connected lobby dock) (connected dock lobby)
    (connected corridor ward-a) (connected ward-a corridor)
    (robot-at r1 dock))
  (:goal (robot-at r1 ward-a)))
