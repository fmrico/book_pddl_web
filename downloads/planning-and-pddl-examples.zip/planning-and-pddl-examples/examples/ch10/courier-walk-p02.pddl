;; The cheat test: be in the pharmacy and in the dock at once.
(define (problem courier-walk-p02)
  (:domain courier-walk)
  (:objects
    r1 - robot
    lobby corridor pharmacy ward-a dock - location)
  (:init
    (connected lobby corridor) (connected corridor lobby)
    (connected lobby pharmacy) (connected pharmacy lobby)
    (connected lobby dock) (connected dock lobby)
    (connected corridor ward-a) (connected ward-a corridor)
    (robot-at r1 lobby))
  (:goal (and (robot-at r1 pharmacy) (robot-at r1 dock))))
