;; A kitchen: a cook prepares dishes, burners cook them alone,
;; and the cook serves them. Times are in minutes.
(define (domain kitchen)
  (:requirements :strips :typing :durative-actions
                 :numeric-fluents)

  (:types cook dish burner)

  (:predicates
    (raw ?d - dish)
    (prepared ?d - dish)
    (cooked ?d - dish)
    (served ?d - dish)
    (available ?c - cook)        ; the cook has nothing in hand
    (burner-free ?b - burner))

  (:functions
    (prep-time ?d - dish)
    (cook-time ?d - dish))

  ;; Washing and chopping keeps the cook busy.
  (:durative-action prepare
    :parameters (?c - cook ?d - dish)
    :duration (= ?duration (prep-time ?d))
    :condition (and (at start (raw ?d))
                    (at start (available ?c)))
    :effect (and (at start (not (raw ?d)))
                 (at start (not (available ?c)))
                 (at end (prepared ?d))
                 (at end (available ?c))))

  ;; The pot is on the burner; nobody has to watch it.
  (:durative-action cook
    :parameters (?d - dish ?b - burner)
    :duration (= ?duration (cook-time ?d))
    :condition (and (at start (prepared ?d))
                    (at start (burner-free ?b)))
    :effect (and (at start (not (prepared ?d)))
                 (at start (not (burner-free ?b)))
                 (at end (cooked ?d))
                 (at end (burner-free ?b))))

  (:durative-action serve
    :parameters (?c - cook ?d - dish)
    :duration (= ?duration 1)
    :condition (and (at start (cooked ?d))
                    (at start (available ?c)))
    :effect (and (at start (not (cooked ?d)))
                 (at start (not (available ?c)))
                 (at end (served ?d))
                 (at end (available ?c)))))
