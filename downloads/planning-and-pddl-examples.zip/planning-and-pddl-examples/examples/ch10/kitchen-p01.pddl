;; Three dishes, one cook and one burner.
(define (problem kitchen-p01)
  (:domain kitchen)
  (:objects
    ana - cook
    soup pasta sauce - dish
    b1 - burner)
  (:init
    (available ana) (burner-free b1)
    (raw soup) (raw pasta) (raw sauce)
    (= (prep-time soup) 6) (= (cook-time soup) 20)
    (= (prep-time pasta) 1) (= (cook-time pasta) 10)
    (= (prep-time sauce) 4) (= (cook-time sauce) 8))
  (:goal (and (served soup) (served pasta) (served sauce)))
  (:metric minimize (total-time)))
