;; Disinfect the pharmacy and take the medicines to the lobby,
;; one thing at a time.
(define (problem courier-idle-p01)
  (:domain courier-idle)
  (:objects
    r1 - robot
    lobby corridor pharmacy lab ward-a ward-b icu dock - location
    meds1 - item)
  (:init
    (connected lobby corridor) (connected corridor lobby)
    (connected lobby pharmacy) (connected pharmacy lobby)
    (connected lobby dock) (connected dock lobby)
    (connected corridor lab) (connected lab corridor)
    (connected corridor ward-a) (connected ward-a corridor)
    (connected corridor ward-b) (connected ward-b corridor)
    (connected ward-b icu) (connected icu ward-b)
    (= (distance lobby corridor) 10)
    (= (distance corridor lobby) 10)
    (= (distance lobby pharmacy) 6)
    (= (distance pharmacy lobby) 6)
    (= (distance lobby dock) 4) (= (distance dock lobby) 4)
    (= (distance corridor lab) 8) (= (distance lab corridor) 8)
    (= (distance corridor ward-a) 12)
    (= (distance ward-a corridor) 12)
    (= (distance corridor ward-b) 12)
    (= (distance ward-b corridor) 12)
    (= (distance ward-b icu) 5) (= (distance icu ward-b) 5)
    (robot-at r1 pharmacy) (free r1) (idle r1)
    (= (speed r1) 1) (= (handling-time r1) 2)
    (item-at meds1 pharmacy))
  (:goal (and (disinfected pharmacy) (item-at meds1 lobby)))
  (:metric minimize (total-time)))
