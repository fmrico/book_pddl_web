;; Wrong on purpose: the conditions of a durative action must
;; say when they hold (at start, over all or at end).
(define (domain courier-walk)
  (:requirements :strips :typing :durative-actions)

  (:types robot location)

  (:predicates
    (connected ?from ?to - location)
    (robot-at ?r - robot ?l - location))

  (:durative-action move
    :parameters (?r - robot ?from ?to - location)
    :duration (= ?duration 10)
    :condition (and (robot-at ?r ?from)
                    (connected ?from ?to))
    :effect (and (at start (not (robot-at ?r ?from)))
                 (at end (robot-at ?r ?to)))))
