;; Wrong on purpose: the effects of a durative action must say
;; when they happen (at start or at end).
(define (domain courier-walk)
  (:requirements :strips :typing :durative-actions)

  (:types robot location)

  (:predicates
    (connected ?from ?to - location)
    (robot-at ?r - robot ?l - location))

  (:durative-action move
    :parameters (?r - robot ?from ?to - location)
    :duration (= ?duration 10)
    :condition (and (at start (robot-at ?r ?from))
                    (at start (connected ?from ?to)))
    :effect (and (not (robot-at ?r ?from))
                 (robot-at ?r ?to))))
