;; Wrong on purpose: a durative action has a :condition, not a
;; :precondition.
(define (domain courier-walk)
  (:requirements :strips :typing :durative-actions)

  (:types robot location)

  (:predicates
    (connected ?from ?to - location)
    (robot-at ?r - robot ?l - location))

  (:durative-action move
    :parameters (?r - robot ?from ?to - location)
    :duration (= ?duration 10)
    :precondition (and (at start (robot-at ?r ?from))
                    (at start (connected ?from ?to)))
    :effect (and (at start (not (robot-at ?r ?from)))
                 (at end (robot-at ?r ?to)))))
