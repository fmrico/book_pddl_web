;; Two lifts, three passengers going down to the ground floor.
(define (problem elevators-p02)
  (:domain elevators)
  (:objects
    e1 e2 - lift
    f0 f1 f2 f3 - floor
    ada bob eve - passenger)
  (:init
    (adjacent f0 f1) (adjacent f1 f0)
    (adjacent f1 f2) (adjacent f2 f1)
    (adjacent f2 f3) (adjacent f3 f2)
    (lift-at e1 f0) (= (floor-time e1) 3)
    (lift-at e2 f3) (= (floor-time e2) 3)
    (passenger-at ada f2) (= (step-time ada) 2)
    (passenger-at bob f2) (= (step-time bob) 4)
    (passenger-at eve f3) (= (step-time eve) 2))
  (:goal (and (passenger-at ada f0) (passenger-at bob f0)
              (passenger-at eve f0)))
  (:metric minimize (total-time)))
