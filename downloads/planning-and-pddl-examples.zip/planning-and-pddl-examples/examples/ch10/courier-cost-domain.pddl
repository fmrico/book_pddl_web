;; The courier without time: instantaneous actions that add the
;; seconds they would take to the cost of the plan.
(define (domain courier-cost)
  (:requirements :strips :typing :numeric-fluents)

  (:types robot location item)

  (:predicates
    (connected ?from ?to - location)
    (robot-at ?r - robot ?l - location)
    (item-at ?i - item ?l - location)
    (carrying ?r - robot ?i - item)
    (free ?r - robot))

  (:functions
    (distance ?from ?to - location)   ; meters
    (speed ?r - robot)                ; meters per second
    (handling-time ?r - robot)        ; seconds to pick or to drop
    (total-cost))                     ; seconds of work

  (:action move
    :parameters (?r - robot ?from ?to - location)
    :precondition (and (robot-at ?r ?from) (connected ?from ?to))
    :effect (and (not (robot-at ?r ?from))
                 (robot-at ?r ?to)
                 (increase (total-cost)
                           (/ (distance ?from ?to) (speed ?r)))))

  (:action pick
    :parameters (?r - robot ?i - item ?l - location)
    :precondition (and (robot-at ?r ?l) (item-at ?i ?l) (free ?r))
    :effect (and (not (item-at ?i ?l)) (not (free ?r))
                 (carrying ?r ?i)
                 (increase (total-cost) (handling-time ?r))))

  (:action drop
    :parameters (?r - robot ?i - item ?l - location)
    :precondition (and (robot-at ?r ?l) (carrying ?r ?i))
    :effect (and (not (carrying ?r ?i))
                 (item-at ?i ?l) (free ?r)
                 (increase (total-cost) (handling-time ?r)))))
