;; The courier world with durative actions of fixed duration:
;; every move lasts 10 seconds, every pick and drop 2 seconds.
(define (domain courier-fixed)
  (:requirements :strips :typing :durative-actions)

  (:types robot location item)

  (:predicates
    (connected ?from ?to - location)
    (robot-at ?r - robot ?l - location)
    (item-at ?i - item ?l - location)
    (carrying ?r - robot ?i - item)
    (free ?r - robot))

  ;; The robot leaves ?from when the move starts
  ;; and is in ?to when it ends.
  (:durative-action move
    :parameters (?r - robot ?from ?to - location)
    :duration (= ?duration 10)
    :condition (and (at start (robot-at ?r ?from))
                    (at start (connected ?from ?to)))
    :effect (and (at start (not (robot-at ?r ?from)))
                 (at end (robot-at ?r ?to))))

  (:durative-action pick
    :parameters (?r - robot ?i - item ?l - location)
    :duration (= ?duration 2)
    :condition (and (at start (robot-at ?r ?l))
                    (at start (item-at ?i ?l))
                    (at start (free ?r)))
    :effect (and (at start (not (item-at ?i ?l)))
                 (at start (not (free ?r)))
                 (at end (carrying ?r ?i))))

  (:durative-action drop
    :parameters (?r - robot ?i - item ?l - location)
    :duration (= ?duration 2)
    :condition (and (at start (robot-at ?r ?l))
                    (at start (carrying ?r ?i)))
    :effect (and (at start (not (carrying ?r ?i)))
                 (at end (item-at ?i ?l))
                 (at end (free ?r)))))
