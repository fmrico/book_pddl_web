;; The timed courier with a fourth action: disinfecting a room
;; with an ultraviolet lamp. The robot can still do two things at
;; once (see courier-idle-domain.pddl for the repair).
(define (domain courier-uv)
  (:requirements :strips :typing :durative-actions
                 :numeric-fluents)

  (:types robot location item)

  (:predicates
    (connected ?from ?to - location)
    (robot-at ?r - robot ?l - location)
    (item-at ?i - item ?l - location)
    (carrying ?r - robot ?i - item)
    (free ?r - robot)
    (disinfected ?l - location))

  (:functions
    (distance ?from ?to - location)   ; meters
    (speed ?r - robot)                ; meters per second
    (handling-time ?r - robot))       ; seconds to pick or to drop

  (:durative-action move
    :parameters (?r - robot ?from ?to - location)
    :duration (= ?duration (/ (distance ?from ?to) (speed ?r)))
    :condition (and (at start (robot-at ?r ?from))
                    (at start (connected ?from ?to)))
    :effect (and (at start (not (robot-at ?r ?from)))
                 (at end (robot-at ?r ?to))))

  (:durative-action pick
    :parameters (?r - robot ?i - item ?l - location)
    :duration (= ?duration (handling-time ?r))
    :condition (and (at start (robot-at ?r ?l))
                    (over all (robot-at ?r ?l))
                    (at start (item-at ?i ?l))
                    (at start (free ?r)))
    :effect (and (at start (not (item-at ?i ?l)))
                 (at start (not (free ?r)))
                 (at end (carrying ?r ?i))))

  (:durative-action drop
    :parameters (?r - robot ?i - item ?l - location)
    :duration (= ?duration (handling-time ?r))
    :condition (and (at start (robot-at ?r ?l))
                    (over all (robot-at ?r ?l))
                    (at start (carrying ?r ?i)))
    :effect (and (at start (not (carrying ?r ?i)))
                 (at end (item-at ?i ?l))
                 (at end (free ?r))))

  ;; The lamp must stay in the room for 20 seconds.
  (:durative-action disinfect
    :parameters (?r - robot ?l - location)
    :duration (= ?duration 20)
    :condition (and (at start (robot-at ?r ?l))
                    (over all (robot-at ?r ?l)))
    :effect (at end (disinfected ?l))))
