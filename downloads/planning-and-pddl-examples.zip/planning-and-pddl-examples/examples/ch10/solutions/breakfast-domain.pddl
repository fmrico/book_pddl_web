;; Breakfast: the toaster and the kettle work alone once started.
;; Times are in seconds.
(define (domain breakfast)
  (:requirements :strips :durative-actions)

  (:predicates
    (bread-in-toaster) (toaster-ready) (toast-done)
    (kettle-full) (kettle-ready) (water-hot))

  (:durative-action toast
    :parameters ()
    :duration (= ?duration 120)
    :condition (and (at start (bread-in-toaster))
                    (at start (toaster-ready)))
    :effect (and (at start (not (toaster-ready)))
                 (at start (not (bread-in-toaster)))
                 (at end (toast-done))
                 (at end (toaster-ready))))

  (:durative-action boil
    :parameters ()
    :duration (= ?duration 180)
    :condition (and (at start (kettle-full))
                    (at start (kettle-ready)))
    :effect (and (at start (not (kettle-ready)))
                 (at end (water-hot))
                 (at end (kettle-ready)))))
