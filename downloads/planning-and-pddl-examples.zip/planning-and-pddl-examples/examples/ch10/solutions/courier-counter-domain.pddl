;; Exercise 10.7.3: a room serves one pick at a time. The token
;; (counter-free ?l) belongs to the room, not to the robot.
(define (domain courier-counter)
  (:requirements :strips :typing :durative-actions
                 :numeric-fluents)

  (:types robot location item)

  (:predicates
    (connected ?from ?to - location)
    (robot-at ?r - robot ?l - location)
    (item-at ?i - item ?l - location)
    (carrying ?r - robot ?i - item)
    (free ?r - robot)
    (idle ?r - robot)
    (counter-free ?l - location)
    (disinfected ?l - location))

  (:functions
    (distance ?from ?to - location)   ; meters
    (speed ?r - robot)                ; meters per second
    (handling-time ?r - robot))       ; seconds to pick or to drop

  (:durative-action move
    :parameters (?r - robot ?from ?to - location)
    :duration (= ?duration (/ (distance ?from ?to) (speed ?r)))
    :condition (and (at start (idle ?r))
                    (at start (robot-at ?r ?from))
                    (at start (connected ?from ?to)))
    :effect (and (at start (not (idle ?r)))
                 (at start (not (robot-at ?r ?from)))
                 (at end (robot-at ?r ?to))
                 (at end (idle ?r))))

  (:durative-action pick
    :parameters (?r - robot ?i - item ?l - location)
    :duration (= ?duration (handling-time ?r))
    :condition (and (at start (idle ?r))
                    (at start (robot-at ?r ?l))
                    (over all (robot-at ?r ?l))
                    (at start (item-at ?i ?l))
                    (at start (free ?r))
                    (at start (counter-free ?l)))
    :effect (and (at start (not (idle ?r)))
                 (at start (not (counter-free ?l)))
                 (at start (not (item-at ?i ?l)))
                 (at start (not (free ?r)))
                 (at end (carrying ?r ?i))
                 (at end (counter-free ?l))
                 (at end (idle ?r))))

  (:durative-action drop
    :parameters (?r - robot ?i - item ?l - location)
    :duration (= ?duration (handling-time ?r))
    :condition (and (at start (idle ?r))
                    (at start (robot-at ?r ?l))
                    (over all (robot-at ?r ?l))
                    (at start (carrying ?r ?i)))
    :effect (and (at start (not (idle ?r)))
                 (at start (not (carrying ?r ?i)))
                 (at end (item-at ?i ?l))
                 (at end (free ?r))
                 (at end (idle ?r))))

  ;; The lamp must stay in the room for 20 seconds.
  (:durative-action disinfect
    :parameters (?r - robot ?l - location)
    :duration (= ?duration 20)
    :condition (and (at start (idle ?r))
                    (at start (robot-at ?r ?l))
                    (over all (robot-at ?r ?l)))
    :effect (and (at start (not (idle ?r)))
                 (at end (disinfected ?l))
                 (at end (idle ?r)))))
