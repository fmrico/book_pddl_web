;; Toast and hot water: the two appliances run at the same time.
(define (problem breakfast-p01)
  (:domain breakfast)
  (:init
    (bread-in-toaster) (toaster-ready)
    (kettle-full) (kettle-ready))
  (:goal (and (toast-done) (water-hot))))
