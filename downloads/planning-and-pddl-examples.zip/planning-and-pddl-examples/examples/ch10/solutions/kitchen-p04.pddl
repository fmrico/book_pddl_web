;; Exercise 10.8.1: three dishes, one cook and three burners.
(define (problem kitchen-p04)
  (:domain kitchen)
  (:objects
    ana - cook
    soup pasta sauce - dish
    b1 b2 b3 - burner)
  (:init
    (available ana) (burner-free b1) (burner-free b2)
    (burner-free b3)
    (raw soup) (raw pasta) (raw sauce)
    (= (prep-time soup) 6) (= (cook-time soup) 20)
    (= (prep-time pasta) 1) (= (cook-time pasta) 10)
    (= (prep-time sauce) 4) (= (cook-time sauce) 8))
  (:goal (and (served soup) (served pasta) (served sauce)))
  (:metric minimize (total-time)))
