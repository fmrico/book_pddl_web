;; Exercise 10.4.2: the lift is asked for only at the start of
;; board and leave, so it does not wait for anybody.
(define (domain elevators)
  (:requirements :strips :typing :durative-actions
                 :numeric-fluents)

  (:types lift passenger floor)

  (:predicates
    (adjacent ?a ?b - floor)
    (lift-at ?e - lift ?f - floor)
    (passenger-at ?p - passenger ?f - floor)
    (boarded ?p - passenger ?e - lift))

  (:functions
    (floor-time ?e - lift)        ; seconds per floor
    (step-time ?p - passenger))   ; seconds to board or to leave

  (:durative-action travel
    :parameters (?e - lift ?from ?to - floor)
    :duration (= ?duration (floor-time ?e))
    :condition (and (at start (lift-at ?e ?from))
                    (at start (adjacent ?from ?to)))
    :effect (and (at start (not (lift-at ?e ?from)))
                 (at end (lift-at ?e ?to))))

  (:durative-action board
    :parameters (?p - passenger ?e - lift ?f - floor)
    :duration (= ?duration (step-time ?p))
    :condition (and (at start (passenger-at ?p ?f))
                    (at start (lift-at ?e ?f)))
    :effect (and (at start (not (passenger-at ?p ?f)))
                 (at end (boarded ?p ?e))))

  (:durative-action leave
    :parameters (?p - passenger ?e - lift ?f - floor)
    :duration (= ?duration (step-time ?p))
    :condition (and (at start (boarded ?p ?e))
                    (at start (lift-at ?e ?f)))
    :effect (and (at start (not (boarded ?p ?e)))
                 (at end (passenger-at ?p ?f)))))
