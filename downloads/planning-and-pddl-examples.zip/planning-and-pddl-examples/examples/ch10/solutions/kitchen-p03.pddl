;; Exercise 10.8.1: three dishes, two cooks and one burner.
(define (problem kitchen-p03)
  (:domain kitchen)
  (:objects
    ana ben - cook
    soup pasta sauce - dish
    b1 - burner)
  (:init
    (available ana) (available ben) (burner-free b1)
    (raw soup) (raw pasta) (raw sauce)
    (= (prep-time soup) 6) (= (cook-time soup) 20)
    (= (prep-time pasta) 1) (= (cook-time pasta) 10)
    (= (prep-time sauce) 4) (= (cook-time sauce) 8))
  (:goal (and (served soup) (served pasta) (served sauce)))
  (:metric minimize (total-time)))
