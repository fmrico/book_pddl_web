;; Two boxes of medicines from the pharmacy to the ICU.
;; The cart is in the pharmacy; nobody says where it must end.
(define (problem courier-cart-p01)
  (:domain courier-cart)
  (:objects
    r1 - robot
    lobby corridor pharmacy lab ward-a ward-b icu dock - location
    meds1 meds2 - item
    cart1 - cart)
  (:init
    (connected lobby corridor) (connected corridor lobby)
    (connected lobby pharmacy) (connected pharmacy lobby)
    (connected lobby dock) (connected dock lobby)
    (connected corridor lab) (connected lab corridor)
    (connected corridor ward-a) (connected ward-a corridor)
    (connected corridor ward-b) (connected ward-b corridor)
    (connected ward-b icu) (connected icu ward-b)
    (robot-at r1 dock) (free r1)
    (cart-at cart1 pharmacy)
    (item-at meds1 pharmacy) (item-at meds2 pharmacy))
  (:goal (and (item-at meds1 icu) (item-at meds2 icu))))
