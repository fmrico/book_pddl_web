;; Six lamps, five of them lit: leave only l2 lit.
;; The master switch saves presses.
(define (problem lights-p02)
  (:domain lights)
  (:objects l1 l2 l3 l4 l5 l6 - lamp)
  (:init (lit l1) (lit l3) (lit l4) (lit l5) (lit l6))
  (:goal (and (lit l2) (not (lit l1)) (not (lit l3))
              (not (lit l4)) (not (lit l5)) (not (lit l6)))))
