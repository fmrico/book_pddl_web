;; The cart without conditional effects: pushing moves the cart
;; only, and bookkeeping actions bring the items along one by one.
(define (domain courier-cart-settle)
  (:requirements :strips :typing :negative-preconditions
                 :disjunctive-preconditions
                 :quantified-preconditions)

  (:types robot location item cart)

  (:predicates
    (connected ?from ?to - location)
    (robot-at ?r - robot ?l - location)
    (item-at ?i - item ?l - location)
    (carrying ?r - robot ?i - item)
    (free ?r - robot)
    (cart-at ?c - cart ?l - location)
    (on-cart ?i - item ?c - cart)
    (pushing ?r - robot ?c - cart)
    ; bookkeeping: the cart went from ?from to ?to and its items
    ; have not all followed yet
    (rolled ?c - cart ?from ?to - location)
    (unsettled))                  ; some cart is in that situation

  (:action move
    :parameters (?r - robot ?from ?to - location)
    :precondition (and (not (unsettled))
                       (robot-at ?r ?from) (connected ?from ?to)
                       (not (exists (?c - cart) (pushing ?r ?c))))
    :effect (and (not (robot-at ?r ?from))
                 (robot-at ?r ?to)))

  (:action pick
    :parameters (?r - robot ?i - item ?l - location)
    :precondition (and (not (unsettled))
                       (robot-at ?r ?l) (item-at ?i ?l) (free ?r)
                       (not (exists (?c - cart) (on-cart ?i ?c))))
    :effect (and (not (item-at ?i ?l)) (not (free ?r))
                 (carrying ?r ?i)))

  ; Without universal effects, taking from a cart names the cart.
  (:action unload
    :parameters (?r - robot ?i - item ?c - cart ?l - location)
    :precondition (and (not (unsettled))
                       (robot-at ?r ?l) (item-at ?i ?l) (free ?r)
                       (on-cart ?i ?c))
    :effect (and (not (item-at ?i ?l)) (not (free ?r))
                 (carrying ?r ?i) (not (on-cart ?i ?c))))

  (:action drop
    :parameters (?r - robot ?i - item ?l - location)
    :precondition (and (not (unsettled))
                       (robot-at ?r ?l) (carrying ?r ?i))
    :effect (and (not (carrying ?r ?i))
                 (item-at ?i ?l) (free ?r)))

  (:action load
    :parameters (?r - robot ?i - item ?c - cart ?l - location)
    :precondition (and (not (unsettled))
                       (robot-at ?r ?l) (cart-at ?c ?l)
                       (carrying ?r ?i))
    :effect (and (not (carrying ?r ?i)) (free ?r)
                 (item-at ?i ?l) (on-cart ?i ?c)))

  (:action grab-cart
    :parameters (?r - robot ?c - cart ?l - location)
    :precondition (and (not (unsettled))
                       (robot-at ?r ?l) (cart-at ?c ?l) (free ?r))
    :effect (and (not (free ?r)) (pushing ?r ?c)))

  (:action release-cart
    :parameters (?r - robot ?c - cart)
    :precondition (and (not (unsettled)) (pushing ?r ?c))
    :effect (and (not (pushing ?r ?c)) (free ?r)))

  ; Step 1: the robot and the cart change room; the items wait.
  (:action push-cart
    :parameters (?r - robot ?c - cart ?from ?to - location)
    :precondition (and (not (unsettled))
                       (pushing ?r ?c) (robot-at ?r ?from)
                       (connected ?from ?to))
    :effect (and (not (robot-at ?r ?from)) (robot-at ?r ?to)
                 (not (cart-at ?c ?from)) (cart-at ?c ?to)
                 (rolled ?c ?from ?to) (unsettled)))

  ; Step 2, once for each item on the cart: it follows the cart.
  (:action bring-along
    :parameters (?i - item ?c - cart ?from ?to - location)
    :precondition (and (rolled ?c ?from ?to) (on-cart ?i ?c)
                       (item-at ?i ?from))
    :effect (and (not (item-at ?i ?from)) (item-at ?i ?to)))

  ; Step 3: when no item is left behind, normal life goes on.
  (:action settle
    :parameters (?c - cart ?from ?to - location)
    :precondition (and (rolled ?c ?from ?to)
                       (forall (?i - item)
                         (imply (on-cart ?i ?c)
                                (item-at ?i ?to))))
    :effect (and (not (rolled ?c ?from ?to))
                 (not (unsettled)))))
