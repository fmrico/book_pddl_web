;; NOT STANDARD: a when inside a when. The grammar of PDDL has
;; no such thing: join the two conditions with and.
(define (domain lights-nested)
  (:requirements :strips :typing :negative-preconditions
                 :conditional-effects)

  (:types lamp)

  (:predicates
    (lit ?l - lamp)
    (broken ?l - lamp))

  (:action toggle
    :parameters (?l - lamp)
    :effect (when (not (broken ?l))
              (and (when (lit ?l) (not (lit ?l)))
                   (when (not (lit ?l)) (lit ?l))))))
