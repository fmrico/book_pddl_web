;; One lit lamp to put out: impossible with the wrong toggle.
(define (problem lights-clash-p01)
  (:domain lights-clash)
  (:objects l1 - lamp)
  (:init (lit l1))
  (:goal (not (lit l1))))
