;; The courier world with a sterile lab: whatever enters a
;; sterile room goes through its disinfection airlock, and a
;; sample that is not sealed is contaminated by it.
(define (domain courier-sterile)
  (:requirements :strips :typing :negative-preconditions
                 :conditional-effects)

  (:types robot location item - object
          medicine sample meal - item)

  (:predicates
    (connected ?from ?to - location)
    (robot-at ?r - robot ?l - location)
    (item-at ?i - item ?l - location)
    (carrying ?r - robot ?i - item)
    (free ?r - robot)
    (sterile ?l - location)       ; static: a room with airlock
    (sealed ?i - sample)          ; the sample is in a sealed bag
    (contaminated ?i - sample))   ; the sample is useless

  ; The move is always possible. What it changes, besides the
  ; position, depends on the room entered and on what is carried.
  (:action move
    :parameters (?r - robot ?from ?to - location)
    :precondition (and (robot-at ?r ?from) (connected ?from ?to))
    :effect (and (not (robot-at ?r ?from))
                 (robot-at ?r ?to)
                 (forall (?i - sample)
                   (when (and (sterile ?to) (carrying ?r ?i)
                              (not (sealed ?i)))
                     (contaminated ?i)))))

  (:action pick
    :parameters (?r - robot ?i - item ?l - location)
    :precondition (and (robot-at ?r ?l) (item-at ?i ?l) (free ?r))
    :effect (and (not (item-at ?i ?l)) (not (free ?r))
                 (carrying ?r ?i)))

  (:action drop
    :parameters (?r - robot ?i - item ?l - location)
    :precondition (and (robot-at ?r ?l) (carrying ?r ?i))
    :effect (and (not (carrying ?r ?i))
                 (item-at ?i ?l) (free ?r)))

  ; Put the carried sample in a sealed bag.
  (:action seal
    :parameters (?r - robot ?i - sample)
    :precondition (and (carrying ?r ?i) (not (sealed ?i)))
    :effect (sealed ?i)))
