;; The cart without conditional effects: one push action for
;; each number of items on the cart, up to three.
(define (domain courier-cart-cases)
  (:requirements :strips :typing :equality
                 :negative-preconditions
                 :disjunctive-preconditions
                 :quantified-preconditions)

  (:types robot location item cart)

  (:predicates
    (connected ?from ?to - location)
    (robot-at ?r - robot ?l - location)
    (item-at ?i - item ?l - location)
    (carrying ?r - robot ?i - item)
    (free ?r - robot)
    (cart-at ?c - cart ?l - location)
    (on-cart ?i - item ?c - cart)     ; ?i lies on the cart
    (pushing ?r - robot ?c - cart))   ; ?r holds the handle

  ; A robot that holds a cart cannot walk away from it.
  (:action move
    :parameters (?r - robot ?from ?to - location)
    :precondition (and (robot-at ?r ?from) (connected ?from ?to)
                       (not (exists (?c - cart) (pushing ?r ?c))))
    :effect (and (not (robot-at ?r ?from))
                 (robot-at ?r ?to)))

  (:action pick
    :parameters (?r - robot ?i - item ?l - location)
    :precondition (and (robot-at ?r ?l) (item-at ?i ?l) (free ?r)
                       (not (exists (?c - cart) (on-cart ?i ?c))))
    :effect (and (not (item-at ?i ?l)) (not (free ?r))
                 (carrying ?r ?i)))

  ; Without universal effects, taking from a cart names the cart.
  (:action unload
    :parameters (?r - robot ?i - item ?c - cart ?l - location)
    :precondition (and (robot-at ?r ?l) (item-at ?i ?l) (free ?r)
                       (on-cart ?i ?c))
    :effect (and (not (item-at ?i ?l)) (not (free ?r))
                 (carrying ?r ?i) (not (on-cart ?i ?c))))

  (:action drop
    :parameters (?r - robot ?i - item ?l - location)
    :precondition (and (robot-at ?r ?l) (carrying ?r ?i))
    :effect (and (not (carrying ?r ?i))
                 (item-at ?i ?l) (free ?r)))

  ; Put the carried item on a cart that is in the same room.
  (:action load
    :parameters (?r - robot ?i - item ?c - cart ?l - location)
    :precondition (and (robot-at ?r ?l) (cart-at ?c ?l)
                       (carrying ?r ?i))
    :effect (and (not (carrying ?r ?i)) (free ?r)
                 (item-at ?i ?l) (on-cart ?i ?c)))

  (:action grab-cart
    :parameters (?r - robot ?c - cart ?l - location)
    :precondition (and (robot-at ?r ?l) (cart-at ?c ?l) (free ?r))
    :effect (and (not (free ?r)) (pushing ?r ?c)))

  (:action release-cart
    :parameters (?r - robot ?c - cart)
    :precondition (pushing ?r ?c)
    :effect (and (not (pushing ?r ?c)) (free ?r)))

  ; Nothing on the cart.
  (:action push-cart-0
    :parameters (?r - robot ?c - cart ?from ?to - location)
    :precondition (and (pushing ?r ?c) (robot-at ?r ?from)
                       (connected ?from ?to)
                       (not (exists (?k - item) (on-cart ?k ?c))))
    :effect (and (not (robot-at ?r ?from)) (robot-at ?r ?to)
                 (not (cart-at ?c ?from)) (cart-at ?c ?to)))

  ; Exactly ?i on the cart.
  (:action push-cart-1
    :parameters (?r - robot ?c - cart ?from ?to - location
                 ?i - item)
    :precondition (and (pushing ?r ?c) (robot-at ?r ?from)
                       (connected ?from ?to)
                       (on-cart ?i ?c)
                       (forall (?k - item)
                         (imply (on-cart ?k ?c) (= ?k ?i))))
    :effect (and (not (robot-at ?r ?from)) (robot-at ?r ?to)
                 (not (cart-at ?c ?from)) (cart-at ?c ?to)
                 (not (item-at ?i ?from)) (item-at ?i ?to)))

  ; Exactly ?i and ?j on the cart.
  (:action push-cart-2
    :parameters (?r - robot ?c - cart ?from ?to - location
                 ?i ?j - item)
    :precondition (and (pushing ?r ?c) (robot-at ?r ?from)
                       (connected ?from ?to)
                       (on-cart ?i ?c) (on-cart ?j ?c)
                       (not (= ?i ?j))
                       (forall (?k - item)
                         (imply (on-cart ?k ?c)
                                (or (= ?k ?i) (= ?k ?j)))))
    :effect (and (not (robot-at ?r ?from)) (robot-at ?r ?to)
                 (not (cart-at ?c ?from)) (cart-at ?c ?to)
                 (not (item-at ?i ?from)) (item-at ?i ?to)
                 (not (item-at ?j ?from)) (item-at ?j ?to)))

  ; Exactly ?i, ?j and ?h on the cart.
  (:action push-cart-3
    :parameters (?r - robot ?c - cart ?from ?to - location
                 ?i ?j ?h - item)
    :precondition (and (pushing ?r ?c) (robot-at ?r ?from)
                       (connected ?from ?to)
                       (on-cart ?i ?c) (on-cart ?j ?c)
                       (on-cart ?h ?c) (not (= ?i ?j))
                       (not (= ?i ?h)) (not (= ?j ?h))
                       (forall (?k - item)
                         (imply (on-cart ?k ?c)
                                (or (= ?k ?i) (= ?k ?j)
                                    (= ?k ?h)))))
    :effect (and (not (robot-at ?r ?from)) (robot-at ?r ?to)
                 (not (cart-at ?c ?from)) (cart-at ?c ?to)
                 (not (item-at ?i ?from)) (item-at ?i ?to)
                 (not (item-at ?j ?from)) (item-at ?j ?to)
                 (not (item-at ?h ?from)) (item-at ?h ?to))))
