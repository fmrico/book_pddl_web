;; Three lamps: leave only l1 lit.
(define (problem lights-p01)
  (:domain lights)
  (:objects l1 l2 l3 - lamp)
  (:init (lit l2))
  (:goal (and (lit l1) (not (lit l2)) (not (lit l3)))))
