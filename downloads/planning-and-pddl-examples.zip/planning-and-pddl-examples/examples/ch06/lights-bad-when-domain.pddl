;; WRONG: a when in a precondition. It belongs to effects only.
(define (domain lights-bad-when)
  (:requirements :strips :typing :negative-preconditions
                 :conditional-effects)

  (:types lamp)

  (:predicates
    (lit ?l - lamp)
    (broken ?l - lamp))

  (:action toggle
    :parameters (?l - lamp)
    :precondition (when (lit ?l) (not (broken ?l)))
    :effect (lit ?l)))
