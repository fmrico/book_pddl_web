;; The sterile lab without conditional effects: one action for
;; each case of entering a room.
(define (domain courier-sterile-cases)
  (:requirements :strips :typing :negative-preconditions
                 :disjunctive-preconditions
                 :universal-preconditions)

  (:types robot location item - object
          medicine sample meal - item)

  (:predicates
    (connected ?from ?to - location)
    (robot-at ?r - robot ?l - location)
    (item-at ?i - item ?l - location)
    (carrying ?r - robot ?i - item)
    (free ?r - robot)
    (sterile ?l - location)
    (sealed ?i - sample)
    (contaminated ?i - sample))

  ; Case 1: the room entered has no airlock.
  (:action move
    :parameters (?r - robot ?from ?to - location)
    :precondition (and (robot-at ?r ?from) (connected ?from ?to)
                       (not (sterile ?to)))
    :effect (and (not (robot-at ?r ?from))
                 (robot-at ?r ?to)))

  ; Case 2: airlock, and no unsealed sample is carried.
  (:action enter-clean
    :parameters (?r - robot ?from ?to - location)
    :precondition (and (robot-at ?r ?from) (connected ?from ?to)
                       (sterile ?to)
                       (forall (?i - sample)
                         (imply (carrying ?r ?i) (sealed ?i))))
    :effect (and (not (robot-at ?r ?from))
                 (robot-at ?r ?to)))

  ; Case 3: airlock, and the unsealed sample ?i is carried.
  (:action enter-exposed
    :parameters (?r - robot ?i - sample ?from ?to - location)
    :precondition (and (robot-at ?r ?from) (connected ?from ?to)
                       (sterile ?to)
                       (carrying ?r ?i) (not (sealed ?i)))
    :effect (and (not (robot-at ?r ?from))
                 (robot-at ?r ?to)
                 (contaminated ?i)))

  (:action pick
    :parameters (?r - robot ?i - item ?l - location)
    :precondition (and (robot-at ?r ?l) (item-at ?i ?l) (free ?r))
    :effect (and (not (item-at ?i ?l)) (not (free ?r))
                 (carrying ?r ?i)))

  (:action drop
    :parameters (?r - robot ?i - item ?l - location)
    :precondition (and (robot-at ?r ?l) (carrying ?r ?i))
    :effect (and (not (carrying ?r ?i))
                 (item-at ?i ?l) (free ?r)))

  (:action seal
    :parameters (?r - robot ?i - sample)
    :precondition (and (carrying ?r ?i) (not (sealed ?i)))
    :effect (sealed ?i)))
