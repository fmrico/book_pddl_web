;; Lights Out: each button changes the lamps wired to it.
;; A universal effect with conditions: every lamp, when wired.
(define (domain lightsout)
  (:requirements :strips :typing :negative-preconditions
                 :universal-preconditions :conditional-effects)

  (:types button lamp)

  (:predicates
    (wired ?b - button ?l - lamp)   ; static: ?b changes ?l
    (lit ?l - lamp))

  (:action press
    :parameters (?b - button)
    :effect (forall (?l - lamp)
              (and (when (and (wired ?b ?l) (lit ?l))
                     (not (lit ?l)))
                   (when (and (wired ?b ?l) (not (lit ?l)))
                     (lit ?l))))))
