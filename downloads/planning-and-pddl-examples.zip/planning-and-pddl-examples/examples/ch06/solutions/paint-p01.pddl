;; Paint the bedroom without staining the bed nor the lamp.
(define (problem paint-p01)
  (:domain paint)
  (:objects bedroom hall - room
            bed lamp - furniture)
  (:init
    (painter-in hall)
    (door hall bedroom) (door bedroom hall)
    (in bed bedroom) (in lamp bedroom))
  (:goal (and (painted bedroom)
              (not (stained bed)) (not (stained lamp)))))
