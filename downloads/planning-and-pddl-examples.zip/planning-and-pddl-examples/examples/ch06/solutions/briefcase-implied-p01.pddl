;; Take the report to the office in the briefcase.
;; The keys are in the briefcase and must stay at home.
(define (problem briefcase-implied-p01)
  (:domain briefcase-implied)
  (:objects home office - place
            report keys - thing)
  (:init
    (case-at home)
    (at report home)
    (in keys))
  (:goal (and (at report office) (at keys home))))
