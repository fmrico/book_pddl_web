;; Solution 6.5.2: the airlock refuses a robot that carries a
;; sample that is not sealed: a precondition, no conditional
;; effect.
(define (domain courier-sterile-refuse)
  (:requirements :strips :typing :negative-preconditions
                 :disjunctive-preconditions
                 :universal-preconditions)

  (:types robot location item - object
          medicine sample meal - item)

  (:predicates
    (connected ?from ?to - location)
    (robot-at ?r - robot ?l - location)
    (item-at ?i - item ?l - location)
    (carrying ?r - robot ?i - item)
    (free ?r - robot)
    (sterile ?l - location)       ; static: a room with airlock
    (sealed ?i - sample)          ; the sample is in a sealed bag
    (contaminated ?i - sample))   ; the sample is useless

  ; The move into a sterile room is not always possible.
  (:action move
    :parameters (?r - robot ?from ?to - location)
    :precondition (and (robot-at ?r ?from) (connected ?from ?to)
                       (forall (?i - sample)
                         (imply (and (sterile ?to)
                                     (carrying ?r ?i))
                                (sealed ?i))))
    :effect (and (not (robot-at ?r ?from))
                 (robot-at ?r ?to)))

  (:action pick
    :parameters (?r - robot ?i - item ?l - location)
    :precondition (and (robot-at ?r ?l) (item-at ?i ?l) (free ?r))
    :effect (and (not (item-at ?i ?l)) (not (free ?r))
                 (carrying ?r ?i)))

  (:action drop
    :parameters (?r - robot ?i - item ?l - location)
    :precondition (and (robot-at ?r ?l) (carrying ?r ?i))
    :effect (and (not (carrying ?r ?i))
                 (item-at ?i ?l) (free ?r)))

  ; Put the carried sample in a sealed bag.
  (:action seal
    :parameters (?r - robot ?i - sample)
    :precondition (and (carrying ?r ?i) (not (sealed ?i)))
    :effect (sealed ?i)))
