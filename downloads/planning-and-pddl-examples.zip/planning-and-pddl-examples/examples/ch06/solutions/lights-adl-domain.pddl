;; Solution 6.6.1: the lamps, with :adl in place of the list.
(define (domain lights-adl)
  (:requirements :adl)

  (:types lamp)

  (:predicates
    (lit ?l - lamp))          ; the lamp is on

  ; One action for both cases: on becomes off, off becomes on.
  (:action toggle
    :parameters (?l - lamp)
    :effect (and (when (lit ?l) (not (lit ?l)))
                 (when (not (lit ?l)) (lit ?l))))

  ; The master switch: every lamp goes off, whatever it was.
  (:action all-off
    :parameters ()
    :effect (forall (?l - lamp) (not (lit ?l)))))
