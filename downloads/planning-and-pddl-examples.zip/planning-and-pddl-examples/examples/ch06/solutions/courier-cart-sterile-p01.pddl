;; Two samples from ward A to the lab on the cart, usable.
(define (problem courier-cart-sterile-p01)
  (:domain courier-cart-sterile)
  (:objects
    r1 - robot
    lobby corridor pharmacy lab ward-a ward-b icu dock - location
    sample1 sample2 - sample
    cart1 - cart)
  (:init
    (connected lobby corridor) (connected corridor lobby)
    (connected lobby pharmacy) (connected pharmacy lobby)
    (connected lobby dock) (connected dock lobby)
    (connected corridor lab) (connected lab corridor)
    (connected corridor ward-a) (connected ward-a corridor)
    (connected corridor ward-b) (connected ward-b corridor)
    (connected ward-b icu) (connected icu ward-b)
    (sterile lab)
    (robot-at r1 ward-a) (free r1)
    (cart-at cart1 ward-a)
    (item-at sample1 ward-a) (item-at sample2 ward-a))
  (:goal (and (item-at sample1 lab) (item-at sample2 lab)
              (not (contaminated sample1))
              (not (contaminated sample2)))))
