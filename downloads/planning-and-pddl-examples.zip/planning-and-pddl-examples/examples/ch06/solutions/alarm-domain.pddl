;; Solution 6.3.1: the fire alarm unlocks and opens every door.
(define (domain alarm)
  (:requirements :strips :typing :negative-preconditions
                 :conditional-effects)

  (:types robot location door)

  (:predicates
    (joins ?d - door ?a ?b - location)
    (open ?d - door)
    (locked ?d - door)
    (robot-at ?r - robot ?l - location)
    (alarm-button ?l - location))   ; static: a button is here

  (:action move
    :parameters (?r - robot ?from ?to - location ?d - door)
    :precondition (and (robot-at ?r ?from) (joins ?d ?from ?to)
                       (open ?d))
    :effect (and (not (robot-at ?r ?from)) (robot-at ?r ?to)))

  (:action open-door
    :parameters (?r - robot ?d - door ?a ?b - location)
    :precondition (and (robot-at ?r ?a) (joins ?d ?a ?b)
                       (not (locked ?d)) (not (open ?d)))
    :effect (open ?d))

  ; One effect for all the doors of the problem, however many.
  (:action raise-alarm
    :parameters (?r - robot ?l - location)
    :precondition (and (robot-at ?r ?l) (alarm-button ?l))
    :effect (forall (?d - door)
              (and (not (locked ?d)) (open ?d)))))
