;; The lab wants the sample open and usable: still no plan.
(define (problem courier-sterile-refuse-p03)
  (:domain courier-sterile-refuse)
  (:objects
    r1 - robot
    lobby corridor pharmacy lab ward-a ward-b icu dock - location
    sample1 - sample)
  (:init
    (connected lobby corridor) (connected corridor lobby)
    (connected lobby pharmacy) (connected pharmacy lobby)
    (connected lobby dock) (connected dock lobby)
    (connected corridor lab) (connected lab corridor)
    (connected corridor ward-a) (connected ward-a corridor)
    (connected corridor ward-b) (connected ward-b corridor)
    (connected ward-b icu) (connected icu ward-b)
    (sterile lab)
    (robot-at r1 dock) (free r1)
    (item-at sample1 ward-a))
  (:goal (and (item-at sample1 lab)
              (not (sealed sample1))
              (not (contaminated sample1)))))
