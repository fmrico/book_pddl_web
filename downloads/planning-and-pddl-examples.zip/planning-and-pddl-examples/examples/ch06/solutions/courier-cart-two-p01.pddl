;; Cheat test with two robots: the cart is wanted in the ICU and
;; in the lab at once. No plan must exist.
(define (problem courier-cart-two-p01)
  (:domain courier-cart-two)
  (:objects
    r1 r2 - robot
    lobby corridor pharmacy lab ward-a ward-b icu dock - location
    cart1 - cart)
  (:init
    (connected lobby corridor) (connected corridor lobby)
    (connected lobby pharmacy) (connected pharmacy lobby)
    (connected lobby dock) (connected dock lobby)
    (connected corridor lab) (connected lab corridor)
    (connected corridor ward-a) (connected ward-a corridor)
    (connected corridor ward-b) (connected ward-b corridor)
    (connected ward-b icu) (connected icu ward-b)
    (robot-at r1 dock) (free r1)
    (robot-at r2 dock) (free r2)
    (cart-at cart1 corridor))
  (:goal (and (cart-at cart1 icu) (cart-at cart1 lab))))
