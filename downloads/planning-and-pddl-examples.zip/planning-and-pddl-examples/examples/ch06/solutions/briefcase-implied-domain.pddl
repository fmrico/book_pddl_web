;; Solution 6.8.2: the briefcase in plain STRIPS. A thing in the
;; briefcase has no place of its own until it is taken out.
(define (domain briefcase-implied)
  (:requirements :strips :typing)

  (:types place thing)

  (:predicates
    (case-at ?p - place)
    (at ?t - thing ?p - place)      ; only for things outside
    (in ?t - thing))

  (:action carry
    :parameters (?from ?to - place)
    :precondition (case-at ?from)
    :effect (and (not (case-at ?from)) (case-at ?to)))

  (:action put-in
    :parameters (?t - thing ?p - place)
    :precondition (and (case-at ?p) (at ?t ?p))
    :effect (and (not (at ?t ?p)) (in ?t)))

  (:action take-out
    :parameters (?t - thing ?p - place)
    :precondition (and (case-at ?p) (in ?t))
    :effect (and (not (in ?t)) (at ?t ?p))))
