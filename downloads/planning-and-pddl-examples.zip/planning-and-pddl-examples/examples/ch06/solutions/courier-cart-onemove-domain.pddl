;; Solution 6.4.2: the cart with a single move action.
(define (domain courier-cart-onemove)
  (:requirements :strips :typing :conditional-effects)

  (:types robot location item cart)

  (:predicates
    (connected ?from ?to - location)
    (robot-at ?r - robot ?l - location)
    (item-at ?i - item ?l - location)
    (carrying ?r - robot ?i - item)
    (free ?r - robot)
    (cart-at ?c - cart ?l - location)
    (on-cart ?i - item ?c - cart)     ; ?i lies on the cart
    (pushing ?r - robot ?c - cart))   ; ?r holds the handle

  ; One action for walking and for pushing: the cart that the
  ; robot holds, if any, comes along, with what is on it.
  (:action move
    :parameters (?r - robot ?from ?to - location)
    :precondition (and (robot-at ?r ?from) (connected ?from ?to))
    :effect (and (not (robot-at ?r ?from))
                 (robot-at ?r ?to)
                 (forall (?c - cart)
                   (when (pushing ?r ?c)
                     (and (not (cart-at ?c ?from))
                          (cart-at ?c ?to))))
                 (forall (?c - cart ?i - item)
                   (when (and (pushing ?r ?c) (on-cart ?i ?c))
                     (and (not (item-at ?i ?from))
                          (item-at ?i ?to))))))

  ; Take an item from the floor or from a cart: whatever cart
  ; it was on, it is on none afterwards.
  (:action pick
    :parameters (?r - robot ?i - item ?l - location)
    :precondition (and (robot-at ?r ?l) (item-at ?i ?l) (free ?r))
    :effect (and (not (item-at ?i ?l)) (not (free ?r))
                 (carrying ?r ?i)
                 (forall (?c - cart) (not (on-cart ?i ?c)))))

  (:action drop
    :parameters (?r - robot ?i - item ?l - location)
    :precondition (and (robot-at ?r ?l) (carrying ?r ?i))
    :effect (and (not (carrying ?r ?i))
                 (item-at ?i ?l) (free ?r)))

  ; Put the carried item on a cart that is in the same room.
  (:action load
    :parameters (?r - robot ?i - item ?c - cart ?l - location)
    :precondition (and (robot-at ?r ?l) (cart-at ?c ?l)
                       (carrying ?r ?i))
    :effect (and (not (carrying ?r ?i)) (free ?r)
                 (item-at ?i ?l) (on-cart ?i ?c)))

  (:action grab-cart
    :parameters (?r - robot ?c - cart ?l - location)
    :precondition (and (robot-at ?r ?l) (cart-at ?c ?l) (free ?r))
    :effect (and (not (free ?r)) (pushing ?r ?c)))

  (:action release-cart
    :parameters (?r - robot ?c - cart)
    :precondition (pushing ?r ?c)
    :effect (and (not (pushing ?r ?c)) (free ?r))))
