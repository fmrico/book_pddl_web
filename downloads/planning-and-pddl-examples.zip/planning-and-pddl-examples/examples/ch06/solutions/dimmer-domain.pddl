;; Solution 6.2.2: a lamp with three levels and one button.
;; off -> low -> high -> off.
(define (domain dimmer)
  (:requirements :strips :typing :negative-preconditions
                 :conditional-effects)

  (:types lamp)

  (:predicates
    (low ?l - lamp)
    (high ?l - lamp))             ; neither: the lamp is off

  (:action press
    :parameters (?l - lamp)
    :effect (and
      (when (and (not (low ?l)) (not (high ?l))) (low ?l))
      (when (low ?l) (and (not (low ?l)) (high ?l)))
      (when (high ?l) (not (high ?l))))))
