;; The robot is in the lobby, the door to the pharmacy is locked.
(define (problem alarm-p01)
  (:domain alarm)
  (:objects r1 - robot
            lobby pharmacy corridor - location
            d1 d2 - door)
  (:init
    (joins d1 lobby pharmacy) (joins d1 pharmacy lobby)
    (joins d2 lobby corridor) (joins d2 corridor lobby)
    (locked d1)
    (alarm-button corridor)
    (robot-at r1 lobby))
  (:goal (robot-at r1 pharmacy)))
