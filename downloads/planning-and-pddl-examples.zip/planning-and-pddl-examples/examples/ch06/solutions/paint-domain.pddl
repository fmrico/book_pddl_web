;; Solution 6.8.1: spray painting a room paints what is in it,
;; unless it is covered.
(define (domain paint)
  (:requirements :strips :typing :negative-preconditions
                 :conditional-effects)

  (:types room furniture)

  (:predicates
    (painter-in ?r - room)
    (door ?a ?b - room)             ; static, both directions
    (in ?f - furniture ?r - room)
    (covered ?f - furniture)
    (painted ?r - room)
    (stained ?f - furniture))

  (:action walk
    :parameters (?from ?to - room)
    :precondition (and (painter-in ?from) (door ?from ?to))
    :effect (and (not (painter-in ?from)) (painter-in ?to)))

  (:action cover
    :parameters (?f - furniture ?r - room)
    :precondition (and (painter-in ?r) (in ?f ?r))
    :effect (covered ?f))

  ; Move a piece of furniture to the next room.
  (:action carry-out
    :parameters (?f - furniture ?from ?to - room)
    :precondition (and (painter-in ?from) (in ?f ?from)
                       (door ?from ?to))
    :effect (and (not (painter-in ?from)) (painter-in ?to)
                 (not (in ?f ?from)) (in ?f ?to)))

  ; Always possible; the stains depend on what is in the room.
  (:action spray
    :parameters (?r - room)
    :precondition (painter-in ?r)
    :effect (and (painted ?r)
                 (forall (?f - furniture)
                   (when (and (in ?f ?r) (not (covered ?f)))
                     (stained ?f))))))
