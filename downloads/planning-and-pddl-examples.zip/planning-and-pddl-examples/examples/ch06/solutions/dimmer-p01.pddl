;; Lamp l1 is low and must be off; l2 is off and must be high.
(define (problem dimmer-p01)
  (:domain dimmer)
  (:objects l1 l2 - lamp)
  (:init (low l1))
  (:goal (and (not (low l1)) (not (high l1)) (high l2))))
