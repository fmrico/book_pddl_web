;; The lamps without conditional effects: one action per case.
(define (domain lights-strips)
  (:requirements :strips :typing :negative-preconditions)

  (:types lamp)

  (:predicates
    (lit ?l - lamp))

  (:action switch-on
    :parameters (?l - lamp)
    :precondition (not (lit ?l))
    :effect (lit ?l))

  (:action switch-off
    :parameters (?l - lamp)
    :precondition (lit ?l)
    :effect (not (lit ?l))))
