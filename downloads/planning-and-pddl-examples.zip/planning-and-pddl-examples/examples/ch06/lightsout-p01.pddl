;; Five lamps in a row; each button changes its lamp and the
;; lamps next to it. Lamps 1, 3 and 4 are lit: put all out.
(define (problem lightsout-p01)
  (:domain lightsout)
  (:objects b1 b2 b3 b4 b5 - button
            l1 l2 l3 l4 l5 - lamp)
  (:init
    (wired b1 l1) (wired b1 l2)
    (wired b2 l1) (wired b2 l2) (wired b2 l3)
    (wired b3 l2) (wired b3 l3) (wired b3 l4)
    (wired b4 l3) (wired b4 l4) (wired b4 l5)
    (wired b5 l4) (wired b5 l5)
    (lit l1) (lit l3) (lit l4))
  (:goal (forall (?l - lamp) (not (lit ?l)))))
