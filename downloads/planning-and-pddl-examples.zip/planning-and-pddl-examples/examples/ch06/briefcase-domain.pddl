;; The briefcase: what is inside moves with it.
(define (domain briefcase)
  (:requirements :strips :typing :negative-preconditions
                 :conditional-effects)

  (:types place thing)

  (:predicates
    (case-at ?p - place)            ; where the briefcase is
    (at ?t - thing ?p - place)      ; where a thing is
    (in ?t - thing))                ; ?t is in the briefcase

  ; Carry the briefcase: every thing in it changes place too.
  (:action carry
    :parameters (?from ?to - place)
    :precondition (case-at ?from)
    :effect (and (not (case-at ?from)) (case-at ?to)
                 (forall (?t - thing)
                   (when (in ?t)
                     (and (not (at ?t ?from)) (at ?t ?to))))))

  (:action put-in
    :parameters (?t - thing ?p - place)
    :precondition (and (case-at ?p) (at ?t ?p)
                       (not (in ?t)))
    :effect (in ?t))

  (:action take-out
    :parameters (?t - thing)
    :precondition (in ?t)
    :effect (not (in ?t))))
