;; Take the report to the office in the briefcase.
;; The keys are in the briefcase and must stay at home.
(define (problem briefcase-p01)
  (:domain briefcase)
  (:objects home office - place
            report keys - thing)
  (:init
    (case-at home)
    (at report home)
    (at keys home) (in keys))
  (:goal (and (at report office) (at keys home))))
