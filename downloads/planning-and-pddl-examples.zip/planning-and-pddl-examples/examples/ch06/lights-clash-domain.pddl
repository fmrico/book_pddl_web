;; WRONG: a toggle whose second case lost its condition. On a
;; lit lamp the action now deletes and adds the same fact.
(define (domain lights-clash)
  (:requirements :strips :typing :negative-preconditions
                 :conditional-effects)

  (:types lamp)

  (:predicates
    (lit ?l - lamp))

  (:action toggle
    :parameters (?l - lamp)
    :effect (and (when (lit ?l) (not (lit ?l)))
                 (lit ?l))))
