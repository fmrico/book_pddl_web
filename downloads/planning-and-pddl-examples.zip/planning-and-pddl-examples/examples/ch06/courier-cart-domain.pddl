;; The courier world with a cart: pushing the cart moves
;; everything that is on it.
(define (domain courier-cart)
  (:requirements :strips :typing :negative-preconditions
                 :existential-preconditions :conditional-effects)

  (:types robot location item cart)

  (:predicates
    (connected ?from ?to - location)
    (robot-at ?r - robot ?l - location)
    (item-at ?i - item ?l - location)
    (carrying ?r - robot ?i - item)
    (free ?r - robot)
    (cart-at ?c - cart ?l - location)
    (on-cart ?i - item ?c - cart)     ; ?i lies on the cart
    (pushing ?r - robot ?c - cart))   ; ?r holds the handle

  ; A robot that holds a cart cannot walk away from it.
  (:action move
    :parameters (?r - robot ?from ?to - location)
    :precondition (and (robot-at ?r ?from) (connected ?from ?to)
                       (not (exists (?c - cart) (pushing ?r ?c))))
    :effect (and (not (robot-at ?r ?from))
                 (robot-at ?r ?to)))

  ; Take an item from the floor or from a cart: whatever cart
  ; it was on, it is on none afterwards.
  (:action pick
    :parameters (?r - robot ?i - item ?l - location)
    :precondition (and (robot-at ?r ?l) (item-at ?i ?l) (free ?r))
    :effect (and (not (item-at ?i ?l)) (not (free ?r))
                 (carrying ?r ?i)
                 (forall (?c - cart) (not (on-cart ?i ?c)))))

  (:action drop
    :parameters (?r - robot ?i - item ?l - location)
    :precondition (and (robot-at ?r ?l) (carrying ?r ?i))
    :effect (and (not (carrying ?r ?i))
                 (item-at ?i ?l) (free ?r)))

  ; Put the carried item on a cart that is in the same room.
  (:action load
    :parameters (?r - robot ?i - item ?c - cart ?l - location)
    :precondition (and (robot-at ?r ?l) (cart-at ?c ?l)
                       (carrying ?r ?i))
    :effect (and (not (carrying ?r ?i)) (free ?r)
                 (item-at ?i ?l) (on-cart ?i ?c)))

  (:action grab-cart
    :parameters (?r - robot ?c - cart ?l - location)
    :precondition (and (robot-at ?r ?l) (cart-at ?c ?l) (free ?r))
    :effect (and (not (free ?r)) (pushing ?r ?c)))

  (:action release-cart
    :parameters (?r - robot ?c - cart)
    :precondition (pushing ?r ?c)
    :effect (and (not (pushing ?r ?c)) (free ?r)))

  ; The robot, the cart and every item on the cart change room.
  (:action push-cart
    :parameters (?r - robot ?c - cart ?from ?to - location)
    :precondition (and (pushing ?r ?c) (robot-at ?r ?from)
                       (connected ?from ?to))
    :effect (and (not (robot-at ?r ?from)) (robot-at ?r ?to)
                 (not (cart-at ?c ?from)) (cart-at ?c ?to)
                 (forall (?i - item)
                   (when (on-cart ?i ?c)
                     (and (not (item-at ?i ?from))
                          (item-at ?i ?to)))))))
