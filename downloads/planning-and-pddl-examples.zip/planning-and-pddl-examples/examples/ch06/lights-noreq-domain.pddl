;; The toggle, with :conditional-effects forgotten in the
;; requirements.
(define (domain lights-noreq)
  (:requirements :strips :typing :negative-preconditions)

  (:types lamp)

  (:predicates
    (lit ?l - lamp))

  (:action toggle
    :parameters (?l - lamp)
    :effect (and (when (lit ?l) (not (lit ?l)))
                 (when (not (lit ?l)) (lit ?l)))))
