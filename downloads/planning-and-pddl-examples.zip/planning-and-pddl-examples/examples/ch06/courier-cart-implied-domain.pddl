;; The cart without updating the items: an item on the cart has
;; no position of its own. It is where the cart is.
(define (domain courier-cart-implied)
  (:requirements :strips :typing :negative-preconditions
                 :existential-preconditions)

  (:types robot location item cart)

  (:predicates
    (connected ?from ?to - location)
    (robot-at ?r - robot ?l - location)
    (item-at ?i - item ?l - location)   ; items on the floor only
    (carrying ?r - robot ?i - item)
    (free ?r - robot)
    (cart-at ?c - cart ?l - location)
    (on-cart ?i - item ?c - cart)
    (pushing ?r - robot ?c - cart))

  (:action move
    :parameters (?r - robot ?from ?to - location)
    :precondition (and (robot-at ?r ?from) (connected ?from ?to)
                       (not (exists (?c - cart) (pushing ?r ?c))))
    :effect (and (not (robot-at ?r ?from))
                 (robot-at ?r ?to)))

  (:action pick
    :parameters (?r - robot ?i - item ?l - location)
    :precondition (and (robot-at ?r ?l) (item-at ?i ?l) (free ?r))
    :effect (and (not (item-at ?i ?l)) (not (free ?r))
                 (carrying ?r ?i)))

  (:action drop
    :parameters (?r - robot ?i - item ?l - location)
    :precondition (and (robot-at ?r ?l) (carrying ?r ?i))
    :effect (and (not (carrying ?r ?i))
                 (item-at ?i ?l) (free ?r)))

  ; On the cart the item loses its own position...
  (:action load
    :parameters (?r - robot ?i - item ?c - cart ?l - location)
    :precondition (and (robot-at ?r ?l) (cart-at ?c ?l)
                       (carrying ?r ?i))
    :effect (and (not (carrying ?r ?i)) (free ?r)
                 (on-cart ?i ?c)))

  ; ...and gets none back until a robot drops it somewhere.
  (:action unload
    :parameters (?r - robot ?i - item ?c - cart ?l - location)
    :precondition (and (robot-at ?r ?l) (cart-at ?c ?l)
                       (on-cart ?i ?c) (free ?r))
    :effect (and (not (on-cart ?i ?c)) (not (free ?r))
                 (carrying ?r ?i)))

  (:action grab-cart
    :parameters (?r - robot ?c - cart ?l - location)
    :precondition (and (robot-at ?r ?l) (cart-at ?c ?l) (free ?r))
    :effect (and (not (free ?r)) (pushing ?r ?c)))

  (:action release-cart
    :parameters (?r - robot ?c - cart)
    :precondition (pushing ?r ?c)
    :effect (and (not (pushing ?r ?c)) (free ?r)))

  ; Plain STRIPS: only the robot and the cart change room.
  (:action push-cart
    :parameters (?r - robot ?c - cart ?from ?to - location)
    :precondition (and (pushing ?r ?c) (robot-at ?r ?from)
                       (connected ?from ?to))
    :effect (and (not (robot-at ?r ?from)) (robot-at ?r ?to)
                 (not (cart-at ?c ?from)) (cart-at ?c ?to))))
