;; Open the treasure chest. You start with the iron key.
(define (problem chests-p01)
  (:domain chests)
  (:objects
    oak pine cedar treasure - chest
    iron brass silver gold - key)
  (:init
    (have iron)
    (fits iron oak) (fits iron pine)
    (inside brass oak) (inside silver pine)
    (fits brass cedar) (fits silver pine)
    (inside gold cedar)
    (fits gold treasure))
  (:goal (opened treasure)))
