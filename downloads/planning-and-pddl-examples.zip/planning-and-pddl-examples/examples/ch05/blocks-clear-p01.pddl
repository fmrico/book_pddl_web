;; The same towers for the classic domain: the initial state
;; must also say which blocks are clear.
(define (problem blocks-clear-p01)
  (:domain blocks-clear)
  (:objects a b c d - block)
  (:init
    (on c a) (on-table a) (on-table b) (on-table d)
    (clear c) (clear b) (clear d)
    (hand-empty))
  (:goal (and (on a b) (on b c))))
