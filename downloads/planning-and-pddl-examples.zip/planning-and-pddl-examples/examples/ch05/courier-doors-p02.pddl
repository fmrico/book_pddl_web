;; The same delivery, and the pharmacy door must end closed:
;; a negative goal.
(define (problem courier-doors-p02)
  (:domain courier-doors)
  (:objects
    r1 - robot
    lobby corridor pharmacy lab ward-a ward-b icu dock - location
    door-pharmacy door-lab door-icu - door
    meds1 - medicine)
  (:init
    ; passages without a door
    (connected lobby corridor) (connected corridor lobby)
    (connected lobby dock) (connected dock lobby)
    (connected corridor ward-a) (connected ward-a corridor)
    (connected corridor ward-b) (connected ward-b corridor)
    ; passages with a door
    (joins door-pharmacy lobby pharmacy)
    (joins door-pharmacy pharmacy lobby)
    (joins door-lab corridor lab) (joins door-lab lab corridor)
    (joins door-icu ward-b icu) (joins door-icu icu ward-b)
    ; every door starts closed: no (open ...) fact
    (robot-at r1 dock) (free r1)
    (item-at meds1 pharmacy))
  (:goal (and (item-at meds1 ward-a)
              (not (open door-pharmacy)))))
