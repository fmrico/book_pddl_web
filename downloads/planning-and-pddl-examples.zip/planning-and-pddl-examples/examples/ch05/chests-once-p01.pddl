;; The same chests with single-use keys: opening the pine chest
;; first wastes the iron key.
(define (problem chests-once-p01)
  (:domain chests-once)
  (:objects
    oak pine cedar treasure - chest
    iron brass silver gold - key)
  (:init
    (have iron)
    (fits iron oak) (fits iron pine)
    (inside brass oak) (inside silver pine)
    (fits brass cedar) (fits silver pine)
    (inside gold cedar)
    (fits gold treasure))
  (:goal (opened treasure)))
