;; The doors without negative preconditions: three predicates,
;; open, closed and locked, and every action keeps exactly one
;; of them true for each door.
(define (domain courier-closed)
  (:requirements :strips :typing)

  (:types
    robot location door
    medicine sample meal - item)

  (:predicates
    (connected ?from ?to - location)    ; a passage with no door
    (joins ?d - door ?a ?b - location)  ; ?d leads from ?a to ?b
    (open ?d - door)
    (closed ?d - door)                  ; closed and not locked
    (locked ?d - door)
    (robot-at ?r - robot ?l - location)
    (item-at ?i - item ?l - location)
    (carrying ?r - robot ?i - item)
    (free ?r - robot)
    (has-keycard ?r - robot))

  (:action move
    :parameters (?r - robot ?from ?to - location)
    :precondition (and (robot-at ?r ?from) (connected ?from ?to))
    :effect (and (not (robot-at ?r ?from))
                 (robot-at ?r ?to)))

  (:action move-through
    :parameters (?r - robot ?d - door ?from ?to - location)
    :precondition (and (robot-at ?r ?from) (joins ?d ?from ?to)
                       (open ?d))
    :effect (and (not (robot-at ?r ?from))
                 (robot-at ?r ?to)))

  (:action open-door
    :parameters (?r - robot ?d - door ?a ?b - location)
    :precondition (and (robot-at ?r ?a) (joins ?d ?a ?b)
                       (closed ?d))
    :effect (and (not (closed ?d)) (open ?d)))

  (:action close-door
    :parameters (?r - robot ?d - door ?a ?b - location)
    :precondition (and (robot-at ?r ?a) (joins ?d ?a ?b)
                       (open ?d))
    :effect (and (not (open ?d)) (closed ?d)))

  (:action unlock
    :parameters (?r - robot ?d - door ?a ?b - location)
    :precondition (and (robot-at ?r ?a) (joins ?d ?a ?b)
                       (locked ?d) (has-keycard ?r))
    :effect (and (not (locked ?d)) (closed ?d)))

  (:action pick
    :parameters (?r - robot ?i - item ?l - location)
    :precondition (and (robot-at ?r ?l) (item-at ?i ?l) (free ?r))
    :effect (and (not (item-at ?i ?l)) (not (free ?r))
                 (carrying ?r ?i)))

  (:action drop
    :parameters (?r - robot ?i - item ?l - location)
    :precondition (and (robot-at ?r ?l) (carrying ?r ?i))
    :effect (and (not (carrying ?r ?i))
                 (item-at ?i ?l) (free ?r))))
