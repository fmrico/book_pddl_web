;; A puzzle of keys and chests: a chest opens if you have SOME
;; key that fits it. Chests hold more keys.
(define (domain chests)
  (:requirements :strips :typing :negative-preconditions
                 :existential-preconditions)

  (:types chest key)

  (:predicates
    (have ?k - key)
    (inside ?k - key ?c - chest)
    (fits ?k - key ?c - chest)
    (opened ?c - chest))

  (:action open
    :parameters (?c - chest)
    :precondition (and (not (opened ?c))
                       (exists (?k - key)
                         (and (have ?k) (fits ?k ?c))))
    :effect (opened ?c))

  (:action take
    :parameters (?k - key ?c - chest)
    :precondition (and (opened ?c) (inside ?k ?c))
    :effect (and (not (inside ?k ?c)) (have ?k))))
