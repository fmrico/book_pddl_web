;; "No item left in the corridor": the cheat test of a goal
;; about absence.
(define (problem courier-ward-p02)
  (:domain courier-ward)
  (:objects
    r1 - robot
    lobby corridor pharmacy lab ward-a ward-b icu dock - location
    door-pharmacy door-lab door-icu - door
    meal1 - meal)
  (:init
    (connected lobby corridor) (connected corridor lobby)
    (connected lobby pharmacy) (connected pharmacy lobby)
    (connected lobby dock) (connected dock lobby)
    (connected corridor lab) (connected lab corridor)
    (connected corridor ward-a) (connected ward-a corridor)
    (connected corridor ward-b) (connected ward-b corridor)
    (connected ward-b icu) (connected icu ward-b)
    (joins door-pharmacy lobby pharmacy)
    (joins door-pharmacy pharmacy lobby)
    (joins door-lab corridor lab) (joins door-lab lab corridor)
    (joins door-icu ward-b icu) (joins door-icu icu ward-b)
    (robot-at r1 corridor) (free r1)
    (item-at meal1 corridor))
  (:goal (forall (?i - item) (not (item-at ?i corridor)))))
