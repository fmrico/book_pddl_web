;; Two robots: deliver, come back to the dock and close.
(define (problem courier-night-p01)
  (:domain courier-night)
  (:objects
    r1 r2 - robot
    lobby corridor pharmacy lab ward-a ward-b icu - location
    door-pharmacy door-lab door-icu - door
    meds1 - medicine)
  (:init
    (connected lobby corridor) (connected corridor lobby)
    (connected lobby pharmacy) (connected pharmacy lobby)
    (connected lobby dock) (connected dock lobby)
    (connected corridor lab) (connected lab corridor)
    (connected corridor ward-a) (connected ward-a corridor)
    (connected corridor ward-b) (connected ward-b corridor)
    (connected ward-b icu) (connected icu ward-b)
    (joins door-pharmacy lobby pharmacy)
    (joins door-pharmacy pharmacy lobby)
    (joins door-lab corridor lab) (joins door-lab lab corridor)
    (joins door-icu ward-b icu) (joins door-icu icu ward-b)
    (open door-lab)
    (robot-at r1 dock) (free r1)
    (robot-at r2 lab) (free r2)
    (item-at meds1 pharmacy))
  (:goal (and (item-at meds1 ward-a) (floor-closed))))
