;; Exercise 5.5.3: take every tower apart.
(define (problem blocks-p02)
  (:domain blocks)
  (:objects a b c d - block)
  (:init
    (on a b) (on b c) (on-table c) (on-table d)
    (hand-empty))
  (:goal (forall (?x - block) (on-table ?x))))
