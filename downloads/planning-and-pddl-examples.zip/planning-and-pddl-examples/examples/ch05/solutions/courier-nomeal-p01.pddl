;; Medicines to the ICU and a meal to ward B: fine.
(define (problem courier-nomeal-p01)
  (:domain courier-nomeal)
  (:objects
    r1 - robot
    lobby corridor pharmacy lab ward-a ward-b icu dock - location
    meds1 - medicine
    meal1 - meal)
  (:init
    (connected lobby corridor) (connected corridor lobby)
    (connected lobby pharmacy) (connected pharmacy lobby)
    (connected lobby dock) (connected dock lobby)
    (connected corridor lab) (connected lab corridor)
    (connected corridor ward-a) (connected ward-a corridor)
    (connected corridor ward-b) (connected ward-b corridor)
    (connected ward-b icu) (connected icu ward-b)
    (restricted icu) (restricted lab)
    (robot-at r1 lobby) (free r1) (has-keycard r1)
    (item-at meds1 pharmacy) (item-at meal1 lobby))
  (:goal (and (item-at meds1 icu) (item-at meal1 ward-b))))
