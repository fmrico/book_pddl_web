;; Exercise 5.1.2: doors that need a free gripper to be opened
;; or closed.
(define (domain courier-doors)
  (:requirements :strips :typing :negative-preconditions)

  (:types
    robot location door
    medicine sample meal - item)

  (:predicates
    (connected ?from ?to - location)    ; a passage with no door
    (joins ?d - door ?a ?b - location)  ; ?d leads from ?a to ?b
    (open ?d - door)
    (locked ?d - door)
    (robot-at ?r - robot ?l - location)
    (item-at ?i - item ?l - location)
    (carrying ?r - robot ?i - item)
    (free ?r - robot)
    (has-keycard ?r - robot))

  (:action move
    :parameters (?r - robot ?from ?to - location)
    :precondition (and (robot-at ?r ?from) (connected ?from ?to))
    :effect (and (not (robot-at ?r ?from))
                 (robot-at ?r ?to)))

  ;; Through a door: only if it is open.
  (:action move-through
    :parameters (?r - robot ?d - door ?from ?to - location)
    :precondition (and (robot-at ?r ?from) (joins ?d ?from ?to)
                       (open ?d))
    :effect (and (not (robot-at ?r ?from))
                 (robot-at ?r ?to)))

  ;; A closed door: one that is not open and not locked.
  (:action open-door
    :parameters (?r - robot ?d - door ?a ?b - location)
    :precondition (and (robot-at ?r ?a) (joins ?d ?a ?b)
                       (free ?r)
                       (not (open ?d)) (not (locked ?d)))
    :effect (open ?d))

  (:action close-door
    :parameters (?r - robot ?d - door ?a ?b - location)
    :precondition (and (robot-at ?r ?a) (joins ?d ?a ?b)
                       (free ?r) (open ?d))
    :effect (not (open ?d)))

  (:action unlock
    :parameters (?r - robot ?d - door ?a ?b - location)
    :precondition (and (robot-at ?r ?a) (joins ?d ?a ?b)
                       (locked ?d) (has-keycard ?r))
    :effect (not (locked ?d)))

  (:action pick
    :parameters (?r - robot ?i - item ?l - location)
    :precondition (and (robot-at ?r ?l) (item-at ?i ?l) (free ?r))
    :effect (and (not (item-at ?i ?l)) (not (free ?r))
                 (carrying ?r ?i)))

  (:action drop
    :parameters (?r - robot ?i - item ?l - location)
    :precondition (and (robot-at ?r ?l) (carrying ?r ?i))
    :effect (and (not (carrying ?r ?i))
                 (item-at ?i ?l) (free ?r))))
