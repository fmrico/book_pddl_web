;; Exercise 5.5.1: the floor is closed for the night when every
;; robot is in the dock and every door is closed.
(define (domain courier-night)
  (:requirements :strips :typing :negative-preconditions
                 :disjunctive-preconditions
                 :universal-preconditions)

  (:types
    robot location door
    medicine sample meal - item)

  (:constants dock - location)

  (:predicates
    (connected ?from ?to - location)    ; any passage
    (joins ?d - door ?a ?b - location)  ; ?d is on that passage
    (open ?d - door)
    (robot-at ?r - robot ?l - location)
    (item-at ?i - item ?l - location)
    (carrying ?r - robot ?i - item)
    (free ?r - robot)
    (floor-closed))

  (:action move
    :parameters (?r - robot ?from ?to - location)
    :precondition
      (and (robot-at ?r ?from) (connected ?from ?to)
           (not (floor-closed))      ; nobody moves at night
           (forall (?d - door)
             (imply (joins ?d ?from ?to) (open ?d))))
    :effect (and (not (robot-at ?r ?from))
                 (robot-at ?r ?to)))

  (:action open-door
    :parameters (?r - robot ?d - door ?a ?b - location)
    :precondition (and (robot-at ?r ?a) (joins ?d ?a ?b)
                       (not (open ?d)))
    :effect (open ?d))

  (:action close-door
    :parameters (?r - robot ?d - door ?a ?b - location)
    :precondition (and (robot-at ?r ?a) (joins ?d ?a ?b)
                       (open ?d))
    :effect (not (open ?d)))

  (:action close-floor
    :parameters ()
    :precondition
      (and (forall (?r - robot) (robot-at ?r dock))
           (forall (?d - door) (not (open ?d))))
    :effect (floor-closed))

  (:action pick
    :parameters (?r - robot ?i - item ?l - location)
    :precondition (and (robot-at ?r ?l) (item-at ?i ?l) (free ?r))
    :effect (and (not (item-at ?i ?l)) (not (free ?r))
                 (carrying ?r ?i)))

  (:action drop
    :parameters (?r - robot ?i - item ?l - location)
    :precondition (and (robot-at ?r ?l) (carrying ?r ?i))
    :effect (and (not (carrying ?r ?i))
                 (item-at ?i ?l) (free ?r))))
