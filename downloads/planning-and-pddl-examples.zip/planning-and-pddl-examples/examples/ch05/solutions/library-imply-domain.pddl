;; Exercise 5.3.1: the library with players (solution 4.4.2),
;; with ONE borrow action and an implication.
(define (domain library-imply)
  (:requirements :strips :typing :disjunctive-preconditions)

  (:types
    member
    book dvd audiobook - loanable)

  (:predicates
    (on-shelf ?x - loanable)
    (borrowed ?x - loanable ?m - member)
    (can-borrow ?m - member)
    (needs-player ?x - loanable)
    (has-player ?m - member))

  (:action borrow
    :parameters (?m - member ?x - loanable)
    :precondition (and (on-shelf ?x) (can-borrow ?m)
                       (imply (needs-player ?x)
                              (has-player ?m)))
    :effect (and (not (on-shelf ?x)) (not (can-borrow ?m))
                 (borrowed ?x ?m)))

  (:action give-back
    :parameters (?m - member ?x - loanable)
    :precondition (borrowed ?x ?m)
    :effect (and (not (borrowed ?x ?m))
                 (on-shelf ?x) (can-borrow ?m)))

  (:action buy-player
    :parameters (?m - member)
    :effect (has-player ?m)))
