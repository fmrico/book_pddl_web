;; Exercise 5.7.2: a coffee machine.
(define (domain coffee)
  (:requirements :strips :typing :negative-preconditions
                 :disjunctive-preconditions
                 :existential-preconditions)

  (:types cup drink)

  (:predicates
    (under-nozzle ?c - cup)
    (full ?c - cup)
    (holds ?c - cup ?d - drink)   ; cup ?c holds drink ?d
    (with-milk ?d - drink)        ; static: the recipe needs milk
    (has-water) (has-beans) (has-milk)
    (clean))

  ;; Only one cup fits under the nozzle.
  (:action place
    :parameters (?c - cup)
    :precondition (not (exists (?o - cup) (under-nozzle ?o)))
    :effect (under-nozzle ?c))

  (:action remove
    :parameters (?c - cup)
    :precondition (under-nozzle ?c)
    :effect (not (under-nozzle ?c)))

  (:action make
    :parameters (?d - drink ?c - cup)
    :precondition (and (under-nozzle ?c) (not (full ?c))
                       (has-water) (has-beans) (clean)
                       (imply (with-milk ?d) (has-milk)))
    :effect (and (full ?c) (holds ?c ?d) (not (clean))))

  (:action add-milk
    :parameters ()
    :precondition (not (has-milk))
    :effect (has-milk))

  ;; Cleaning sprays water: no cup may be under the nozzle.
  (:action clean-machine
    :parameters ()
    :precondition
      (and (not (clean))
           (not (exists (?c - cup) (under-nozzle ?c))))
    :effect (clean)))
