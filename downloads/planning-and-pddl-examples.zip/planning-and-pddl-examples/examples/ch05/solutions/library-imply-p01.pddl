;; Ana wants an audiobook and has no player; Bob wants a book.
(define (problem library-imply-p01)
  (:domain library-imply)
  (:objects
    ana bob - member
    book1 - book
    audio1 - audiobook)
  (:init
    (can-borrow ana) (can-borrow bob)
    (on-shelf book1) (on-shelf audio1)
    (needs-player audio1))
  (:goal (and (borrowed audio1 ana) (borrowed book1 bob))))
