;; An espresso and a cappuccino; there is no milk in the machine.
(define (problem coffee-p01)
  (:domain coffee)
  (:objects
    cup1 cup2 - cup
    espresso cappuccino - drink)
  (:init
    (with-milk cappuccino)
    (has-water) (has-beans) (clean))
  (:goal (and (holds cup1 espresso) (holds cup2 cappuccino)
              (clean))))
