;; A sample from the ICU to the lab. The ICU door is locked and
;; the robot has a keycard.
(define (problem courier-doors-p03)
  (:domain courier-doors)
  (:objects
    r1 - robot
    lobby corridor pharmacy lab ward-a ward-b icu dock - location
    door-pharmacy door-lab door-icu - door
    sample1 - sample)
  (:init
    ; passages without a door
    (connected lobby corridor) (connected corridor lobby)
    (connected lobby dock) (connected dock lobby)
    (connected corridor ward-a) (connected ward-a corridor)
    (connected corridor ward-b) (connected ward-b corridor)
    ; passages with a door
    (joins door-pharmacy lobby pharmacy)
    (joins door-pharmacy pharmacy lobby)
    (joins door-lab corridor lab) (joins door-lab lab corridor)
    (joins door-icu ward-b icu) (joins door-icu icu ward-b)
    ; every door starts closed: no (open ...) fact
    (locked door-icu)
    (robot-at r1 dock) (free r1) (has-keycard r1)
    (item-at sample1 icu))
  (:goal (item-at sample1 lab)))
