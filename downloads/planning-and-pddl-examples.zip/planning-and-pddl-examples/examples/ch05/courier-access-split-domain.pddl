;; Restricted rooms without (or ...): one action for each way
;; of being allowed in.
(define (domain courier-access)
  (:requirements :strips :typing :negative-preconditions)

  (:types
    robot location
    medicine sample meal - item)

  (:predicates
    (connected ?from ?to - location)
    (robot-at ?r - robot ?l - location)
    (item-at ?i - item ?l - location)
    (carrying ?r - robot ?i - item)
    (free ?r - robot)
    (restricted ?l - location)    ; entering ?l needs a keycard
    (has-keycard ?r - robot))

  ;; Anybody enters a room that is not restricted.
  (:action move
    :parameters (?r - robot ?from ?to - location)
    :precondition (and (robot-at ?r ?from) (connected ?from ?to)
                       (not (restricted ?to)))
    :effect (and (not (robot-at ?r ?from))
                 (robot-at ?r ?to)))

  ;; A robot with a keycard enters a restricted room.
  (:action move-with-keycard
    :parameters (?r - robot ?from ?to - location)
    :precondition (and (robot-at ?r ?from) (connected ?from ?to)
                       (restricted ?to) (has-keycard ?r))
    :effect (and (not (robot-at ?r ?from))
                 (robot-at ?r ?to)))

  (:action pick
    :parameters (?r - robot ?i - item ?l - location)
    :precondition (and (robot-at ?r ?l) (item-at ?i ?l) (free ?r))
    :effect (and (not (item-at ?i ?l)) (not (free ?r))
                 (carrying ?r ?i)))

  (:action drop
    :parameters (?r - robot ?i - item ?l - location)
    :precondition (and (robot-at ?r ?l) (carrying ?r ?i))
    :effect (and (not (carrying ?r ?i))
                 (item-at ?i ?l) (free ?r))))
