;; Blocks world without the predicate clear: a block is clear
;; when no block is on it, and the preconditions say just that.
(define (domain blocks)
  (:requirements :strips :typing :equality
                 :negative-preconditions
                 :existential-preconditions)

  (:types block)

  (:predicates
    (on ?x ?y - block)
    (on-table ?x - block)
    (holding ?x - block)
    (hand-empty))

  (:action pick-up
    :parameters (?x - block)
    :precondition (and (on-table ?x) (hand-empty)
                       (not (exists (?z - block) (on ?z ?x))))
    :effect (and (not (on-table ?x)) (not (hand-empty))
                 (holding ?x)))

  (:action put-down
    :parameters (?x - block)
    :precondition (holding ?x)
    :effect (and (not (holding ?x)) (hand-empty)
                 (on-table ?x)))

  ;; ?y must be another block, with nothing on it.
  (:action stack
    :parameters (?x ?y - block)
    :precondition (and (holding ?x) (not (= ?x ?y))
                       (not (exists (?z - block) (on ?z ?y))))
    :effect (and (not (holding ?x)) (hand-empty)
                 (on ?x ?y)))

  (:action unstack
    :parameters (?x ?y - block)
    :precondition (and (on ?x ?y) (hand-empty)
                       (not (exists (?z - block) (on ?z ?x))))
    :effect (and (not (on ?x ?y)) (not (hand-empty))
                 (holding ?x))))
