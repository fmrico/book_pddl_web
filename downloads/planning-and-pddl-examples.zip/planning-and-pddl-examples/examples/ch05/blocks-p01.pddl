;; c is on a; a, b and d are on the table. Build a on b on c.
;; Nothing says which blocks are clear: it follows from on.
(define (problem blocks-p01)
  (:domain blocks)
  (:objects a b c d - block)
  (:init
    (on c a) (on-table a) (on-table b) (on-table d)
    (hand-empty))
  (:goal (and (on a b) (on b c))))
