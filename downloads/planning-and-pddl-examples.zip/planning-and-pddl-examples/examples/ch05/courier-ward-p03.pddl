;; "No item left in the corridor", and no robot ends with an
;; item in its gripper.
(define (problem courier-ward-p03)
  (:domain courier-ward)
  (:objects
    r1 - robot
    lobby corridor pharmacy lab ward-a ward-b icu dock - location
    door-pharmacy door-lab door-icu - door
    meal1 - meal)
  (:init
    (connected lobby corridor) (connected corridor lobby)
    (connected lobby pharmacy) (connected pharmacy lobby)
    (connected lobby dock) (connected dock lobby)
    (connected corridor lab) (connected lab corridor)
    (connected corridor ward-a) (connected ward-a corridor)
    (connected corridor ward-b) (connected ward-b corridor)
    (connected ward-b icu) (connected icu ward-b)
    (joins door-pharmacy lobby pharmacy)
    (joins door-pharmacy pharmacy lobby)
    (joins door-lab corridor lab) (joins door-lab lab corridor)
    (joins door-icu ward-b icu) (joins door-icu icu ward-b)
    (robot-at r1 corridor) (free r1)
    (item-at meal1 corridor))
  (:goal (and (forall (?i - item) (not (item-at ?i corridor)))
              (forall (?r - robot) (free ?r)))))
