;; Medicines for the ICU, a restricted room. r1 is next to them
;; but only r2 has a keycard.
(define (problem courier-access-p01)
  (:domain courier-access)
  (:objects
    r1 r2 - robot
    lobby corridor pharmacy lab ward-a ward-b icu dock - location
    meds1 - medicine)
  (:init
    (connected lobby corridor) (connected corridor lobby)
    (connected lobby pharmacy) (connected pharmacy lobby)
    (connected lobby dock) (connected dock lobby)
    (connected corridor lab) (connected lab corridor)
    (connected corridor ward-a) (connected ward-a corridor)
    (connected corridor ward-b) (connected ward-b corridor)
    (connected ward-b icu) (connected icu ward-b)
    (restricted icu) (restricted lab)
    (robot-at r1 pharmacy) (free r1)
    (robot-at r2 ward-a) (free r2) (has-keycard r2)
    (item-at meds1 pharmacy))
  (:goal (item-at meds1 icu)))
