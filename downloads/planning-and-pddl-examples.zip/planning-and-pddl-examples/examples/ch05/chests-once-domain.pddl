;; The same puzzle with keys that break when used. The action
;; must say WHICH key it uses, so the key is a parameter.
(define (domain chests-once)
  (:requirements :strips :typing :negative-preconditions)

  (:types chest key)

  (:predicates
    (have ?k - key)
    (inside ?k - key ?c - chest)
    (fits ?k - key ?c - chest)
    (opened ?c - chest))

  (:action open
    :parameters (?c - chest ?k - key)
    :precondition (and (not (opened ?c)) (have ?k) (fits ?k ?c))
    :effect (and (opened ?c) (not (have ?k))))

  (:action take
    :parameters (?k - key ?c - chest)
    :precondition (and (opened ?c) (inside ?k ?c))
    :effect (and (not (inside ?k ?c)) (have ?k))))
