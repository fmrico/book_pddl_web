;; The classic blocks world: clear is a predicate, and every
;; action that moves a block keeps it up to date.
(define (domain blocks-clear)
  (:requirements :strips :typing)

  (:types block)

  (:predicates
    (on ?x ?y - block)
    (on-table ?x - block)
    (clear ?x - block)      ; nothing is on ?x, and it is not held
    (holding ?x - block)
    (hand-empty))

  (:action pick-up
    :parameters (?x - block)
    :precondition (and (on-table ?x) (clear ?x) (hand-empty))
    :effect (and (not (on-table ?x)) (not (clear ?x))
                 (not (hand-empty)) (holding ?x)))

  (:action put-down
    :parameters (?x - block)
    :precondition (holding ?x)
    :effect (and (not (holding ?x)) (hand-empty)
                 (on-table ?x) (clear ?x)))

  (:action stack
    :parameters (?x ?y - block)
    :precondition (and (holding ?x) (clear ?y))
    :effect (and (not (holding ?x)) (not (clear ?y))
                 (hand-empty) (on ?x ?y) (clear ?x)))

  (:action unstack
    :parameters (?x ?y - block)
    :precondition (and (on ?x ?y) (clear ?x) (hand-empty))
    :effect (and (not (on ?x ?y)) (not (clear ?x))
                 (not (hand-empty)) (holding ?x) (clear ?y))))
