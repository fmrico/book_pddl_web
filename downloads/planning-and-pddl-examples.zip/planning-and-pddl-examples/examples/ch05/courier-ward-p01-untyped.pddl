;; WRONG on purpose: the variable of the first forall has no
;; type. It ranges over every object: robots, rooms, doors...
(define (problem courier-ward-p01-untyped)
  (:domain courier-ward)
  (:objects
    r1 - robot
    lobby corridor pharmacy lab ward-a ward-b icu dock - location
    door-pharmacy door-lab door-icu - door
    meds1 meds2 - medicine
    sample1 - sample)
  (:init
    (connected lobby corridor) (connected corridor lobby)
    (connected lobby pharmacy) (connected pharmacy lobby)
    (connected lobby dock) (connected dock lobby)
    (connected corridor lab) (connected lab corridor)
    (connected corridor ward-a) (connected ward-a corridor)
    (connected corridor ward-b) (connected ward-b corridor)
    (connected ward-b icu) (connected icu ward-b)
    (joins door-pharmacy lobby pharmacy)
    (joins door-pharmacy pharmacy lobby)
    (joins door-lab corridor lab) (joins door-lab lab corridor)
    (joins door-icu ward-b icu) (joins door-icu icu ward-b)
    (robot-at r1 dock) (free r1)
    (item-at meds1 pharmacy) (item-at meds2 pharmacy)
    (item-at sample1 lab))
  (:goal (and (forall (?m) (item-at ?m icu))
              (forall (?d - door) (not (open ?d))))))
