;; Another day, the same floor: a sample waits in the ICU and
;; the lab needs it. The robot starts in ward A.
(define (problem courier-p02)
  (:domain courier)
  (:objects r1 sample1
            lobby corridor pharmacy lab ward-a ward-b icu dock)
  (:init
    (robot r1) (item sample1)
    (location lobby) (location corridor) (location pharmacy)
    (location lab) (location ward-a) (location ward-b)
    (location icu) (location dock)
    ; the map: every connection in both directions
    (connected lobby corridor) (connected corridor lobby)
    (connected lobby pharmacy) (connected pharmacy lobby)
    (connected lobby dock) (connected dock lobby)
    (connected corridor lab) (connected lab corridor)
    (connected corridor ward-a) (connected ward-a corridor)
    (connected corridor ward-b) (connected ward-b corridor)
    (connected ward-b icu) (connected icu ward-b)
    ; where things are
    (robot-at r1 ward-a) (free r1)
    (item-at sample1 icu))
  (:goal (item-at sample1 lab)))
