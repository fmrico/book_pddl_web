;; Exercise 1.7.2: courier-p01 without the fact (free r1).
(define (problem courier-s02)
  (:domain courier)
  (:objects r1 meds1
            lobby corridor pharmacy lab ward-a ward-b icu dock)
  (:init
    (robot r1) (item meds1)
    (location lobby) (location corridor) (location pharmacy)
    (location lab) (location ward-a) (location ward-b)
    (location icu) (location dock)
    ; the map: every connection in both directions
    (connected lobby corridor) (connected corridor lobby)
    (connected lobby pharmacy) (connected pharmacy lobby)
    (connected lobby dock) (connected dock lobby)
    (connected corridor lab) (connected lab corridor)
    (connected corridor ward-a) (connected ward-a corridor)
    (connected corridor ward-b) (connected ward-b corridor)
    (connected ward-b icu) (connected icu ward-b)
    ; where things are
    (robot-at r1 dock)
    (item-at meds1 pharmacy))
  (:goal (item-at meds1 ward-a)))
