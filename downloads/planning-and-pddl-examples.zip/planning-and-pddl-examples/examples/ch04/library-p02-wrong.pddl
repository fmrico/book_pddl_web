;; WRONG on purpose: nobody can borrow a magazine.
(define (problem library-p02-wrong)
  (:domain library)
  (:objects
    ana - member
    mag1 - magazine)
  (:init (can-borrow ana) (on-shelf mag1))
  (:goal (borrowed mag1 ana)))
