;; Logistics with inequalities: a vehicle never travels from a
;; place to the same place.
(define (domain logistics)
  (:requirements :strips :typing :equality
                 :negative-preconditions)

  (:types
    city
    airport depot - place
    truck airplane - vehicle
    package vehicle - physobj)

  (:predicates
    (in-city ?p - place ?c - city)
    (at ?x - physobj ?p - place)        ; packages and vehicles
    (in ?k - package ?v - vehicle))

  ;; One load and one unload serve trucks and airplanes.
  (:action load
    :parameters (?k - package ?v - vehicle ?p - place)
    :precondition (and (at ?k ?p) (at ?v ?p))
    :effect (and (not (at ?k ?p)) (in ?k ?v)))

  (:action unload
    :parameters (?k - package ?v - vehicle ?p - place)
    :precondition (and (in ?k ?v) (at ?v ?p))
    :effect (and (not (in ?k ?v)) (at ?k ?p)))

  ;; A truck drives between any two places of one city.
  (:action drive
    :parameters (?t - truck ?from ?to - place ?c - city)
    :precondition (and (at ?t ?from) (not (= ?from ?to))
                       (in-city ?from ?c) (in-city ?to ?c))
    :effect (and (not (at ?t ?from)) (at ?t ?to)))

  ;; An airplane flies only between airports.
  (:action fly
    :parameters (?a - airplane ?from ?to - airport)
    :precondition (and (at ?a ?from) (not (= ?from ?to)))
    :effect (and (not (at ?a ?from)) (at ?a ?to))))
