;; Three balls from room a to room b.
(define (problem gripper-p01)
  (:domain gripper)
  (:objects
    rooma roomb - room
    ball1 ball2 ball3 - ball
    left right - gripper)
  (:init
    (at-robby rooma) (empty left) (empty right)
    (at ball1 rooma) (at ball2 rooma) (at ball3 rooma))
  (:goal (and (at ball1 roomb) (at ball2 roomb)
              (at ball3 roomb))))
