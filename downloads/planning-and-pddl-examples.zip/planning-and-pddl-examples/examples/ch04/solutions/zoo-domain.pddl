;; A zoo: keepers feed animals; only a vet treats, and big cats
;; are fed only by a senior keeper.
(define (domain zoo)
  (:requirements :strips :typing)

  (:types
    enclosure
    keeper vet - staff
    senior - keeper
    bigcat herbivore - animal
    lion tiger - bigcat
    zebra giraffe - herbivore)

  (:predicates
    (staff-at ?s - staff ?e - enclosure)
    (lives-in ?a - animal ?e - enclosure)
    (fed ?a - animal)
    (treated ?a - animal))

  (:action walk
    :parameters (?s - staff ?from ?to - enclosure)
    :precondition (staff-at ?s ?from)
    :effect (and (not (staff-at ?s ?from)) (staff-at ?s ?to)))

  (:action feed
    :parameters (?k - keeper ?a - herbivore ?e - enclosure)
    :precondition (and (staff-at ?k ?e) (lives-in ?a ?e))
    :effect (fed ?a))

  (:action feed-bigcat
    :parameters (?k - senior ?a - bigcat ?e - enclosure)
    :precondition (and (staff-at ?k ?e) (lives-in ?a ?e))
    :effect (fed ?a))

  (:action treat
    :parameters (?v - vet ?a - animal ?e - enclosure)
    :precondition (and (staff-at ?v ?e) (lives-in ?a ?e))
    :effect (treated ?a)))
