;; r1 holds what the ICU needs and r2 what the lab needs, each
;; in the wrong room. A swap saves one of the two trips.
(define (problem courier-swap-p01)
  (:domain courier-swap)
  (:objects
    r1 r2 - robot
    lobby corridor pharmacy lab ward-a ward-b icu dock - location
    meds1 sample1 - item)
  (:init
    (connected lobby corridor) (connected corridor lobby)
    (connected lobby pharmacy) (connected pharmacy lobby)
    (connected lobby dock) (connected dock lobby)
    (connected corridor lab) (connected lab corridor)
    (connected corridor ward-a) (connected ward-a corridor)
    (connected corridor ward-b) (connected ward-b corridor)
    (connected ward-b icu) (connected icu ward-b)
    (robot-at r1 lab) (carrying r1 meds1)
    (robot-at r2 icu) (carrying r2 sample1))
  (:goal (and (item-at meds1 icu) (item-at sample1 lab)
              (robot-at r1 lab) (robot-at r2 icu))))
