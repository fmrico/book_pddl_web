;; The library with audiobooks: DVDs and audiobooks need a
;; player. The hierarchy says what is loanable; (either ...)
;; says what needs a player.
(define (domain library-player)
  (:requirements :strips :typing)

  (:types
    member
    loanable magazine - media
    book dvd audiobook - loanable)

  (:predicates
    (on-shelf ?x - media)
    (borrowed ?x - loanable ?m - member)
    (can-borrow ?m - member)
    (has-player ?m - member))

  (:action borrow
    :parameters (?m - member ?x - book)
    :precondition (and (on-shelf ?x) (can-borrow ?m))
    :effect (and (not (on-shelf ?x)) (not (can-borrow ?m))
                 (borrowed ?x ?m)))

  (:action borrow-to-play
    :parameters (?m - member ?x - (either dvd audiobook))
    :precondition (and (on-shelf ?x) (can-borrow ?m)
                       (has-player ?m))
    :effect (and (not (on-shelf ?x)) (not (can-borrow ?m))
                 (borrowed ?x ?m)))

  (:action give-back
    :parameters (?m - member ?x - loanable)
    :precondition (borrowed ?x ?m)
    :effect (and (not (borrowed ?x ?m))
                 (on-shelf ?x) (can-borrow ?m)))

  (:action buy-player
    :parameters (?m - member)
    :effect (has-player ?m)))
