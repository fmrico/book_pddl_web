;; Feed everybody and treat the giraffe.
(define (problem zoo-p01)
  (:domain zoo)
  (:objects
    savanna cats-house office - enclosure
    kim - keeper
    sam - senior
    vera - vet
    leo - lion
    zoe - zebra
    gina - giraffe)
  (:init
    (staff-at kim office) (staff-at sam office)
    (staff-at vera office)
    (lives-in leo cats-house)
    (lives-in zoe savanna) (lives-in gina savanna))
  (:goal (and (fed leo) (fed zoe) (fed gina) (treated gina))))
