;; Gripper with types: a robot with two grippers carries balls
;; between rooms.
(define (domain gripper)
  (:requirements :strips :typing)

  (:types room ball gripper)

  (:predicates
    (at-robby ?r - room)
    (at ?b - ball ?r - room)
    (empty ?g - gripper)
    (holding ?g - gripper ?b - ball))

  (:action move
    :parameters (?from ?to - room)
    :precondition (at-robby ?from)
    :effect (and (not (at-robby ?from)) (at-robby ?to)))

  (:action pick
    :parameters (?b - ball ?r - room ?g - gripper)
    :precondition (and (at ?b ?r) (at-robby ?r) (empty ?g))
    :effect (and (not (at ?b ?r)) (not (empty ?g))
                 (holding ?g ?b)))

  (:action drop
    :parameters (?b - ball ?r - room ?g - gripper)
    :precondition (and (holding ?g ?b) (at-robby ?r))
    :effect (and (not (holding ?g ?b))
                 (at ?b ?r) (empty ?g))))
