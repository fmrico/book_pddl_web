;; Deliver the medicines and end the shift parked. The robot
;; starts in the dock: parking first is tempting.
(define (problem courier-park-p01)
  (:domain courier-park)
  (:objects
    r1 - robot
    lobby corridor pharmacy lab ward-a ward-b icu - location
    meds1 - item)
  (:init
    (connected lobby corridor) (connected corridor lobby)
    (connected lobby pharmacy) (connected pharmacy lobby)
    (connected lobby dock) (connected dock lobby)
    (connected corridor lab) (connected lab corridor)
    (connected corridor ward-a) (connected ward-a corridor)
    (connected corridor ward-b) (connected ward-b corridor)
    (connected ward-b icu) (connected icu ward-b)
    (robot-at r1 dock) (free r1)
    (item-at meds1 pharmacy))
  (:goal (and (item-at meds1 ward-a) (parked r1))))
