;; Ana wants an audiobook and has no player yet.
(define (problem library-player-p01)
  (:domain library-player)
  (:objects
    ana - member
    book1 - book
    audio1 - audiobook)
  (:init (can-borrow ana) (on-shelf book1) (on-shelf audio1))
  (:goal (borrowed audio1 ana)))
