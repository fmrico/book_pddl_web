;; Exercise 4.1.1: the arguments of robot-at are swapped in the
;; untyped model, and nothing complains.
(define (problem courier-untyped-p01-robot)
  (:domain courier)
  (:objects r1 meds1
            lobby corridor pharmacy lab ward-a ward-b icu dock)
  (:init
    (robot r1) (item meds1)
    (location lobby) (location corridor) (location pharmacy)
    (location lab) (location ward-a) (location ward-b)
    (location icu) (location dock)
    (connected lobby corridor) (connected corridor lobby)
    (connected lobby pharmacy) (connected pharmacy lobby)
    (connected lobby dock) (connected dock lobby)
    (connected corridor lab) (connected lab corridor)
    (connected corridor ward-a) (connected ward-a corridor)
    (connected corridor ward-b) (connected ward-b corridor)
    (connected ward-b icu) (connected icu ward-b)
    (robot-at dock r1) (free r1)
    (item-at meds1 pharmacy))
  (:goal (item-at meds1 ward-a)))
