;; A robot and a porter deliver medicines and a meal.
(define (problem courier-at-p01)
  (:domain courier-at)
  (:objects
    r1 - robot
    porter1 - porter
    lobby corridor pharmacy lab ward-a ward-b icu dock - location
    meds1 - medicine
    meal1 - meal)
  (:init
    (connected lobby corridor) (connected corridor lobby)
    (connected lobby pharmacy) (connected pharmacy lobby)
    (connected lobby dock) (connected dock lobby)
    (connected corridor lab) (connected lab corridor)
    (connected corridor ward-a) (connected ward-a corridor)
    (connected corridor ward-b) (connected ward-b corridor)
    (connected ward-b icu) (connected icu ward-b)
    (at r1 lobby) (free r1)
    (at porter1 ward-b) (free porter1)
    (at meal1 lobby) (at meds1 pharmacy))
  (:goal (and (at meal1 ward-a) (at meds1 icu))))
