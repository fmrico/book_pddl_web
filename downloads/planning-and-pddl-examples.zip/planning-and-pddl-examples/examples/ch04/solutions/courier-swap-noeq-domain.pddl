;; The swap WITHOUT the inequality: (swap r1 r1 ...) is legal.
(define (domain courier-swap)
  (:requirements :strips :typing)

  (:types robot location item)

  (:predicates
    (connected ?from ?to - location)
    (robot-at ?r - robot ?l - location)
    (item-at ?i - item ?l - location)
    (carrying ?r - robot ?i - item)
    (free ?r - robot))

  (:action move
    :parameters (?r - robot ?from ?to - location)
    :precondition (and (robot-at ?r ?from) (connected ?from ?to))
    :effect (and (not (robot-at ?r ?from))
                 (robot-at ?r ?to)))

  (:action pick
    :parameters (?r - robot ?i - item ?l - location)
    :precondition (and (robot-at ?r ?l) (item-at ?i ?l) (free ?r))
    :effect (and (not (item-at ?i ?l)) (not (free ?r))
                 (carrying ?r ?i)))

  (:action drop
    :parameters (?r - robot ?i - item ?l - location)
    :precondition (and (robot-at ?r ?l) (carrying ?r ?i))
    :effect (and (not (carrying ?r ?i))
                 (item-at ?i ?l) (free ?r)))

  (:action swap
    :parameters (?a ?b - robot ?i ?j - item ?l - location)
    :precondition (and (robot-at ?a ?l) (robot-at ?b ?l)
                       (carrying ?a ?i) (carrying ?b ?j))
    :effect (and (not (carrying ?a ?i)) (not (carrying ?b ?j))
                 (carrying ?a ?j) (carrying ?b ?i))))
