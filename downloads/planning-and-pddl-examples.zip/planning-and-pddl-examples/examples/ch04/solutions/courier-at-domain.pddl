;; The team of carriers with ONE predicate for "is in": its
;; first argument is (either carrier item).
(define (domain courier-at)
  (:requirements :strips :typing)

  (:types
    location
    robot porter - carrier
    medicine sample meal - item)

  (:predicates
    (connected ?from ?to - location)
    (at ?x - (either carrier item) ?l - location)
    (carrying ?c - carrier ?i - item)
    (free ?c - carrier))

  (:action move
    :parameters (?c - carrier ?from ?to - location)
    :precondition (and (at ?c ?from) (connected ?from ?to))
    :effect (and (not (at ?c ?from)) (at ?c ?to)))

  (:action pick
    :parameters (?c - carrier ?i - item ?l - location)
    :precondition (and (at ?c ?l) (at ?i ?l) (free ?c))
    :effect (and (not (at ?i ?l)) (not (free ?c))
                 (carrying ?c ?i)))

  (:action drop
    :parameters (?c - carrier ?i - item ?l - location)
    :precondition (and (at ?c ?l) (carrying ?c ?i))
    :effect (and (not (carrying ?c ?i))
                 (at ?i ?l) (free ?c))))
