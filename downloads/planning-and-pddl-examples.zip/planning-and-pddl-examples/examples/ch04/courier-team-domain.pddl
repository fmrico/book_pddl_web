;; The courier world with a type hierarchy: robots and porters
;; are carriers; medicines, samples and meals are items.
(define (domain courier-team)
  (:requirements :strips :typing)

  (:types
    location
    robot porter - carrier
    medicine sample meal - item)

  (:predicates
    (connected ?from ?to - location)
    (carrier-at ?c - carrier ?l - location)
    (item-at ?i - item ?l - location)
    (carrying ?c - carrier ?i - item)
    (free ?c - carrier)
    (served ?m - meal ?l - location))   ; ?m was served in ?l

  ;; Any carrier moves, picks and drops any item.
  (:action move
    :parameters (?c - carrier ?from ?to - location)
    :precondition (and (carrier-at ?c ?from)
                       (connected ?from ?to))
    :effect (and (not (carrier-at ?c ?from))
                 (carrier-at ?c ?to)))

  (:action pick
    :parameters (?c - carrier ?i - item ?l - location)
    :precondition (and (carrier-at ?c ?l) (item-at ?i ?l)
                       (free ?c))
    :effect (and (not (item-at ?i ?l)) (not (free ?c))
                 (carrying ?c ?i)))

  (:action drop
    :parameters (?c - carrier ?i - item ?l - location)
    :precondition (and (carrier-at ?c ?l) (carrying ?c ?i))
    :effect (and (not (carrying ?c ?i))
                 (item-at ?i ?l) (free ?c)))

  ;; Only a porter serves, and only a meal is served.
  (:action serve
    :parameters (?p - porter ?m - meal ?l - location)
    :precondition (and (carrier-at ?p ?l) (carrying ?p ?m))
    :effect (and (not (carrying ?p ?m)) (free ?p)
                 (served ?m ?l))))
