;; A library: books and DVDs can be borrowed, magazines cannot.
;; The parameter of borrow uses (either ...).
(define (domain library)
  (:requirements :strips :typing)

  (:types book dvd magazine member)

  (:predicates
    (on-shelf ?x - (either book dvd magazine))
    (borrowed ?x - (either book dvd) ?m - member)
    (reading ?g - magazine ?m - member)
    (can-borrow ?m - member))     ; one loan at a time

  (:action borrow
    :parameters (?m - member ?x - (either book dvd))
    :precondition (and (on-shelf ?x) (can-borrow ?m))
    :effect (and (not (on-shelf ?x)) (not (can-borrow ?m))
                 (borrowed ?x ?m)))

  (:action give-back
    :parameters (?m - member ?x - (either book dvd))
    :precondition (borrowed ?x ?m)
    :effect (and (not (borrowed ?x ?m))
                 (on-shelf ?x) (can-borrow ?m)))

  ;; Magazines are read in the library.
  (:action take-to-read
    :parameters (?m - member ?g - magazine)
    :precondition (on-shelf ?g)
    :effect (and (not (on-shelf ?g)) (reading ?g ?m)))

  (:action put-back
    :parameters (?m - member ?g - magazine)
    :precondition (reading ?g ?m)
    :effect (and (not (reading ?g ?m)) (on-shelf ?g))))
