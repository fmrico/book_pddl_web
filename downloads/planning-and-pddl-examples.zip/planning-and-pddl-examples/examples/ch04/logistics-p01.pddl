;; A package from a depot in Madrid to a depot in Paris.
(define (problem logistics-p01)
  (:domain logistics)
  (:objects
    madrid paris - city
    mad-airport par-airport - airport
    mad-depot par-depot - depot
    truck1 truck2 - truck
    plane1 - airplane
    pkg1 - package)
  (:init
    (in-city mad-airport madrid) (in-city mad-depot madrid)
    (in-city par-airport paris) (in-city par-depot paris)
    (at truck1 mad-airport) (at truck2 par-depot)
    (at plane1 par-airport)
    (at pkg1 mad-depot))
  (:goal (at pkg1 par-depot)))
