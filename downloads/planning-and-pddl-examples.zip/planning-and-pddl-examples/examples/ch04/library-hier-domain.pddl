;; The library again, with a hierarchy instead of (either ...).
(define (domain library)
  (:requirements :strips :typing)

  (:types
    member
    loanable magazine - media
    book dvd - loanable)

  (:predicates
    (on-shelf ?x - media)
    (borrowed ?x - loanable ?m - member)
    (reading ?g - magazine ?m - member)
    (can-borrow ?m - member))     ; one loan at a time

  (:action borrow
    :parameters (?m - member ?x - loanable)
    :precondition (and (on-shelf ?x) (can-borrow ?m))
    :effect (and (not (on-shelf ?x)) (not (can-borrow ?m))
                 (borrowed ?x ?m)))

  (:action give-back
    :parameters (?m - member ?x - loanable)
    :precondition (borrowed ?x ?m)
    :effect (and (not (borrowed ?x ?m))
                 (on-shelf ?x) (can-borrow ?m)))

  ;; Magazines are read in the library.
  (:action take-to-read
    :parameters (?m - member ?g - magazine)
    :precondition (on-shelf ?g)
    :effect (and (not (on-shelf ?g)) (reading ?g ?m)))

  (:action put-back
    :parameters (?m - member ?g - magazine)
    :precondition (reading ?g ?m)
    :effect (and (not (reading ?g ?m)) (on-shelf ?g))))
