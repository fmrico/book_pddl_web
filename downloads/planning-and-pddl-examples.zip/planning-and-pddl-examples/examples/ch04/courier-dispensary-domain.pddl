;; The alternative to the constant: the room where medicines
;; are dispensed is a parameter, marked by a static predicate.
(define (domain courier-dispensary)
  (:requirements :strips :typing)

  (:types
    robot location
    medicine sample meal - item)

  (:predicates
    (connected ?from ?to - location)
    (robot-at ?r - robot ?l - location)
    (item-at ?i - item ?l - location)
    (carrying ?r - robot ?i - item)
    (free ?r - robot)
    (dispensary ?l - location)            ; medicines handed here
    (in-stock ?m - medicine ?l - location))

  (:action move
    :parameters (?r - robot ?from ?to - location)
    :precondition (and (robot-at ?r ?from) (connected ?from ?to))
    :effect (and (not (robot-at ?r ?from))
                 (robot-at ?r ?to)))

  (:action pick
    :parameters (?r - robot ?i - item ?l - location)
    :precondition (and (robot-at ?r ?l) (item-at ?i ?l) (free ?r))
    :effect (and (not (item-at ?i ?l)) (not (free ?r))
                 (carrying ?r ?i)))

  (:action drop
    :parameters (?r - robot ?i - item ?l - location)
    :precondition (and (robot-at ?r ?l) (carrying ?r ?i))
    :effect (and (not (carrying ?r ?i))
                 (item-at ?i ?l) (free ?r)))

  (:action dispense
    :parameters (?r - robot ?m - medicine ?l - location)
    :precondition (and (dispensary ?l) (robot-at ?r ?l)
                       (in-stock ?m ?l) (free ?r))
    :effect (and (not (in-stock ?m ?l)) (not (free ?r))
                 (carrying ?r ?m))))
