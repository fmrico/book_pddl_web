;; The double check WITHOUT the inequality: nothing says that
;; the witness ?w is another robot. Compare courier-check-domain.
(define (domain courier-check)
  (:requirements :strips :typing)

  (:types
    robot location
    medicine sample meal - item)

  (:predicates
    (connected ?from ?to - location)
    (robot-at ?r - robot ?l - location)
    (item-at ?i - item ?l - location)
    (carrying ?r - robot ?i - item)
    (free ?r - robot)
    (verified ?m - medicine))

  (:action move
    :parameters (?r - robot ?from ?to - location)
    :precondition (and (robot-at ?r ?from) (connected ?from ?to))
    :effect (and (not (robot-at ?r ?from))
                 (robot-at ?r ?to)))

  (:action pick
    :parameters (?r - robot ?i - item ?l - location)
    :precondition (and (robot-at ?r ?l) (item-at ?i ?l) (free ?r))
    :effect (and (not (item-at ?i ?l)) (not (free ?r))
                 (carrying ?r ?i)))

  (:action drop
    :parameters (?r - robot ?i - item ?l - location)
    :precondition (and (robot-at ?r ?l) (carrying ?r ?i))
    :effect (and (not (carrying ?r ?i))
                 (item-at ?i ?l) (free ?r)))

  ;; Robot ?r carries the medicine, robot ?w witnesses.
  (:action verify
    :parameters (?r ?w - robot ?m - medicine ?l - location)
    :precondition (and (robot-at ?r ?l) (robot-at ?w ?l)
                       (carrying ?r ?m))
    :effect (verified ?m)))
