;; Two robots: r2, in the corridor, can be the witness.
(define (problem courier-check-p02)
  (:domain courier-check)
  (:objects
    r1 r2 - robot
    lobby corridor pharmacy lab ward-a ward-b icu dock - location
    meds1 - medicine)
  (:init
    (connected lobby corridor) (connected corridor lobby)
    (connected lobby pharmacy) (connected pharmacy lobby)
    (connected lobby dock) (connected dock lobby)
    (connected corridor lab) (connected lab corridor)
    (connected corridor ward-a) (connected ward-a corridor)
    (connected corridor ward-b) (connected ward-b corridor)
    (connected ward-b icu) (connected icu ward-b)
    (robot-at r1 dock) (free r1)
    (robot-at r2 corridor) (free r2)
    (item-at meds1 pharmacy))
  (:goal (and (item-at meds1 icu) (verified meds1))))
