;; Ana has the book that Bob wants, and wants a DVD herself.
(define (problem library-p01)
  (:domain library)
  (:objects
    ana bob - member
    book1 - book
    dvd1 - dvd
    mag1 - magazine)
  (:init
    (borrowed book1 ana) (can-borrow bob)
    (on-shelf dvd1) (on-shelf mag1))
  (:goal (and (borrowed dvd1 ana) (borrowed book1 bob)
              (reading mag1 bob))))
