;; Two robots and three deliveries (typed version).
(define (problem courier-p02)
  (:domain courier)
  (:objects
    r1 r2 - robot
    lobby corridor pharmacy lab ward-a ward-b icu dock - location
    meds1 meds2 sample1 - item)
  (:init
    (connected lobby corridor) (connected corridor lobby)
    (connected lobby pharmacy) (connected pharmacy lobby)
    (connected lobby dock) (connected dock lobby)
    (connected corridor lab) (connected lab corridor)
    (connected corridor ward-a) (connected ward-a corridor)
    (connected corridor ward-b) (connected ward-b corridor)
    (connected ward-b icu) (connected icu ward-b)
    (robot-at r1 dock) (free r1)
    (robot-at r2 corridor) (free r2)
    (item-at meds1 pharmacy) (item-at meds2 pharmacy)
    (item-at sample1 ward-b))
  (:goal (and (item-at meds1 ward-a) (item-at meds2 icu)
              (item-at sample1 lab))))
