;; The courier world with a constant: medicines are dispensed
;; in the pharmacy, a room that every problem has.
(define (domain courier-pharmacy)
  (:requirements :strips :typing)

  (:types
    robot location
    medicine sample meal - item)

  (:constants pharmacy - location)

  (:predicates
    (connected ?from ?to - location)
    (robot-at ?r - robot ?l - location)
    (item-at ?i - item ?l - location)
    (carrying ?r - robot ?i - item)
    (free ?r - robot)
    (in-stock ?m - medicine))     ; ?m is still in the pharmacy

  (:action move
    :parameters (?r - robot ?from ?to - location)
    :precondition (and (robot-at ?r ?from) (connected ?from ?to))
    :effect (and (not (robot-at ?r ?from))
                 (robot-at ?r ?to)))

  (:action pick
    :parameters (?r - robot ?i - item ?l - location)
    :precondition (and (robot-at ?r ?l) (item-at ?i ?l) (free ?r))
    :effect (and (not (item-at ?i ?l)) (not (free ?r))
                 (carrying ?r ?i)))

  (:action drop
    :parameters (?r - robot ?i - item ?l - location)
    :precondition (and (robot-at ?r ?l) (carrying ?r ?i))
    :effect (and (not (carrying ?r ?i))
                 (item-at ?i ?l) (free ?r)))

  ;; The pharmacist hands a medicine to a robot. The action
  ;; names the pharmacy: it has no location parameter.
  (:action dispense
    :parameters (?r - robot ?m - medicine)
    :precondition (and (robot-at ?r pharmacy) (in-stock ?m)
                       (free ?r))
    :effect (and (not (in-stock ?m)) (not (free ?r))
                 (carrying ?r ?m))))
