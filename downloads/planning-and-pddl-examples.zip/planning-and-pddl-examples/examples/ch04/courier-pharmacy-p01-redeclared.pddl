;; WRONG on purpose: pharmacy, a constant of the domain, is
;; declared again as an object.
(define (problem courier-pharmacy-p01-redeclared)
  (:domain courier-pharmacy)
  (:objects
    r1 - robot
    lobby corridor pharmacy lab ward-a ward-b icu dock - location
    meds1 meds2 - medicine
    sample1 - sample)
  (:init
    (connected lobby corridor) (connected corridor lobby)
    (connected lobby pharmacy) (connected pharmacy lobby)
    (connected lobby dock) (connected dock lobby)
    (connected corridor lab) (connected lab corridor)
    (connected corridor ward-a) (connected ward-a corridor)
    (connected corridor ward-b) (connected ward-b corridor)
    (connected ward-b icu) (connected icu ward-b)
    (robot-at r1 dock) (free r1)
    (in-stock meds1) (in-stock meds2)
    (item-at sample1 icu))
  (:goal (and (item-at meds1 ward-a) (item-at meds2 icu)
              (item-at sample1 lab))))
