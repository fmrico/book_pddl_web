;; A meal to serve in ward A and medicines for the ICU.
(define (problem courier-team-p01)
  (:domain courier-team)
  (:objects
    r1 - robot
    porter1 - porter
    lobby corridor pharmacy lab ward-a ward-b icu dock - location
    meds1 - medicine
    meal1 - meal)
  (:init
    (connected lobby corridor) (connected corridor lobby)
    (connected lobby pharmacy) (connected pharmacy lobby)
    (connected lobby dock) (connected dock lobby)
    (connected corridor lab) (connected lab corridor)
    (connected corridor ward-a) (connected ward-a corridor)
    (connected corridor ward-b) (connected ward-b corridor)
    (connected ward-b icu) (connected icu ward-b)
    (carrier-at r1 lobby) (free r1)
    (carrier-at porter1 ward-b) (free porter1)
    (item-at meal1 lobby) (item-at meds1 pharmacy))
  (:goal (and (served meal1 ward-a) (item-at meds1 icu))))
