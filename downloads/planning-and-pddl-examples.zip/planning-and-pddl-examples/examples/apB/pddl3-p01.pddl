;; Appendix B, template 4: a problem for the PDDL 3 domain.
(define (problem courier-pddl3-p01)
  (:domain courier-pddl3)
  (:requirements :negative-preconditions :universal-preconditions)
  (:objects r1 - robot
            lobby pharmacy ward-a icu - location
            meds1 meal1 - item)
  (:init
    (connected dock lobby) (connected lobby dock)
    (connected lobby pharmacy) (connected pharmacy lobby)
    (connected lobby ward-a) (connected ward-a lobby)
    (connected ward-a icu) (connected icu ward-a)
    (quiet icu)
    (= (location-of r1) dock) (free r1)
    (item-at meds1 pharmacy) (item-at meal1 lobby))
  (:goal (and
    (item-at meds1 ward-a)                          ; required
    (preference meal-served (item-at meal1 icu))    ; wished
    (preference back-home (= (location-of r1) dock))
    (forall (?i - item)
      (preference hands-off (not (carrying r1 ?i))))))
  (:constraints (and                        ; for this problem
    (always (not (item-at meds1 lobby)))
    (sometime (= (location-of r1) pharmacy))
    (sometime-before (item-at meal1 icu) (item-at meds1 ward-a))
    (preference no-icu
      (always (not (= (location-of r1) icu))))))
  (:metric minimize (+ (* 10 (is-violated meal-served))
                       (* 2 (is-violated back-home))
                       (* 5 (is-violated hands-off))
                       (* 3 (is-violated no-icu))
                       (is-violated quiet-moves))))
