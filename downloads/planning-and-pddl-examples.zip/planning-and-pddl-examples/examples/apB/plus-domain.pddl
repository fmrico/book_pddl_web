;; Appendix B, template 5: PDDL+ (chapters 17 and 18). Actions are
;; what the agent decides; processes and events are what the world
;; does by itself.
(define (domain courier-plus)
  (:requirements :typing :negative-preconditions
                 :numeric-fluents :time)

  (:types robot location item)

  (:predicates
    (connected ?from ?to - location)
    (robot-at ?r - robot ?l - location)
    (powered ?r - robot)
    (has-charger ?l - location)
    (charging ?r - robot)
    (in-fridge ?i - item) (spoiled ?i - item))

  (:functions
    (battery ?r - robot) (battery-capacity ?r - robot)
    (drain-rate ?r - robot) (charge-rate ?r - robot)
    (temperature ?i - item))

  (:action move
    :parameters (?r - robot ?from ?to - location)
    :precondition (and (powered ?r) (robot-at ?r ?from)
                       (connected ?from ?to) (not (charging ?r))
                       (>= (battery ?r) 5))
    :effect (and (not (robot-at ?r ?from)) (robot-at ?r ?to)
                 (decrease (battery ?r) 5)))

  (:action plug
    :parameters (?r - robot ?l - location)
    :precondition (and (robot-at ?r ?l) (has-charger ?l)
                       (not (charging ?r)))
    :effect (charging ?r))

  (:action unplug
    :parameters (?r - robot)
    :precondition (charging ?r)
    :effect (not (charging ?r)))

  (:action take-out
    :parameters (?i - item)
    :precondition (in-fridge ?i)
    :effect (not (in-fridge ?i)))

  ;; Runs for as long as its condition holds.
  (:process drain
    :parameters (?r - robot)
    :precondition (and (powered ?r) (not (charging ?r)))
    :effect (decrease (battery ?r) (* #t (drain-rate ?r))))

  (:process recharge
    :parameters (?r - robot)
    :precondition (and (charging ?r)
                       (< (battery ?r) (battery-capacity ?r)))
    :effect (increase (battery ?r) (* #t (charge-rate ?r))))

  (:process warm-up
    :parameters (?i - item)
    :precondition (and (not (in-fridge ?i))
                       (< (temperature ?i) 20))
    :effect (increase (temperature ?i) (* #t 0.5)))

  ;; Fires at the instant its condition becomes true, and must
  ;; make it false.
  (:event shut-down
    :parameters (?r - robot)
    :precondition (and (powered ?r) (<= (battery ?r) 0))
    :effect (not (powered ?r)))

  (:event spoil
    :parameters (?i - item)
    :precondition (and (not (spoiled ?i)) (>= (temperature ?i) 8))
    :effect (spoiled ?i)))
