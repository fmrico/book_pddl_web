;; Appendix B, template 2: numeric PDDL (PDDL 2.1 level 2, and the
;; action costs of PDDL 3.1; chapters 8 and 9).
(define (domain courier-numeric)
  (:requirements :typing :numeric-fluents)

  (:types robot location item)

  (:predicates
    (connected ?from ?to - location)
    (robot-at ?r - robot ?l - location)
    (item-at ?i - item ?l - location)
    (carrying ?r - robot ?i - item)
    (has-charger ?l - location))

  (:functions                               ; numbers in the state
    (battery ?r - robot) (battery-capacity ?r - robot)
    (consumption ?r - robot)
    (load ?r - robot) (capacity ?r - robot)
    (weight ?i - item)
    (distance ?from ?to - location)
    (total-cost))

  (:action move
    :parameters (?r - robot ?from ?to - location)
    :precondition (and
      (robot-at ?r ?from) (connected ?from ?to)
      (>= (battery ?r)                      ; < <= = >= >
          (* (distance ?from ?to) (consumption ?r))))   ; + - * /
    :effect (and
      (not (robot-at ?r ?from)) (robot-at ?r ?to)
      (decrease (battery ?r)
                (* (distance ?from ?to) (consumption ?r)))
      (increase (total-cost) (distance ?from ?to))))

  (:action pick
    :parameters (?r - robot ?i - item ?l - location)
    :precondition (and
      (robot-at ?r ?l) (item-at ?i ?l)
      (<= (+ (load ?r) (weight ?i)) (capacity ?r)))
    :effect (and (not (item-at ?i ?l)) (carrying ?r ?i)
                 (increase (load ?r) (weight ?i))
                 (increase (total-cost) 1)))

  (:action drop
    :parameters (?r - robot ?i - item ?l - location)
    :precondition (and (robot-at ?r ?l) (carrying ?r ?i))
    :effect (and (not (carrying ?r ?i)) (item-at ?i ?l)
                 (decrease (load ?r) (weight ?i))
                 (increase (total-cost) 1)))

  (:action charge
    :parameters (?r - robot ?l - location)
    :precondition (and (robot-at ?r ?l) (has-charger ?l)
                       (< (battery ?r) (battery-capacity ?r)))
    :effect (and (assign (battery ?r) (battery-capacity ?r))
                 (increase (total-cost) 20)))

  (:action save-energy                      ; scale-up, scale-down
    :parameters (?r - robot)
    :precondition (> (consumption ?r) 0.5)
    :effect (and (scale-down (consumption ?r) 2)
                 (increase (total-cost) 5))))
