;; Appendix B, template 4: PDDL 3.0 and 3.1 (chapters 14-16):
;; preferences, constraints on the whole plan, object fluents.
(define (domain courier-pddl3)
  (:requirements :typing :equality :negative-preconditions
                 :universal-preconditions
                 :preferences :constraints :object-fluents)

  (:types robot location item)

  (:constants dock - location)

  (:predicates
    (connected ?from ?to - location)
    (item-at ?i - item ?l - location)
    (carrying ?r - robot ?i - item)
    (free ?r - robot)
    (quiet ?l - location))

  (:functions
    (location-of ?r - robot) - location)    ; holds an object

  (:constraints                             ; for every plan
    (forall (?r - robot)
      (at-most-once (= (location-of ?r) dock))))

  (:action move
    :parameters (?r - robot ?from ?to - location)
    :precondition (and
      (= (location-of ?r) ?from) (connected ?from ?to)
      (preference quiet-moves (not (quiet ?to))))   ; a wish
    :effect (assign (location-of ?r) ?to))

  (:action pick
    :parameters (?r - robot ?i - item ?l - location)
    :precondition (and (= (location-of ?r) ?l) (item-at ?i ?l)
                       (free ?r))
    :effect (and (not (item-at ?i ?l)) (not (free ?r))
                 (carrying ?r ?i)))

  (:action drop
    :parameters (?r - robot ?i - item ?l - location)
    :precondition (and (= (location-of ?r) ?l) (carrying ?r ?i))
    :effect (and (not (carrying ?r ?i)) (free ?r)
                 (item-at ?i ?l))))
