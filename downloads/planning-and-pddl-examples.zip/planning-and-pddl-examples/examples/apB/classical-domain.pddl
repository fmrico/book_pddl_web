;; Appendix B, template 1: classical PDDL (PDDL 1.2), the
;; language of chapters 2 to 7.
(define (domain courier-classical)
  (:requirements :strips :typing :equality
                 :negative-preconditions
                 :disjunctive-preconditions
                 :existential-preconditions
                 :universal-preconditions
                 :conditional-effects)    ; or all of them: :adl

  (:types robot location item - object      ; a type hierarchy
          medicine sample - item)

  (:constants dock - location)              ; in every problem

  (:predicates
    (connected ?from ?to - location)
    (robot-at ?r - robot ?l - location)
    (item-at ?i - item ?l - location)
    (carrying ?r - robot ?i - item)
    (free ?r - robot)
    (restricted ?l - location) (has-keycard ?r - robot)
    (sterile ?l - location)
    (sealed ?i - item) (contaminated ?i - item))

  (:action move
    :parameters (?r - robot ?from ?to - location)
    :precondition (and
      (robot-at ?r ?from) (connected ?from ?to)
      (not (= ?from ?to))                         ; equality
      (or (not (restricted ?to)) (has-keycard ?r)))   ; or, not
    :effect (and
      (not (robot-at ?r ?from)) (robot-at ?r ?to)   ; delete, add
      (forall (?i - sample)                         ; for each...
        (when (and (carrying ?r ?i) (sterile ?to)   ; ...if
                   (not (sealed ?i)))
          (contaminated ?i)))))

  (:action pick
    :parameters (?r - robot ?i - item ?l - location)
    :precondition (and (robot-at ?r ?l) (item-at ?i ?l) (free ?r))
    :effect (and (not (item-at ?i ?l)) (not (free ?r))
                 (carrying ?r ?i)))

  (:action drop
    :parameters (?r - robot ?i - item ?l - location)
    :precondition (and (robot-at ?r ?l) (carrying ?r ?i))
    :effect (and (not (carrying ?r ?i))
                 (item-at ?i ?l) (free ?r)))

  (:action take-keycard
    :parameters (?r - robot)
    :precondition (and
      (robot-at ?r dock)                            ; a constant
      (forall (?i - item) (not (carrying ?r ?i)))   ; forall
      (exists (?l - location) (restricted ?l)))     ; exists
    :effect (has-keycard ?r)))
