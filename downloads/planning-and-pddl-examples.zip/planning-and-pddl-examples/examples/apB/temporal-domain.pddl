;; Appendix B, template 3: temporal PDDL (PDDL 2.1 levels 3 and 4,
;; PDDL 2.2; chapters 10-13).
(define (domain courier-temporal)
  (:requirements :typing :numeric-fluents :durative-actions
                 :duration-inequalities :continuous-effects
                 :derived-predicates :timed-initial-literals
                 :disjunctive-preconditions
                 :existential-preconditions)

  (:types robot location item)

  (:predicates
    (connected ?from ?to - location)
    (reachable ?from ?to - location)        ; derived, see below
    (robot-at ?r - robot ?l - location)
    (item-at ?i - item ?l - location)
    (carrying ?r - robot ?i - item)
    (idle ?r - robot)
    (has-charger ?l - location)
    (is-open ?l - location))

  (:functions
    (distance ?from ?to - location) (speed ?r - robot)
    (battery ?r - robot) (battery-capacity ?r - robot)
    (drain-rate ?r - robot) (charge-rate ?r - robot))

  ;; A fact defined by a rule, never by an effect.
  (:derived (reachable ?from ?to - location)
    (or (connected ?from ?to)
        (exists (?mid - location)
          (and (connected ?from ?mid) (reachable ?mid ?to)))))

  (:durative-action move
    :parameters (?r - robot ?from ?to - location)
    :duration (= ?duration (/ (distance ?from ?to) (speed ?r)))
    :condition (and
      (at start (robot-at ?r ?from))        ; when it starts
      (at start (idle ?r))
      (at start (connected ?from ?to))
      (at start (>= (battery ?r)
                    (* (drain-rate ?r)
                       (/ (distance ?from ?to) (speed ?r)))))
      (over all (is-open ?to)))             ; while it runs
    :effect (and
      (at start (not (robot-at ?r ?from)))
      (at start (not (idle ?r)))
      (at end (robot-at ?r ?to))            ; when it ends
      (at end (idle ?r))
      (at end (decrease (battery ?r)
                        (* (drain-rate ?r) ?duration)))))

  (:durative-action charge                  ; the planner chooses
    :parameters (?r - robot ?l - location)  ; how long it lasts
    :duration (and (>= ?duration 1)
                   (<= ?duration (/ (- (battery-capacity ?r)
                                       (battery ?r))
                                    (charge-rate ?r))))
    :condition (and
      (at start (idle ?r))
      (over all (robot-at ?r ?l))
      (over all (has-charger ?l)))
    :effect (and
      (at start (not (idle ?r)))
      (at end (idle ?r))
      (increase (battery ?r)                ; continuous: #t is
                (* #t (charge-rate ?r)))))  ; the time elapsed

  (:durative-action pick
    :parameters (?r - robot ?i - item ?l - location)
    :duration (= ?duration 2)
    :condition (and (at start (idle ?r))
                    (at start (item-at ?i ?l))
                    (over all (robot-at ?r ?l)))
    :effect (and (at start (not (idle ?r)))
                 (at start (not (item-at ?i ?l)))
                 (at end (carrying ?r ?i)) (at end (idle ?r))))

  (:durative-action drop
    :parameters (?r - robot ?i - item ?l - location)
    :duration (= ?duration 2)
    :condition (and (at start (idle ?r))
                    (at start (carrying ?r ?i))
                    (over all (robot-at ?r ?l)))
    :effect (and (at start (not (idle ?r)))
                 (at start (not (carrying ?r ?i)))
                 (at end (item-at ?i ?l)) (at end (idle ?r)))))
