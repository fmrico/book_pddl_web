;; Appendix B, template 2: a problem for the numeric domain.
(define (problem courier-numeric-p01)
  (:domain courier-numeric)
  (:objects r1 - robot
            dock lobby pharmacy - location
            meds1 meds2 - item)
  (:init
    (connected dock lobby) (connected lobby dock)
    (connected lobby pharmacy) (connected pharmacy lobby)
    (has-charger dock)
    (robot-at r1 dock)
    (item-at meds1 pharmacy) (item-at meds2 pharmacy)
    (= (battery r1) 15) (= (battery-capacity r1) 100)
    (= (consumption r1) 1)
    (= (load r1) 0) (= (capacity r1) 5)
    (= (weight meds1) 2) (= (weight meds2) 4)
    (= (distance dock lobby) 4) (= (distance lobby dock) 4)
    (= (distance lobby pharmacy) 6)
    (= (distance pharmacy lobby) 6)
    (= (total-cost) 0))
  (:goal (and (item-at meds1 lobby) (item-at meds2 lobby)
              (>= (battery r1) 10)))        ; a numeric goal
  ;; minimize or maximize, any expression of fluents
  (:metric minimize (total-cost)))
