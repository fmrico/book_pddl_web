;; Appendix B, template 5: a problem for the PDDL+ domain.
(define (problem courier-plus-p01)
  (:domain courier-plus)
  (:requirements :negative-preconditions)
  (:objects r1 - robot
            dock lobby lab - location
            sample1 - item)
  (:init
    (connected dock lobby) (connected lobby dock)
    (connected lobby lab) (connected lab lobby)
    (has-charger dock)
    (robot-at r1 dock) (powered r1)
    (in-fridge sample1)
    (= (battery r1) 8) (= (battery-capacity r1) 100)
    (= (drain-rate r1) 1) (= (charge-rate r1) 10)
    (= (temperature sample1) 4))
  (:goal (and (robot-at r1 lab) (powered r1)
              (>= (battery r1) 20)
              (not (in-fridge sample1))
              (not (spoiled sample1)))))
