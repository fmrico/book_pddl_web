;; Appendix B, template 1: a problem for the classical domain.
(define (problem courier-classical-p01)
  (:domain courier-classical)
  (:objects
    r1 - robot
    lobby pharmacy lab - location           ; dock is a constant
    meds1 meds2 - medicine
    sample1 - sample)
  (:init
    (connected dock lobby) (connected lobby dock)
    (connected lobby pharmacy) (connected pharmacy lobby)
    (connected lobby lab) (connected lab lobby)
    (restricted pharmacy) (sterile lab)
    (robot-at r1 dock) (free r1)
    (item-at meds1 pharmacy) (item-at meds2 pharmacy)
    (item-at sample1 lobby) (sealed sample1))   ; the rest: false
  (:goal (and
    (forall (?i - medicine) (item-at ?i lobby))
    (item-at sample1 lab)
    (not (contaminated sample1))            ; a negative goal
    (imply (has-keycard r1) (robot-at r1 dock)))))
