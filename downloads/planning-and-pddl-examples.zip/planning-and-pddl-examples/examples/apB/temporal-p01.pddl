;; Appendix B, template 3: a problem for the temporal domain.
(define (problem courier-temporal-p01)
  (:domain courier-temporal)
  (:objects r1 - robot
            dock lobby pharmacy - location
            meds1 - item)
  (:init
    (connected dock lobby) (connected lobby dock)
    (connected lobby pharmacy) (connected pharmacy lobby)
    (has-charger dock)
    (robot-at r1 dock) (idle r1)
    (item-at meds1 pharmacy)
    (is-open dock) (is-open lobby)
    ; timed initial literals: true at 30, false again at 300
    (at 30 (is-open pharmacy))
    (at 300 (not (is-open pharmacy)))
    (= (distance dock lobby) 4) (= (distance lobby dock) 4)
    (= (distance lobby pharmacy) 6)
    (= (distance pharmacy lobby) 6)
    (= (speed r1) 1)
    (= (battery r1) 5) (= (battery-capacity r1) 100)
    (= (drain-rate r1) 1) (= (charge-rate r1) 2))
  (:goal (and (item-at meds1 lobby)
              (reachable lobby dock)))
  (:metric minimize (total-time)))          ; the makespan
