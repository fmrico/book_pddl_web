;; Step L, encoding C: the battery counted in moves, with one
;; predicate per level (four moves at most, fixed in the domain).
(define (domain courier-moves-flags)
  (:requirements :strips :typing :negative-preconditions
                 :conditional-effects)

  (:types robot location item)

  (:predicates
    (connected ?from ?to - location)
    (robot-at ?r - robot ?l - location)
    (item-at ?i - item ?l - location)
    (carrying ?r - robot ?i - item)
    (free ?r - robot)
    (has-charger ?l - location)
    (battery-4 ?r - robot) (battery-3 ?r - robot)
    (battery-2 ?r - robot) (battery-1 ?r - robot)
    (battery-0 ?r - robot))

  (:action move
    :parameters (?r - robot ?from ?to - location)
    :precondition (and (robot-at ?r ?from) (connected ?from ?to)
                       (not (battery-0 ?r)))
    :effect (and
      (not (robot-at ?r ?from)) (robot-at ?r ?to)
      (when (battery-4 ?r)
        (and (not (battery-4 ?r)) (battery-3 ?r)))
      (when (battery-3 ?r)
        (and (not (battery-3 ?r)) (battery-2 ?r)))
      (when (battery-2 ?r)
        (and (not (battery-2 ?r)) (battery-1 ?r)))
      (when (battery-1 ?r)
        (and (not (battery-1 ?r)) (battery-0 ?r)))))

  (:action charge
    :parameters (?r - robot ?l - location)
    :precondition (and (robot-at ?r ?l) (has-charger ?l)
                       (not (battery-4 ?r)))
    :effect (and (battery-4 ?r)
                 (not (battery-3 ?r)) (not (battery-2 ?r))
                 (not (battery-1 ?r)) (not (battery-0 ?r))))

  (:action pick
    :parameters (?r - robot ?i - item ?l - location)
    :precondition (and (robot-at ?r ?l) (item-at ?i ?l) (free ?r))
    :effect (and (not (item-at ?i ?l)) (not (free ?r))
                 (carrying ?r ?i)))

  (:action drop
    :parameters (?r - robot ?i - item ?l - location)
    :precondition (and (robot-at ?r ?l) (carrying ?r ?i))
    :effect (and (not (carrying ?r ?i))
                 (item-at ?i ?l) (free ?r))))
