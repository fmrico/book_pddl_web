;; Encoding B with a battery of 100 moves: 101 level objects.
(define (problem moves-chain-p02)
  (:domain courier-moves-chain)
  (:objects
    r1 - robot
    lobby corridor pharmacy lab ward-a ward-b icu dock - location
    meds1 - item
    n0 n1 n2 n3 n4 n5 n6 n7 n8 n9 n10 n11 n12 n13 n14 n15 n16
    n17 n18 n19 n20 n21 n22 n23 n24 n25 n26 n27 n28 n29 n30 n31
    n32 n33 n34 n35 n36 n37 n38 n39 n40 n41 n42 n43 n44 n45 n46
    n47 n48 n49 n50 n51 n52 n53 n54 n55 n56 n57 n58 n59 n60 n61
    n62 n63 n64 n65 n66 n67 n68 n69 n70 n71 n72 n73 n74 n75 n76
    n77 n78 n79 n80 n81 n82 n83 n84 n85 n86 n87 n88 n89 n90 n91
    n92 n93 n94 n95 n96 n97 n98 n99 n100 - level)
  (:init
    (connected lobby corridor) (connected corridor lobby)
    (connected lobby pharmacy) (connected pharmacy lobby)
    (connected lobby dock) (connected dock lobby)
    (connected corridor lab) (connected lab corridor)
    (connected corridor ward-a) (connected ward-a corridor)
    (connected corridor ward-b) (connected ward-b corridor)
    (connected ward-b icu) (connected icu ward-b)
    (has-charger dock)
    (robot-at r1 dock) (free r1)
    (next n0 n1) (next n1 n2) (next n2 n3) (next n3 n4) (next n4
    n5) (next n5 n6) (next n6 n7) (next n7 n8) (next n8 n9)
    (next n9 n10) (next n10 n11) (next n11 n12) (next n12 n13)
    (next n13 n14) (next n14 n15) (next n15 n16) (next n16 n17)
    (next n17 n18) (next n18 n19) (next n19 n20) (next n20 n21)
    (next n21 n22) (next n22 n23) (next n23 n24) (next n24 n25)
    (next n25 n26) (next n26 n27) (next n27 n28) (next n28 n29)
    (next n29 n30) (next n30 n31) (next n31 n32) (next n32 n33)
    (next n33 n34) (next n34 n35) (next n35 n36) (next n36 n37)
    (next n37 n38) (next n38 n39) (next n39 n40) (next n40 n41)
    (next n41 n42) (next n42 n43) (next n43 n44) (next n44 n45)
    (next n45 n46) (next n46 n47) (next n47 n48) (next n48 n49)
    (next n49 n50) (next n50 n51) (next n51 n52) (next n52 n53)
    (next n53 n54) (next n54 n55) (next n55 n56) (next n56 n57)
    (next n57 n58) (next n58 n59) (next n59 n60) (next n60 n61)
    (next n61 n62) (next n62 n63) (next n63 n64) (next n64 n65)
    (next n65 n66) (next n66 n67) (next n67 n68) (next n68 n69)
    (next n69 n70) (next n70 n71) (next n71 n72) (next n72 n73)
    (next n73 n74) (next n74 n75) (next n75 n76) (next n76 n77)
    (next n77 n78) (next n78 n79) (next n79 n80) (next n80 n81)
    (next n81 n82) (next n82 n83) (next n83 n84) (next n84 n85)
    (next n85 n86) (next n86 n87) (next n87 n88) (next n88 n89)
    (next n89 n90) (next n90 n91) (next n91 n92) (next n92 n93)
    (next n93 n94) (next n94 n95) (next n95 n96) (next n96 n97)
    (next n97 n98) (next n98 n99) (next n99 n100)
    (battery-level r1 n100) (full-level r1 n100)
    (item-at meds1 pharmacy))
  (:goal (item-at meds1 ward-a)))
