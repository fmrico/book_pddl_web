;; A drip that adds a tenth of a milliliter at a time: a small
;; domain to see what happens with fractions and equality.
(define (domain drip)
  (:requirements :strips :numeric-fluents)

  (:functions (dose))    ; ml given so far

  (:action drip
    :parameters ()
    :precondition (< (dose) 1)
    :effect (increase (dose) 0.1)))
