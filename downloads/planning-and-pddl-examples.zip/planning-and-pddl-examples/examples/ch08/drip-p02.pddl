;; The same wish, asked with a tolerance: it has a plan.
(define (problem drip-p02)
  (:domain drip)
  (:init (= (dose) 0))
  (:goal (and (>= (dose) 0.29) (<= (dose) 0.31))))
