;; From Madrid to Valencia through Cuenca, starting almost dry.
(define (problem truck-p01)
  (:domain truck)
  (:objects
    t1 - truck
    madrid cuenca valencia - city)
  (:init
    (road madrid cuenca) (road cuenca madrid)
    (road cuenca valencia) (road valencia cuenca)
    (= (distance madrid cuenca) 170)
    (= (distance cuenca madrid) 170)
    (= (distance cuenca valencia) 200)
    (= (distance valencia cuenca) 200)
    (has-station madrid) (has-station cuenca)
    (truck-at t1 madrid)
    (= (fuel t1) 5) (= (tank t1) 60) (= (km-per-liter t1) 4))
  (:goal (truck-at t1 valencia)))
