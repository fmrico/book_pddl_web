;; Counting in a warehouse: units of each product go from the
;; shelf to a box. Units are counted, they are not objects.
(define (domain warehouse)
  (:requirements :strips :typing :numeric-fluents)

  (:types product)

  (:functions
    (stock ?p - product)    ; units on the shelf
    (batch ?p - product)    ; units that one restocking brings
    (packed ?p - product)   ; units already in the box
    (box-space))            ; units that still fit in the box

  (:action pack
    :parameters (?p - product)
    :precondition (and (>= (stock ?p) 1) (>= (box-space) 1))
    :effect (and (decrease (stock ?p) 1)
                 (increase (packed ?p) 1)
                 (decrease (box-space) 1)))

  ; the supplier only comes when the shelf is empty
  (:action restock
    :parameters (?p - product)
    :precondition (= (stock ?p) 0)
    :effect (increase (stock ?p) (batch ?p))))
