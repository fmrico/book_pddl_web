;; From 80 mg/ml down to 10 mg/ml or less in a tube of 10 ml,
;; keeping at least 4 ml to work with.
(define (problem dilution-p01)
  (:domain dilution)
  (:objects t1 - tube)
  (:init
    (= (concentration t1) 80) (= (volume t1) 2) (= (size t1) 10))
  (:goal (and (<= (concentration t1) 10) (>= (volume t1) 4))))
