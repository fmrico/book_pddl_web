;; No plan: the order asks for 7 units and the box holds 6.
(define (problem warehouse-p02)
  (:domain warehouse)
  (:objects gloves masks - product)
  (:init
    (= (stock gloves) 1) (= (batch gloves) 4)
    (= (stock masks) 5) (= (batch masks) 10)
    (= (packed gloves) 0) (= (packed masks) 0)
    (= (box-space) 6))
  (:goal (and (= (packed gloves) 3) (>= (packed masks) 4))))
