;; Diluting a sample in the lab: adding as much water as there
;; is liquid doubles the volume and halves the concentration.
(define (domain dilution)
  (:requirements :strips :typing :numeric-fluents)

  (:types tube)

  (:functions
    (concentration ?t - tube)   ; mg per ml
    (volume ?t - tube)          ; ml of liquid in the tube
    (size ?t - tube))           ; ml the tube holds

  (:action dilute
    :parameters (?t - tube)
    :precondition (<= (* 2 (volume ?t)) (size ?t))
    :effect (and (scale-up (volume ?t) 2)
                 (scale-down (concentration ?t) 2)))

  ; pour half of the liquid away: same concentration, less volume
  (:action discard-half
    :parameters (?t - tube)
    :precondition (>= (volume ?t) 2)
    :effect (scale-down (volume ?t) 2)))
