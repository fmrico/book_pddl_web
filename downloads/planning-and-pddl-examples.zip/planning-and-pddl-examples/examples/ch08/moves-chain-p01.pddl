;; A battery of four moves for a delivery that needs five (B).
(define (problem moves-chain-p01)
  (:domain courier-moves-chain)
  (:objects
    r1 - robot
    lobby corridor pharmacy lab ward-a ward-b icu dock - location
    meds1 - item
    n0 n1 n2 n3 n4 - level)
  (:init
    (connected lobby corridor) (connected corridor lobby)
    (connected lobby pharmacy) (connected pharmacy lobby)
    (connected lobby dock) (connected dock lobby)
    (connected corridor lab) (connected lab corridor)
    (connected corridor ward-a) (connected ward-a corridor)
    (connected corridor ward-b) (connected ward-b corridor)
    (connected ward-b icu) (connected icu ward-b)
    (has-charger dock)
    (robot-at r1 dock) (free r1)
    (next n0 n1) (next n1 n2) (next n2 n3) (next n3 n4)
    (battery-level r1 n4) (full-level r1 n4)
    (item-at meds1 pharmacy))
  (:goal (item-at meds1 ward-a)))
