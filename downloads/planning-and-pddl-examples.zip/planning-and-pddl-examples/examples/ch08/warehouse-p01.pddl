;; An order: exactly 3 units of gloves and at least 2 masks.
(define (problem warehouse-p01)
  (:domain warehouse)
  (:objects gloves masks - product)
  (:init
    (= (stock gloves) 1) (= (batch gloves) 4)
    (= (stock masks) 5) (= (batch masks) 10)
    (= (packed gloves) 0) (= (packed masks) 0)
    (= (box-space) 6))
  (:goal (and (= (packed gloves) 3) (>= (packed masks) 2))))
