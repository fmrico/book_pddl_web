;; The classic: jugs of 3 and 5 liters, measure exactly 4.
(define (problem jugs-p01)
  (:domain jugs)
  (:objects small big - jug)
  (:init
    (= (volume small) 3) (= (amount small) 0)
    (= (volume big) 5) (= (amount big) 0))
  (:goal (= (amount big) 4)))
