;; The water jugs: measure an amount of water with jugs that
;; have no marks. A jug can be filled, emptied or poured.
(define (domain jugs)
  (:requirements :strips :typing :equality
                 :negative-preconditions :numeric-fluents)

  (:types jug)

  (:functions
    (amount ?j - jug)    ; liters in the jug now
    (volume ?j - jug))   ; liters it holds when full

  (:action fill
    :parameters (?j - jug)
    :precondition (< (amount ?j) (volume ?j))
    :effect (assign (amount ?j) (volume ?j)))

  (:action empty
    :parameters (?j - jug)
    :precondition (> (amount ?j) 0)
    :effect (assign (amount ?j) 0))

  ; everything in ?from fits in ?to
  (:action pour-all
    :parameters (?from ?to - jug)
    :precondition (and
      (not (= ?from ?to))
      (> (amount ?from) 0)
      (<= (+ (amount ?from) (amount ?to)) (volume ?to)))
    :effect (and
      (increase (amount ?to) (amount ?from))
      (assign (amount ?from) 0)))

  ; ?to gets full and something stays in ?from
  (:action pour-until-full
    :parameters (?from ?to - jug)
    :precondition (and
      (not (= ?from ?to))
      (< (amount ?to) (volume ?to))
      (> (+ (amount ?from) (amount ?to)) (volume ?to)))
    :effect (and
      (decrease (amount ?from) (- (volume ?to) (amount ?to)))
      (assign (amount ?to) (volume ?to)))))
