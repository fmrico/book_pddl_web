;; A truck with a fuel tank: driving burns fuel according to
;; the length of the road, stations sell it 10 liters at a time.
(define (domain truck)
  (:requirements :strips :typing :numeric-fluents)

  (:types truck city)

  (:predicates
    (road ?from ?to - city)
    (truck-at ?t - truck ?c - city)
    (has-station ?c - city))

  (:functions
    (fuel ?t - truck)            ; liters in the tank
    (tank ?t - truck)            ; liters the tank holds
    (km-per-liter ?t - truck)    ; how far one liter takes it
    (distance ?from ?to - city)) ; km of road

  (:action drive
    :parameters (?t - truck ?from ?to - city)
    :precondition (and
      (truck-at ?t ?from) (road ?from ?to)
      (>= (fuel ?t) (/ (distance ?from ?to) (km-per-liter ?t))))
    :effect (and
      (not (truck-at ?t ?from)) (truck-at ?t ?to)
      (decrease (fuel ?t)
                (/ (distance ?from ?to) (km-per-liter ?t)))))

  (:action refuel
    :parameters (?t - truck ?c - city)
    :precondition (and
      (truck-at ?t ?c) (has-station ?c)
      (<= (+ (fuel ?t) 10) (tank ?t)))   ; 10 more must fit
    :effect (increase (fuel ?t) 10)))
