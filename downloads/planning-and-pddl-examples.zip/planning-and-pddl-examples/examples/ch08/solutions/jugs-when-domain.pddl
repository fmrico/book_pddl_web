;; Exercise 8.5.2: one pour action instead of two. Conditional
;; effects choose between "all of it fits" and "until full".
(define (domain jugs-when)
  (:requirements :strips :typing :equality
                 :negative-preconditions :conditional-effects
                 :numeric-fluents)

  (:types jug)

  (:functions
    (amount ?j - jug)
    (volume ?j - jug))

  (:action fill
    :parameters (?j - jug)
    :precondition (< (amount ?j) (volume ?j))
    :effect (assign (amount ?j) (volume ?j)))

  (:action empty
    :parameters (?j - jug)
    :precondition (> (amount ?j) 0)
    :effect (assign (amount ?j) 0))

  (:action pour
    :parameters (?from ?to - jug)
    :precondition (and
      (not (= ?from ?to))
      (> (amount ?from) 0)
      (< (amount ?to) (volume ?to)))
    :effect (and
      (when (<= (+ (amount ?from) (amount ?to)) (volume ?to))
        (and (increase (amount ?to) (amount ?from))
             (assign (amount ?from) 0)))
      (when (> (+ (amount ?from) (amount ?to)) (volume ?to))
        (and (decrease (amount ?from)
                       (- (volume ?to) (amount ?to)))
             (assign (amount ?to) (volume ?to)))))))
