;; Exercise 8.6.1: the weight of the meal was forgotten.
(define (problem courier-load-undefined)
  (:domain courier-load)
  (:objects
    r1 - robot
    lobby corridor pharmacy lab ward-a ward-b icu dock - location
    meds1 meds2 - medicine
    meal1 - meal)
  (:init
    (connected lobby corridor) (connected corridor lobby)
    (connected lobby pharmacy) (connected pharmacy lobby)
    (connected lobby dock) (connected dock lobby)
    (connected corridor lab) (connected lab corridor)
    (connected corridor ward-a) (connected ward-a corridor)
    (connected corridor ward-b) (connected ward-b corridor)
    (connected ward-b icu) (connected icu ward-b)
    (robot-at r1 lobby)
    (= (load r1) 0) (= (capacity r1) 5)
    (item-at meds1 lobby) (= (weight meds1) 2)
    (item-at meds2 lobby) (= (weight meds2) 2)
    (item-at meal1 lobby))
  (:goal (and (item-at meds1 ward-a) (item-at meds2 ward-a)
              (item-at meal1 ward-a))))
