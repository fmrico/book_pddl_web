;; Exercise 8.3.1: the two deliveries starting with half a charge.
(define (problem courier-battery-half)
  (:domain courier-battery)
  (:objects
    r1 - robot
    lobby corridor pharmacy lab ward-a ward-b icu dock - location
    meds1 sample1 - item)
  (:init
    (connected lobby corridor) (connected corridor lobby)
    (connected lobby pharmacy) (connected pharmacy lobby)
    (connected lobby dock) (connected dock lobby)
    (connected corridor lab) (connected lab corridor)
    (connected corridor ward-a) (connected ward-a corridor)
    (connected corridor ward-b) (connected ward-b corridor)
    (connected ward-b icu) (connected icu ward-b)
    ; distances in meters, one line per pair of rooms
    (= (distance lobby corridor) 10)
    (= (distance corridor lobby) 10)
    (= (distance lobby pharmacy) 6)
    (= (distance pharmacy lobby) 6)
    (= (distance lobby dock) 4) (= (distance dock lobby) 4)
    (= (distance corridor lab) 8) (= (distance lab corridor) 8)
    (= (distance corridor ward-a) 12)
    (= (distance ward-a corridor) 12)
    (= (distance corridor ward-b) 12)
    (= (distance ward-b corridor) 12)
    (= (distance ward-b icu) 5) (= (distance icu ward-b) 5)
    (has-charger dock)
    (robot-at r1 dock) (free r1)
    (= (battery r1) 50)
    (= (battery-capacity r1) 100)
    (= (consumption r1) 1.5)
    (item-at meds1 pharmacy) (item-at sample1 lab))
  (:goal (and (item-at meds1 ward-a) (item-at sample1 icu))))
