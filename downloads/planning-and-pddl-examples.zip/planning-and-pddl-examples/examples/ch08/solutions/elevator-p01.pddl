;; Exercise 8.5.4: three people go up to the second floor in an
;; elevator for two.
(define (problem elevator-p01)
  (:domain elevator)
  (:objects
    ana ben eva - person
    f0 f1 f2 - floor)
  (:init
    (above f0 f1) (above f1 f2)
    (lift-at f2)
    (person-at ana f0) (person-at ben f0) (person-at eva f0)
    (= (passengers) 0) (= (max-passengers) 2))
  (:goal (and (person-at ana f2) (person-at ben f2)
              (person-at eva f2))))
