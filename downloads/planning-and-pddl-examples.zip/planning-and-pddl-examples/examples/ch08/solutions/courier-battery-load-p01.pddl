;; Exercise 8.4.1: a meal of 5 kg and medicines of 2 kg from the
;; lobby to the ICU with a robot that uses 2 units per meter.
(define (problem courier-battery-load-p01)
  (:domain courier-battery-load)
  (:objects
    r1 - robot
    lobby corridor pharmacy lab ward-a ward-b icu dock - location
    meds1 meal1 - item)
  (:init
    (connected lobby corridor) (connected corridor lobby)
    (connected lobby pharmacy) (connected pharmacy lobby)
    (connected lobby dock) (connected dock lobby)
    (connected corridor lab) (connected lab corridor)
    (connected corridor ward-a) (connected ward-a corridor)
    (connected corridor ward-b) (connected ward-b corridor)
    (connected ward-b icu) (connected icu ward-b)
    ; distances in meters, one line per pair of rooms
    (= (distance lobby corridor) 10)
    (= (distance corridor lobby) 10)
    (= (distance lobby pharmacy) 6)
    (= (distance pharmacy lobby) 6)
    (= (distance lobby dock) 4) (= (distance dock lobby) 4)
    (= (distance corridor lab) 8) (= (distance lab corridor) 8)
    (= (distance corridor ward-a) 12)
    (= (distance ward-a corridor) 12)
    (= (distance corridor ward-b) 12)
    (= (distance ward-b corridor) 12)
    (= (distance ward-b icu) 5) (= (distance icu ward-b) 5)
    (has-charger dock)
    (robot-at r1 dock)
    (= (battery r1) 100)
    (= (battery-capacity r1) 100)
    (= (consumption r1) 2)
    (= (load r1) 0) (= (capacity r1) 8)
    (item-at meds1 lobby) (= (weight meds1) 2)
    (item-at meal1 lobby) (= (weight meal1) 5))
  (:goal (and (item-at meds1 icu) (item-at meal1 icu))))
