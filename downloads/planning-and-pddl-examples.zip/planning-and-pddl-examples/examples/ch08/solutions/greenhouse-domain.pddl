;; Exercise 8.8.3: a watering robot in a greenhouse. It carries
;; a tank, refills it at the tap and gives each bed its water.
(define (domain greenhouse)
  (:requirements :strips :typing :numeric-fluents)

  (:types place - object
          bed tap - place)

  (:predicates (robot-at ?p - place))

  (:functions
    (tank)               ; liters in the tank of the robot
    (tank-size)          ; liters the tank holds
    (need ?b - bed)      ; liters the bed still needs
    (dose))              ; liters given by one watering

  (:action go
    :parameters (?from ?to - place)
    :precondition (robot-at ?from)
    :effect (and (not (robot-at ?from)) (robot-at ?to)))

  (:action refill
    :parameters (?t - tap)
    :precondition (and (robot-at ?t) (< (tank) (tank-size)))
    :effect (assign (tank) (tank-size)))

  ; one dose at a time, and never more than the bed needs
  (:action water
    :parameters (?b - bed)
    :precondition (and (robot-at ?b)
                       (>= (tank) (dose))
                       (>= (need ?b) (dose)))
    :effect (and (decrease (tank) (dose))
                 (decrease (need ?b) (dose)))))
