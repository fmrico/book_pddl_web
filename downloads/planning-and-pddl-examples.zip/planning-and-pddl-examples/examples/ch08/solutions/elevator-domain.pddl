;; Exercise 8.5.4: an elevator that counts the people inside.
;; Who is inside is a fact; how many are inside is a number.
(define (domain elevator)
  (:requirements :strips :typing :numeric-fluents)

  (:types person floor)

  (:predicates
    (above ?lower ?upper - floor)   ; ?upper is right above
    (lift-at ?f - floor)
    (person-at ?p - person ?f - floor)
    (inside ?p - person))

  (:functions
    (passengers)       ; people inside now
    (max-passengers))  ; people that fit

  (:action up
    :parameters (?from ?to - floor)
    :precondition (and (lift-at ?from) (above ?from ?to))
    :effect (and (not (lift-at ?from)) (lift-at ?to)))

  (:action down
    :parameters (?from ?to - floor)
    :precondition (and (lift-at ?from) (above ?to ?from))
    :effect (and (not (lift-at ?from)) (lift-at ?to)))

  (:action board
    :parameters (?p - person ?f - floor)
    :precondition (and (lift-at ?f) (person-at ?p ?f)
                       (< (passengers) (max-passengers)))
    :effect (and (not (person-at ?p ?f)) (inside ?p)
                 (increase (passengers) 1)))

  (:action leave
    :parameters (?p - person ?f - floor)
    :precondition (and (lift-at ?f) (inside ?p))
    :effect (and (not (inside ?p)) (person-at ?p ?f)
                 (decrease (passengers) 1))))
