;; Exercise 8.8.1: three items for ward A and a robot with two
;; slots, whatever the items weigh.
(define (problem courier-slots-p01)
  (:domain courier-slots)
  (:objects
    r1 - robot
    lobby corridor pharmacy lab ward-a ward-b icu dock - location
    meds1 meds2 meal1 - item
    s1 s2 - slot)
  (:init
    (connected lobby corridor) (connected corridor lobby)
    (connected lobby pharmacy) (connected pharmacy lobby)
    (connected lobby dock) (connected dock lobby)
    (connected corridor lab) (connected lab corridor)
    (connected corridor ward-a) (connected ward-a corridor)
    (connected corridor ward-b) (connected ward-b corridor)
    (connected ward-b icu) (connected icu ward-b)
    (robot-at r1 lobby)
    (slot-of s1 r1) (empty s1) (slot-of s2 r1) (empty s2)
    (item-at meds1 lobby) (item-at meds2 lobby)
    (item-at meal1 lobby))
  (:goal (and (item-at meds1 ward-a) (item-at meds2 ward-a)
              (item-at meal1 ward-a))))
