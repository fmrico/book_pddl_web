;; Exercise 8.5.1: jugs without a tap or a sink. The liquid can
;; only be poured from one jug into another.
(define (domain jugs-closed)
  (:requirements :strips :typing :equality
                 :negative-preconditions :numeric-fluents)

  (:types jug)

  (:functions
    (amount ?j - jug)    ; liters in the jug now
    (volume ?j - jug))   ; liters it holds when full

  ; everything in ?from fits in ?to
  (:action pour-all
    :parameters (?from ?to - jug)
    :precondition (and
      (not (= ?from ?to))
      (> (amount ?from) 0)
      (<= (+ (amount ?from) (amount ?to)) (volume ?to)))
    :effect (and
      (increase (amount ?to) (amount ?from))
      (assign (amount ?from) 0)))

  ; ?to gets full and something stays in ?from
  (:action pour-until-full
    :parameters (?from ?to - jug)
    :precondition (and
      (not (= ?from ?to))
      (< (amount ?to) (volume ?to))
      (> (+ (amount ?from) (amount ?to)) (volume ?to)))
    :effect (and
      (decrease (amount ?from) (- (volume ?to) (amount ?to)))
      (assign (amount ?to) (volume ?to)))))
