;; Exercise 8.8.3: tomatoes need 6 liters and lettuces 4; the
;; tank holds 6 and starts empty.
(define (problem greenhouse-p01)
  (:domain greenhouse)
  (:objects
    tomatoes lettuces - bed
    tap1 - tap)
  (:init
    (robot-at tap1)
    (= (tank) 0) (= (tank-size) 6) (= (dose) 2)
    (= (need tomatoes) 6) (= (need lettuces) 4))
  (:goal (and (= (need tomatoes) 0) (= (need lettuces) 0))))
