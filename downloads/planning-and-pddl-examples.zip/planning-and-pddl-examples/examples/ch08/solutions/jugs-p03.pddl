;; Exercise 8.5.1: 8 liters of wine in a full jug, and two empty
;; jugs of 5 and 3. Split the wine in two equal parts.
(define (problem jugs-p03)
  (:domain jugs-closed)
  (:objects j8 j5 j3 - jug)
  (:init
    (= (volume j8) 8) (= (amount j8) 8)
    (= (volume j5) 5) (= (amount j5) 0)
    (= (volume j3) 3) (= (amount j3) 0))
  (:goal (and (= (amount j8) 4) (= (amount j5) 4))))
