;; Exercise 8.4.1: battery and load together. A loaded robot
;; uses more charge: 2 percent more per kilogram carried.
(define (domain courier-battery-load)
  (:requirements :strips :typing :numeric-fluents)

  (:types robot location item)

  (:predicates
    (connected ?from ?to - location)
    (robot-at ?r - robot ?l - location)
    (item-at ?i - item ?l - location)
    (carrying ?r - robot ?i - item)
    (has-charger ?l - location))

  (:functions
    (battery ?r - robot)
    (battery-capacity ?r - robot)
    (consumption ?r - robot)         ; per meter, when empty
    (distance ?from ?to - location)
    (load ?r - robot)                ; kg carried now
    (capacity ?r - robot)            ; kg it can carry
    (weight ?i - item))

  (:action move
    :parameters (?r - robot ?from ?to - location)
    :precondition (and
      (robot-at ?r ?from) (connected ?from ?to)
      (>= (battery ?r)
          (* (* (distance ?from ?to) (consumption ?r))
             (+ 1 (* 0.02 (load ?r))))))
    :effect (and
      (not (robot-at ?r ?from)) (robot-at ?r ?to)
      (decrease (battery ?r)
                (* (* (distance ?from ?to) (consumption ?r))
                   (+ 1 (* 0.02 (load ?r)))))))

  (:action charge
    :parameters (?r - robot ?l - location)
    :precondition (and
      (robot-at ?r ?l) (has-charger ?l)
      (< (battery ?r) (battery-capacity ?r)))
    :effect (assign (battery ?r) (battery-capacity ?r)))

  (:action pick
    :parameters (?r - robot ?i - item ?l - location)
    :precondition (and
      (robot-at ?r ?l) (item-at ?i ?l)
      (<= (+ (load ?r) (weight ?i)) (capacity ?r)))
    :effect (and
      (not (item-at ?i ?l)) (carrying ?r ?i)
      (increase (load ?r) (weight ?i))))

  (:action drop
    :parameters (?r - robot ?i - item ?l - location)
    :precondition (and (robot-at ?r ?l) (carrying ?r ?i))
    :effect (and
      (not (carrying ?r ?i)) (item-at ?i ?l)
      (decrease (load ?r) (weight ?i)))))
