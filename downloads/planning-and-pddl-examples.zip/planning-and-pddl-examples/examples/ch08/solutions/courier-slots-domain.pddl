;; Exercise 8.8.1: the capacity of the robot without numbers.
;; The robot has slots, and every item takes one of them
;; (the pattern "capacity with slots" of chapter 7).
(define (domain courier-slots)
  (:requirements :strips :typing)

  (:types robot location item slot)

  (:predicates
    (connected ?from ?to - location)
    (robot-at ?r - robot ?l - location)
    (item-at ?i - item ?l - location)
    (slot-of ?s - slot ?r - robot)
    (empty ?s - slot)
    (in-slot ?i - item ?s - slot))

  (:action move
    :parameters (?r - robot ?from ?to - location)
    :precondition (and (robot-at ?r ?from) (connected ?from ?to))
    :effect (and (not (robot-at ?r ?from))
                 (robot-at ?r ?to)))

  (:action pick
    :parameters (?r - robot ?i - item ?l - location ?s - slot)
    :precondition (and (robot-at ?r ?l) (item-at ?i ?l)
                       (slot-of ?s ?r) (empty ?s))
    :effect (and (not (item-at ?i ?l)) (not (empty ?s))
                 (in-slot ?i ?s)))

  (:action drop
    :parameters (?r - robot ?i - item ?l - location ?s - slot)
    :precondition (and (robot-at ?r ?l) (slot-of ?s ?r)
                       (in-slot ?i ?s))
    :effect (and (not (in-slot ?i ?s)) (empty ?s)
                 (item-at ?i ?l))))
