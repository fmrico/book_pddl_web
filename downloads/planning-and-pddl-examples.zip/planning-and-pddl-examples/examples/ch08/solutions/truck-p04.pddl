;; Exercise 8.4.3: the direct road is too long for the fuel on
;; board, and the only station is off the route, in Teruel.
(define (problem truck-p04)
  (:domain truck)
  (:objects
    t1 - truck
    cuenca teruel valencia - city)
  (:init
    (road cuenca valencia) (road valencia cuenca)
    (road cuenca teruel) (road teruel cuenca)
    (road teruel valencia) (road valencia teruel)
    (= (distance cuenca valencia) 200)
    (= (distance valencia cuenca) 200)
    (= (distance cuenca teruel) 150)
    (= (distance teruel cuenca) 150)
    (= (distance teruel valencia) 140)
    (= (distance valencia teruel) 140)
    (has-station teruel)
    (truck-at t1 cuenca)
    (= (fuel t1) 40) (= (tank t1) 60) (= (km-per-liter t1) 4))
  (:goal (truck-at t1 valencia)))
