;; The courier world with a load capacity: a robot carries
;; several items at once, up to a total weight in kilograms.
(define (domain courier-load)
  (:requirements :strips :typing :numeric-fluents)

  (:types
    robot location item - object
    medicine sample meal - item)

  (:predicates
    (connected ?from ?to - location)
    (robot-at ?r - robot ?l - location)
    (item-at ?i - item ?l - location)
    (carrying ?r - robot ?i - item))

  (:functions
    (load ?r - robot) - number      ; kg it carries now
    (capacity ?r - robot) - number  ; kg it can carry
    (weight ?i - item) - number)    ; kg of one item

  (:action move
    :parameters (?r - robot ?from ?to - location)
    :precondition (and (robot-at ?r ?from) (connected ?from ?to))
    :effect (and (not (robot-at ?r ?from))
                 (robot-at ?r ?to)))

  (:action pick
    :parameters (?r - robot ?i - item ?l - location)
    :precondition (and
      (robot-at ?r ?l) (item-at ?i ?l)
      ; the item must still fit
      (<= (+ (load ?r) (weight ?i)) (capacity ?r)))
    :effect (and
      (not (item-at ?i ?l)) (carrying ?r ?i)
      (increase (load ?r) (weight ?i))))

  (:action drop
    :parameters (?r - robot ?i - item ?l - location)
    :precondition (and (robot-at ?r ?l) (carrying ?r ?i))
    :effect (and
      (not (carrying ?r ?i)) (item-at ?i ?l)
      (decrease (load ?r) (weight ?i)))))
