;; A battery of four moves for a delivery that needs five (A).
(define (problem moves-number-p01)
  (:domain courier-moves-number)
  (:objects
    r1 - robot
    lobby corridor pharmacy lab ward-a ward-b icu dock - location
    meds1 - item)
  (:init
    (connected lobby corridor) (connected corridor lobby)
    (connected lobby pharmacy) (connected pharmacy lobby)
    (connected lobby dock) (connected dock lobby)
    (connected corridor lab) (connected lab corridor)
    (connected corridor ward-a) (connected ward-a corridor)
    (connected corridor ward-b) (connected ward-b corridor)
    (connected ward-b icu) (connected icu ward-b)
    (has-charger dock)
    (robot-at r1 dock) (free r1)
    (= (battery r1) 4) (= (battery-capacity r1) 4)
    (item-at meds1 pharmacy))
  (:goal (item-at meds1 ward-a)))
