;; Step L, encoding A: the battery counted in moves, as a number.
(define (domain courier-moves-number)
  (:requirements :strips :typing :numeric-fluents)

  (:types robot location item)

  (:predicates
    (connected ?from ?to - location)
    (robot-at ?r - robot ?l - location)
    (item-at ?i - item ?l - location)
    (carrying ?r - robot ?i - item)
    (free ?r - robot)
    (has-charger ?l - location))

  (:functions
    (battery ?r - robot)            ; moves left
    (battery-capacity ?r - robot))  ; moves of a full battery

  (:action move
    :parameters (?r - robot ?from ?to - location)
    :precondition (and (robot-at ?r ?from) (connected ?from ?to)
                       (>= (battery ?r) 1))
    :effect (and (not (robot-at ?r ?from)) (robot-at ?r ?to)
                 (decrease (battery ?r) 1)))

  (:action charge
    :parameters (?r - robot ?l - location)
    :precondition (and (robot-at ?r ?l) (has-charger ?l)
                       (< (battery ?r) (battery-capacity ?r)))
    :effect (assign (battery ?r) (battery-capacity ?r)))

  (:action pick
    :parameters (?r - robot ?i - item ?l - location)
    :precondition (and (robot-at ?r ?l) (item-at ?i ?l) (free ?r))
    :effect (and (not (item-at ?i ?l)) (not (free ?r))
                 (carrying ?r ?i)))

  (:action drop
    :parameters (?r - robot ?i - item ?l - location)
    :precondition (and (robot-at ?r ?l) (carrying ?r ?i))
    :effect (and (not (carrying ?r ?i))
                 (item-at ?i ?l) (free ?r))))
