;; The courier world with a battery: every move consumes
;; charge in proportion to the distance, the dock restores it.
(define (domain courier-battery)
  (:requirements :strips :typing :numeric-fluents)

  (:types robot location item)

  (:predicates
    (connected ?from ?to - location)
    (robot-at ?r - robot ?l - location)
    (item-at ?i - item ?l - location)
    (carrying ?r - robot ?i - item)
    (free ?r - robot)
    (has-charger ?l - location))

  (:functions
    (battery ?r - robot)             ; charge left, 0 to 100
    (battery-capacity ?r - robot)    ; the most it can hold
    (consumption ?r - robot)         ; charge used per meter
    (distance ?from ?to - location)) ; meters between rooms

  (:action move
    :parameters (?r - robot ?from ?to - location)
    :precondition (and
      (robot-at ?r ?from) (connected ?from ?to)
      ; enough charge for the whole stretch
      (>= (battery ?r)
          (* (distance ?from ?to) (consumption ?r))))
    :effect (and
      (not (robot-at ?r ?from)) (robot-at ?r ?to)
      (decrease (battery ?r)
                (* (distance ?from ?to) (consumption ?r)))))

  (:action charge
    :parameters (?r - robot ?l - location)
    :precondition (and
      (robot-at ?r ?l) (has-charger ?l)
      (< (battery ?r) (battery-capacity ?r)))
    :effect (and
      (assign (battery ?r) (battery-capacity ?r))))

  (:action pick
    :parameters (?r - robot ?i - item ?l - location)
    :precondition (and (robot-at ?r ?l) (item-at ?i ?l) (free ?r))
    :effect (and (not (item-at ?i ?l)) (not (free ?r))
                 (carrying ?r ?i)))

  (:action drop
    :parameters (?r - robot ?i - item ?l - location)
    :precondition (and (robot-at ?r ?l) (carrying ?r ?i))
    :effect (and (not (carrying ?r ?i))
                 (item-at ?i ?l) (free ?r))))
