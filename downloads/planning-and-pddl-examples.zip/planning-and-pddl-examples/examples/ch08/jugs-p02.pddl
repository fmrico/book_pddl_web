;; No plan: with jugs of 4 and 6 liters every amount is even.
(define (problem jugs-p02)
  (:domain jugs)
  (:objects small big - jug)
  (:init
    (= (volume small) 4) (= (amount small) 0)
    (= (volume big) 6) (= (amount big) 0))
  (:goal (= (amount big) 3)))
