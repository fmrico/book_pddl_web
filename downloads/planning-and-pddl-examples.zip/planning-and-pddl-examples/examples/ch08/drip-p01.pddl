;; No plan (!): three times 0.1 is not exactly 0.3 in a computer.
(define (problem drip-p01)
  (:domain drip)
  (:init (= (dose) 0))
  (:goal (= (dose) 0.3)))
