;; Step L, encoding B: the battery counted in moves, as a chain
;; of level objects linked by next (the pattern of chapter 7).
(define (domain courier-moves-chain)
  (:requirements :strips :typing :equality
                 :negative-preconditions)

  (:types robot location item level)

  (:predicates
    (connected ?from ?to - location)
    (robot-at ?r - robot ?l - location)
    (item-at ?i - item ?l - location)
    (carrying ?r - robot ?i - item)
    (free ?r - robot)
    (has-charger ?l - location)
    (battery-level ?r - robot ?v - level)  ; moves left
    (next ?lower ?higher - level)          ; ?higher = ?lower + 1
    (full-level ?r - robot ?v - level))    ; a full battery

  (:action move
    :parameters (?r - robot ?from ?to - location
                 ?before ?after - level)
    :precondition (and (robot-at ?r ?from) (connected ?from ?to)
                       (battery-level ?r ?before)
                       (next ?after ?before))
    :effect (and (not (robot-at ?r ?from)) (robot-at ?r ?to)
                 (not (battery-level ?r ?before))
                 (battery-level ?r ?after)))

  (:action charge
    :parameters (?r - robot ?l - location ?now ?full - level)
    :precondition (and (robot-at ?r ?l) (has-charger ?l)
                       (battery-level ?r ?now)
                       (full-level ?r ?full)
                       (not (= ?now ?full)))
    :effect (and (not (battery-level ?r ?now))
                 (battery-level ?r ?full)))

  (:action pick
    :parameters (?r - robot ?i - item ?l - location)
    :precondition (and (robot-at ?r ?l) (item-at ?i ?l) (free ?r))
    :effect (and (not (item-at ?i ?l)) (not (free ?r))
                 (carrying ?r ?i)))

  (:action drop
    :parameters (?r - robot ?i - item ?l - location)
    :precondition (and (robot-at ?r ?l) (carrying ?r ?i))
    :effect (and (not (carrying ?r ?i))
                 (item-at ?i ?l) (free ?r))))
