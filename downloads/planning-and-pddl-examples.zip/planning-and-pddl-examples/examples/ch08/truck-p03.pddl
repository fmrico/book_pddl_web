;; No plan: the tank only ever holds 5, 15, 25... minus what
;; the roads burn; the goal asks for a value never reached.
(define (problem truck-p03)
  (:domain truck)
  (:objects
    t1 - truck
    madrid cuenca - city)
  (:init
    (road madrid cuenca) (road cuenca madrid)
    (= (distance madrid cuenca) 160)
    (= (distance cuenca madrid) 160)
    (has-station madrid)
    (truck-at t1 madrid)
    (= (fuel t1) 5) (= (tank t1) 60) (= (km-per-liter t1) 4))
  (:goal (= (fuel t1) 12)))
