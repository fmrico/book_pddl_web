;; Two fuses and one match: both fit in its 5 seconds.
(define (problem cellar-p02)
  (:domain cellar)
  (:objects
    m1 - match
    f1 f2 - fuse)
  (:init
    (hand-free)
    (unused m1))
  (:goal (and (mended f1) (mended f2))))
