;; A coffee machine: the pump runs for as long as the planner
;; decides, 25 ml per second, once for each cup.
(define (domain coffee)
  (:requirements :strips :typing :durative-actions
                 :duration-inequalities :numeric-fluents)

  (:types cup)

  (:predicates
    (under-spout ?c - cup)
    (empty ?c - cup)
    (pump-off))

  (:functions
    (level ?c - cup)        ; ml in the cup
    (size ?c - cup)         ; ml that fit in the cup
    (flow))                 ; ml per second

  (:durative-action pour
    :parameters (?c - cup)
    :duration (and (>= ?duration 1)
                   (<= ?duration (/ (size ?c) (flow))))
    :condition (and (at start (pump-off))
                    (at start (under-spout ?c))
                    (at start (empty ?c))
                    (over all (under-spout ?c)))
    :effect (and (at start (not (pump-off)))
                 (at start (not (empty ?c)))
                 (at end (increase (level ?c)
                                   (* ?duration (flow))))
                 (at end (pump-off)))))
