;; An espresso: between 40 and 50 ml in the cup.
(define (problem coffee-p01)
  (:domain coffee)
  (:objects cup1 - cup)
  (:init
    (pump-off) (under-spout cup1) (empty cup1)
    (= (level cup1) 0) (= (size cup1) 250)
    (= (flow) 25))
  (:goal (and (>= (level cup1) 40) (<= (level cup1) 50))))
