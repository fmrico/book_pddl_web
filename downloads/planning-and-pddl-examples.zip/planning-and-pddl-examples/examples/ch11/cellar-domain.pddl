;; The match cellar: a fuse can be mended only by the light of a
;; match, and a match burns for 5 seconds.
(define (domain cellar)
  (:requirements :strips :typing :durative-actions)

  (:types match fuse)

  (:predicates
    (unused ?m - match)
    (lit ?m - match)
    (mended ?f - fuse)
    (hand-free))

  ;; There is light from the start of the action to its end.
  (:durative-action light
    :parameters (?m - match)
    :duration (= ?duration 5)
    :condition (at start (unused ?m))
    :effect (and (at start (not (unused ?m)))
                 (at start (lit ?m))
                 (at end (not (lit ?m)))))

  ;; Mending takes 2 seconds, all of them with light.
  (:durative-action mend
    :parameters (?f - fuse ?m - match)
    :duration (= ?duration 2)
    :condition (and (at start (hand-free))
                    (at start (lit ?m))
                    (over all (lit ?m)))
    :effect (and (at start (not (hand-free)))
                 (at end (mended ?f))
                 (at end (hand-free)))))
