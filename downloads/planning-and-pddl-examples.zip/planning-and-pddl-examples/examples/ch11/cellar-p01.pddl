;; One fuse to mend and one match.
(define (problem cellar-p01)
  (:domain cellar)
  (:objects
    m1 - match
    f1 - fuse)
  (:init
    (hand-free)
    (unused m1))
  (:goal (and (mended f1))))
