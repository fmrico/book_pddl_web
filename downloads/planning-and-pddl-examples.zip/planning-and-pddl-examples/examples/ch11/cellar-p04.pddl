;; Three fuses and two matches.
(define (problem cellar-p04)
  (:domain cellar)
  (:objects
    m1 m2 - match
    f1 f2 f3 - fuse)
  (:init
    (hand-free)
    (unused m1) (unused m2))
  (:goal (and (mended f1) (mended f2) (mended f3))))
