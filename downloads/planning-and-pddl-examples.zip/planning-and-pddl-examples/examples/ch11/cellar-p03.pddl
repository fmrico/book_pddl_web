;; Three fuses and one match: no plan, the light is too short.
(define (problem cellar-p03)
  (:domain cellar)
  (:objects
    m1 - match
    f1 f2 f3 - fuse)
  (:init
    (hand-free)
    (unused m1))
  (:goal (and (mended f1) (mended f2) (mended f3))))
