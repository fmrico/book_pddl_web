;; The classic puzzle: everything to the right bank.
(define (problem river-p01)
  (:domain river)
  (:objects left right - bank
            wolf goat cabbage - thing)
  (:init
    (boat-at left)
    (at wolf left) (at goat left) (at cabbage left)
    (eats wolf goat) (eats goat cabbage))
  (:goal (and (at wolf right) (at goat right)
              (at cabbage right))))
