;; Cheat test for the gripper: one ball in two rooms at once.
(define (problem gripper-buggy-p02)
  (:domain gripper-buggy)
  (:objects rooma roomb - room
            ball1 - ball
            left right - gripper)
  (:init
    (robby-at rooma) (free left) (free right)
    (ball-at ball1 rooma))
  (:goal (and (ball-at ball1 rooma) (ball-at ball1 roomb))))
