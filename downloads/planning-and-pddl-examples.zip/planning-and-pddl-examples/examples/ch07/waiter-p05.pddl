;; A dead end as initial state: the tray is full of main
;; courses, and the starters wait on the pass.
(define (problem waiter-p05)
  (:domain waiter)
  (:objects t1 t2 - place
            soup1 fish1 salad2 pasta2 - dish
            s1 s2 - slot)
  (:init
    (waiter-at pass)
    (on-tray fish1 s1) (on-tray pasta2 s2)
    (ready soup1) (ready salad2)
    (ordered soup1 t1) (ordered fish1 t1)
    (ordered salad2 t2) (ordered pasta2 t2)
    (before soup1 fish1) (before salad2 pasta2))
  (:goal (and (served soup1) (served fish1)
              (served salad2) (served pasta2))))
