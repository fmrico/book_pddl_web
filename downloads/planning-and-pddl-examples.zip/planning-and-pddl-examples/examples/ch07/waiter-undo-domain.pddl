;; The waiter with an inverse for load: a dish can go back
;; from the tray to the pass.
(define (domain waiter-undo)
  (:requirements :strips :typing :equality
                 :negative-preconditions
                 :disjunctive-preconditions
                 :universal-preconditions)

  (:types place dish slot)

  (:constants pass - place)         ; where the cook leaves dishes

  (:predicates
    (waiter-at ?p - place)
    (ready ?d - dish)               ; the dish waits on the pass
    (on-tray ?d - dish ?s - slot)
    (empty ?s - slot)               ; a free place of the tray
    (served ?d - dish)              ; the dish is on its table
    (ordered ?d - dish ?t - place)  ; static: the table of ?d
    (before ?a ?b - dish))          ; static: ?a goes before ?b

  ; The dining room is open: any place is one move away.
  (:action move
    :parameters (?from ?to - place)
    :precondition (and (waiter-at ?from) (not (= ?from ?to)))
    :effect (and (not (waiter-at ?from)) (waiter-at ?to)))

  (:action load
    :parameters (?d - dish ?s - slot)
    :precondition (and (waiter-at pass) (ready ?d) (empty ?s))
    :effect (and (not (ready ?d)) (not (empty ?s))
                 (on-tray ?d ?s)))

  ; The inverse of load: same places, effects turned around.
  (:action unload
    :parameters (?d - dish ?s - slot)
    :precondition (and (waiter-at pass) (on-tray ?d ?s))
    :effect (and (ready ?d) (empty ?s)
                 (not (on-tray ?d ?s))))

  ; A dish is served at its table, after the dishes before it.
  (:action serve
    :parameters (?d - dish ?s - slot ?t - place)
    :precondition (and (waiter-at ?t) (on-tray ?d ?s)
                       (ordered ?d ?t)
                       (forall (?e - dish)
                         (imply (before ?e ?d) (served ?e))))
    :effect (and (not (on-tray ?d ?s)) (empty ?s)
                 (served ?d))))
