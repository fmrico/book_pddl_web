;; Typical: two tables, a starter and a main course each.
(define (problem waiter-idle-p02)
  (:domain waiter-idle)
  (:objects t1 t2 - place
            soup1 fish1 salad2 pasta2 - dish
            s1 s2 - slot)
  (:init
    (waiter-at pass) (empty s1) (empty s2)
    (ready soup1) (ready fish1) (ready salad2) (ready pasta2)
    (ordered soup1 t1) (ordered fish1 t1)
    (ordered salad2 t2) (ordered pasta2 t2)
    (before soup1 fish1) (before salad2 pasta2))
  (:goal (and (served soup1) (served fish1)
              (served salad2) (served pasta2))))
