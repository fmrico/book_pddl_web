;; WRONG: the goal is already true in the initial state. The
;; line (served soup1) was copied into :init by mistake.
(define (problem waiter-done-p01)
  (:domain waiter)
  (:objects t1 - place
            soup1 - dish
            s1 s2 - slot)
  (:init
    (waiter-at pass) (empty s1) (empty s2)
    (ready soup1) (ordered soup1 t1)
    (served soup1))
  (:goal (served soup1)))
