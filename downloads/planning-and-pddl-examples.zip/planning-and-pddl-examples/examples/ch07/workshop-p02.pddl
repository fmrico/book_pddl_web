;; WRONG: two tokens in the initial state. The phases are all
;; on at once and order nothing.
(define (problem workshop-p02)
  (:domain workshop)
  (:objects seat leg1 leg2 - part)
  (:init
    (now cutting) (now joining) (now painting)
    (follows joining cutting) (follows painting joining))
  (:goal (and (painted seat) (painted leg1) (painted leg2))))
