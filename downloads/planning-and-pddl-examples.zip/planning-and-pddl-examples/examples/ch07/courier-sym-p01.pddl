;; Take the medicines from the pharmacy to ward A. The map has
;; seven facts, one for each connection.
(define (problem courier-sym-p01)
  (:domain courier-sym)
  (:objects
    r1 - robot
    lobby corridor pharmacy lab ward-a ward-b icu dock - location
    meds1 - item)
  (:init
    (connected lobby corridor) (connected lobby pharmacy)
    (connected lobby dock) (connected corridor lab)
    (connected corridor ward-a) (connected corridor ward-b)
    (connected ward-b icu)
    (robot-at r1 dock) (free r1)
    (item-at meds1 pharmacy))
  (:goal (item-at meds1 ward-a)))
