;; A wolf that also eats cabbage: one more fact, and no plan.
(define (problem river-p02)
  (:domain river)
  (:objects left right - bank
            wolf goat cabbage - thing)
  (:init
    (boat-at left)
    (at wolf left) (at goat left) (at cabbage left)
    (eats wolf goat) (eats goat cabbage) (eats wolf cabbage))
  (:goal (and (at wolf right) (at goat right)
              (at cabbage right))))
