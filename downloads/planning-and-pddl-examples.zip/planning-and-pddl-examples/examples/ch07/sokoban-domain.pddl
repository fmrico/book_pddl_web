;; Sokoban: the player pushes boxes over a grid. A push cannot
;; be undone: there is no pull.
(define (domain sokoban)
  (:requirements :strips :typing :negative-preconditions)

  (:types cell dir)

  (:predicates
    (adjacent ?a ?b - cell ?d - dir)  ; static: ?b is next to ?a
                                      ; in direction ?d
    (player-at ?c - cell)
    (box-at ?c - cell))               ; boxes have no names

  (:action walk
    :parameters (?from ?to - cell ?d - dir)
    :precondition (and (player-at ?from) (adjacent ?from ?to ?d)
                       (not (box-at ?to)))
    :effect (and (not (player-at ?from)) (player-at ?to)))

  ; Three cells in a line: the player, the box, the cell behind.
  (:action push
    :parameters (?p ?from ?to - cell ?d - dir)
    :precondition (and (player-at ?p) (box-at ?from)
                       (adjacent ?p ?from ?d)
                       (adjacent ?from ?to ?d)
                       (not (box-at ?to)))
    :effect (and (not (player-at ?p)) (player-at ?from)
                 (not (box-at ?from)) (box-at ?to))))
