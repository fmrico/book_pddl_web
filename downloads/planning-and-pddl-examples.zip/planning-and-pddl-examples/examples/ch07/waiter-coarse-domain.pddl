;; The waiter in one action: a dish goes from the pass to its
;; table. No tray, no trips.
(define (domain waiter-coarse)
  (:requirements :strips :typing :disjunctive-preconditions
                 :universal-preconditions)

  (:types place dish)

  (:predicates
    (ready ?d - dish)
    (served ?d - dish)
    (ordered ?d - dish ?t - place)
    (before ?a ?b - dish))

  (:action deliver
    :parameters (?d - dish ?t - place)
    :precondition (and (ready ?d) (ordered ?d ?t)
                       (forall (?e - dish)
                         (imply (before ?e ?d) (served ?e))))
    :effect (and (not (ready ?d)) (served ?d))))
