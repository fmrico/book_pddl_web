;; The courier world with one keycard for the restricted
;; rooms: a resource that only one robot can hold.
(define (domain courier-keycard)
  (:requirements :strips :typing :negative-preconditions
                 :disjunctive-preconditions)

  (:types robot location item)

  (:predicates
    (connected ?from ?to - location)
    (robot-at ?r - robot ?l - location)
    (item-at ?i - item ?l - location)
    (carrying ?r - robot ?i - item)
    (free ?r - robot)
    (restricted ?l - location)      ; static: needs the keycard
    (has-keycard ?r - robot)
    (keycard-at ?l - location))     ; the card hangs here

  (:action move
    :parameters (?r - robot ?from ?to - location)
    :precondition (and (robot-at ?r ?from) (connected ?from ?to)
                       (or (not (restricted ?to))
                           (has-keycard ?r)))
    :effect (and (not (robot-at ?r ?from))
                 (robot-at ?r ?to)))

  (:action pick
    :parameters (?r - robot ?i - item ?l - location)
    :precondition (and (robot-at ?r ?l) (item-at ?i ?l) (free ?r))
    :effect (and (not (item-at ?i ?l)) (not (free ?r))
                 (carrying ?r ?i)))

  (:action drop
    :parameters (?r - robot ?i - item ?l - location)
    :precondition (and (robot-at ?r ?l) (carrying ?r ?i))
    :effect (and (not (carrying ?r ?i))
                 (item-at ?i ?l) (free ?r)))

  ; Acquire: the card leaves its hook, so nobody else can
  ; take it.
  (:action take-keycard
    :parameters (?r - robot ?l - location)
    :precondition (and (robot-at ?r ?l) (keycard-at ?l))
    :effect (and (not (keycard-at ?l)) (has-keycard ?r)))

  ; Release: the card is available again, here.
  (:action leave-keycard
    :parameters (?r - robot ?l - location)
    :precondition (and (robot-at ?r ?l) (has-keycard ?r))
    :effect (and (not (has-keycard ?r)) (keycard-at ?l))))
