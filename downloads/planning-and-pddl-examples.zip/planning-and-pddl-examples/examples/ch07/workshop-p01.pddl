;; A stool: the seat and two legs, cut, joined and painted.
(define (problem workshop-p01)
  (:domain workshop)
  (:objects seat leg1 leg2 - part)
  (:init
    (now cutting)
    (follows joining cutting) (follows painting joining))
  (:goal (and (painted seat) (painted leg1) (painted leg2))))
