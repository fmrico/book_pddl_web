;; WRONG: the chain lost a link. The tray was meant for two
;; dishes and holds one.
(define (problem waiter-count-p03)
  (:domain waiter-count)
  (:objects t1 t2 - place
            soup1 fish1 salad2 pasta2 - dish
            n0 n1 n2 - count)
  (:init
    (waiter-at pass)
    (tray-count n0) (next n0 n1)
    (ready soup1) (ready fish1) (ready salad2) (ready pasta2)
    (ordered soup1 t1) (ordered fish1 t1)
    (ordered salad2 t2) (ordered pasta2 t2)
    (before soup1 fish1) (before salad2 pasta2))
  (:goal (and (served soup1) (served fish1)
              (served salad2) (served pasta2))))
