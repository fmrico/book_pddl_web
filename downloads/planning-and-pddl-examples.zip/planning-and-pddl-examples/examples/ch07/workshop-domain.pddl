;; A workshop that works in phases: all the cutting, then all
;; the joining, then all the painting. A token says which
;; phase is on.
(define (domain workshop)
  (:requirements :strips :typing :negative-preconditions)

  (:types part phase)

  (:constants cutting joining painting - phase)

  (:predicates
    (now ?p - phase)                ; the token: the phase on
    (follows ?b ?a - phase)         ; static: ?b comes after ?a
    (cut ?x - part)
    (joined ?x - part)
    (painted ?x - part))

  (:action cut
    :parameters (?x - part)
    :precondition (and (now cutting) (not (cut ?x)))
    :effect (cut ?x))

  (:action join
    :parameters (?x - part)
    :precondition (and (now joining) (cut ?x) (not (joined ?x)))
    :effect (joined ?x))

  (:action paint
    :parameters (?x - part)
    :precondition (and (now painting) (joined ?x)
                       (not (painted ?x)))
    :effect (painted ?x))

  ; The token moves forward and never comes back.
  (:action advance
    :parameters (?a ?b - phase)
    :precondition (and (now ?a) (follows ?b ?a))
    :effect (and (not (now ?a)) (now ?b))))
