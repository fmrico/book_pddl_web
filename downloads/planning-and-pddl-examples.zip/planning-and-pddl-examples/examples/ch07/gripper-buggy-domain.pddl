;; WRONG (Exercise 7.5.1): a robot with two grippers carries
;; balls between rooms. Three anti-patterns hide in this file.
(define (domain gripper-buggy)
  (:requirements :strips :typing)

  (:types room ball gripper)

  (:predicates
    (robby-at ?r - room)
    (ball-at ?b - ball ?r - room)
    (holding ?g - gripper ?b - ball)
    (free ?g - gripper)
    (busy ?g - gripper))

  (:action move
    :parameters (?from ?to - room ?g - gripper)
    :precondition (robby-at ?from)
    :effect (and (not (robby-at ?from)) (robby-at ?to)))

  (:action pick
    :parameters (?b - ball ?r - room ?g - gripper)
    :precondition (and (robby-at ?r) (ball-at ?b ?r) (free ?g))
    :effect (and (holding ?g ?b) (busy ?g) (not (free ?g))))

  (:action drop
    :parameters (?b - ball ?r - room ?g - gripper)
    :precondition (and (robby-at ?r) (holding ?g ?b))
    :effect (and (ball-at ?b ?r) (not (holding ?g ?b))
                 (free ?g))))
