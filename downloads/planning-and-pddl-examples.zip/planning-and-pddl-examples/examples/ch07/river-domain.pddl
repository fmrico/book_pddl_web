;; The farmer, the wolf, the goat and the cabbage. The boat is
;; where the farmer is; who eats whom is data of the problem.
(define (domain river)
  (:requirements :strips :typing :equality
                 :negative-preconditions
                 :existential-preconditions)

  (:types bank thing)

  (:predicates
    (boat-at ?b - bank)             ; the farmer and the boat
    (at ?x - thing ?b - bank)
    (eats ?a ?b - thing))           ; static: ?a eats ?b if alone

  ; The farmer crosses alone: nothing may be eaten behind him.
  (:action cross-alone
    :parameters (?from ?to - bank)
    :precondition (and (boat-at ?from) (not (= ?from ?to))
      (not (exists (?a ?b - thing)
             (and (eats ?a ?b) (at ?a ?from) (at ?b ?from)))))
    :effect (and (not (boat-at ?from)) (boat-at ?to)))

  ; The farmer crosses with ?x: nothing may be eaten among
  ; the things that stay.
  (:action cross-with
    :parameters (?x - thing ?from ?to - bank)
    :precondition (and (boat-at ?from) (at ?x ?from)
                       (not (= ?from ?to))
      (not (exists (?a ?b - thing)
             (and (eats ?a ?b) (at ?a ?from) (at ?b ?from)
                  (not (= ?a ?x)) (not (= ?b ?x))))))
    :effect (and (not (boat-at ?from)) (boat-at ?to)
                 (not (at ?x ?from)) (at ?x ?to))))
