;; Cheat test: both robots inside the narrow pharmacy. No plan.
(define (problem courier-narrow-p02)
  (:domain courier-narrow)
  (:objects
    r1 r2 - robot
    lobby corridor pharmacy lab ward-a ward-b icu dock - location)
  (:init
    (connected lobby corridor) (connected corridor lobby)
    (connected lobby pharmacy) (connected pharmacy lobby)
    (connected lobby dock) (connected dock lobby)
    (connected corridor lab) (connected lab corridor)
    (connected corridor ward-a) (connected ward-a corridor)
    (connected corridor ward-b) (connected ward-b corridor)
    (connected ward-b icu) (connected icu ward-b)
    (narrow pharmacy)
    (robot-at r1 lobby) (free r1)
    (robot-at r2 lobby) (free r2))
  (:goal (and (robot-at r1 pharmacy) (robot-at r2 pharmacy))))
