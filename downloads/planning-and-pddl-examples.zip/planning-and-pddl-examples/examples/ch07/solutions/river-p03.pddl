;; Solution 7.2.1: a fox, a chicken, a sack of grain and a dog
;; that keeps the fox quiet... by eating nothing. Only data.
(define (problem river-p03)
  (:domain river)
  (:objects left right - bank
            fox chicken grain dog - thing)
  (:init
    (boat-at left)
    (at fox left) (at chicken left) (at grain left)
    (at dog left)
    (eats fox chicken) (eats chicken grain))
  (:goal (and (at fox right) (at chicken right)
              (at grain right) (at dog right))))
