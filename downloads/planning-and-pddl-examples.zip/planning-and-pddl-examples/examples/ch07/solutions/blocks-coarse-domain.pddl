;; Solution 7.4.2: the blocks world with coarse actions. A
;; block goes from where it is to where it must be in one step;
;; the hand is not modeled.
(define (domain blocks-coarse)
  (:requirements :strips :typing :equality
                 :negative-preconditions)

  (:types block)

  (:predicates
    (on ?x ?y - block)
    (on-table ?x - block)
    (clear ?x - block))

  (:action move-to-block
    :parameters (?x ?from ?to - block)
    :precondition (and (on ?x ?from) (clear ?x) (clear ?to)
                       (not (= ?x ?to)))
    :effect (and (not (on ?x ?from)) (on ?x ?to)
                 (clear ?from) (not (clear ?to))))

  (:action move-to-table
    :parameters (?x ?from - block)
    :precondition (and (on ?x ?from) (clear ?x))
    :effect (and (not (on ?x ?from)) (on-table ?x)
                 (clear ?from)))

  (:action move-from-table
    :parameters (?x ?to - block)
    :precondition (and (on-table ?x) (clear ?x) (clear ?to)
                       (not (= ?x ?to)))
    :effect (and (not (on-table ?x)) (on ?x ?to)
                 (not (clear ?to)))))
