;; Solution 7.3.2: the patrol without the action wait.
(define (domain patrol-nowait)
  (:requirements :strips :typing :negative-preconditions)

  (:types cell agent)

  (:constants robot machine - agent)

  (:predicates
    (turn ?a - agent)               ; the token: who moves now
    (robot-at ?c - cell)
    (machine-at ?c - cell)
    (connected ?a ?b - cell)        ; static
    (route ?a ?b - cell))           ; static: the machine's round

  ; The robot's turn: one step, never into the machine.
  (:action move
    :parameters (?from ?to - cell)
    :precondition (and (turn robot) (robot-at ?from)
                       (connected ?from ?to)
                       (not (machine-at ?to)))
    :effect (and (not (robot-at ?from)) (robot-at ?to)
                 (not (turn robot)) (turn machine)))

  ; The machine's turn: the only thing that can happen. If the
  ; robot stands in its way, nothing can, and the plan dies.
  (:action machine-step
    :parameters (?from ?to - cell)
    :precondition (and (turn machine) (machine-at ?from)
                       (route ?from ?to) (not (robot-at ?to)))
    :effect (and (not (machine-at ?from)) (machine-at ?to)
                 (not (turn machine)) (turn robot))))
