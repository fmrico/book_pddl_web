;; The hall is a ring of four cells, h1 to h4. The robot goes
;; from the door (next to h1) to the exit (next to h3); the
;; machine starts in h1 and goes h1, h2, h3, h4, h1...
(define (problem patrol-nowait-p01)
  (:domain patrol-nowait)
  (:objects door h1 h2 h3 h4 exit - cell)
  (:init
    (connected door h1) (connected h1 door)
    (connected h1 h2) (connected h2 h1)
    (connected h2 h3) (connected h3 h2)
    (connected h3 h4) (connected h4 h3)
    (connected h4 h1) (connected h1 h4)
    (connected h3 exit) (connected exit h3)
    (route h1 h2) (route h2 h3) (route h3 h4) (route h4 h1)
    (robot-at door) (machine-at h1)
    (turn robot))
  (:goal (robot-at exit)))
