;; Two robots must each bring an item out of the pharmacy,
;; where only one of them fits.
(define (problem courier-narrow-p01)
  (:domain courier-narrow)
  (:objects
    r1 r2 - robot
    lobby corridor pharmacy lab ward-a ward-b icu dock - location
    meds1 meds2 - item)
  (:init
    (connected lobby corridor) (connected corridor lobby)
    (connected lobby pharmacy) (connected pharmacy lobby)
    (connected lobby dock) (connected dock lobby)
    (connected corridor lab) (connected lab corridor)
    (connected corridor ward-a) (connected ward-a corridor)
    (connected corridor ward-b) (connected ward-b corridor)
    (connected ward-b icu) (connected icu ward-b)
    (narrow pharmacy)
    (robot-at r1 lobby) (free r1)
    (robot-at r2 lobby) (free r2)
    (item-at meds1 pharmacy) (item-at meds2 pharmacy))
  (:goal (and (carrying r1 meds1) (carrying r2 meds2)
              (robot-at r1 lobby) (robot-at r2 lobby))))
