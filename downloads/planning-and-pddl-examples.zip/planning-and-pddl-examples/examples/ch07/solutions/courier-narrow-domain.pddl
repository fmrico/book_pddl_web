;; Solution 7.3.3: rooms where only one robot fits. The room
;; is a resource: entering takes it, leaving gives it back.
(define (domain courier-narrow)
  (:requirements :strips :typing :negative-preconditions
                 :disjunctive-preconditions)

  (:types robot location item)

  (:predicates
    (connected ?from ?to - location)
    (robot-at ?r - robot ?l - location)
    (item-at ?i - item ?l - location)
    (carrying ?r - robot ?i - item)
    (free ?r - robot)
    (narrow ?l - location)          ; static: one robot fits
    (taken ?l - location))          ; a robot is inside

  (:action move
    :parameters (?r - robot ?from ?to - location)
    :precondition (and (robot-at ?r ?from) (connected ?from ?to)
                       (not (narrow ?from)) (not (narrow ?to)))
    :effect (and (not (robot-at ?r ?from))
                 (robot-at ?r ?to)))

  ; Acquire the room on the way in...
  (:action enter
    :parameters (?r - robot ?from ?to - location)
    :precondition (and (robot-at ?r ?from) (connected ?from ?to)
                       (narrow ?to) (not (taken ?to)))
    :effect (and (not (robot-at ?r ?from)) (robot-at ?r ?to)
                 (taken ?to)))

  ; ...and release it on the way out.
  (:action leave
    :parameters (?r - robot ?from ?to - location)
    :precondition (and (robot-at ?r ?from) (connected ?from ?to)
                       (narrow ?from) (not (narrow ?to)))
    :effect (and (not (robot-at ?r ?from)) (robot-at ?r ?to)
                 (not (taken ?from))))

  (:action pick
    :parameters (?r - robot ?i - item ?l - location)
    :precondition (and (robot-at ?r ?l) (item-at ?i ?l) (free ?r))
    :effect (and (not (item-at ?i ?l)) (not (free ?r))
                 (carrying ?r ?i)))

  (:action drop
    :parameters (?r - robot ?i - item ?l - location)
    :precondition (and (robot-at ?r ?l) (carrying ?r ?i))
    :effect (and (not (carrying ?r ?i))
                 (item-at ?i ?l) (free ?r))))
