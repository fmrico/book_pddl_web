;; Typical: three cars to the north shore, one to the south.
(define (problem ferry-p01)
  (:domain ferry)
  (:objects south north - shore
            car1 car2 car3 car4 - car
            n0 n1 n2 - count)
  (:init
    (ferry-at south) (load n0) (next n0 n1) (next n1 n2)
    (car-at car1 south) (car-at car2 south) (car-at car3 south)
    (car-at car4 north))
  (:goal (and (car-at car1 north) (car-at car2 north)
              (car-at car3 north) (car-at car4 south))))
