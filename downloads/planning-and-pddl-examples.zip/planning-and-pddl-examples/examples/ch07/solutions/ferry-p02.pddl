;; Cheat test: three cars aboard a ferry for two. No plan.
(define (problem ferry-p02)
  (:domain ferry)
  (:objects south north - shore
            car1 car2 car3 - car
            n0 n1 n2 - count)
  (:init
    (ferry-at south) (load n0) (next n0 n1) (next n1 n2)
    (car-at car1 south) (car-at car2 south) (car-at car3 south))
  (:goal (and (aboard car1) (aboard car2) (aboard car3))))
