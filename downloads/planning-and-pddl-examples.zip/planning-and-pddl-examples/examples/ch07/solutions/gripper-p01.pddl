;; Four balls from room a to room b.
(define (problem gripper-p01)
  (:domain gripper)
  (:objects rooma roomb - room
            ball1 ball2 ball3 ball4 - ball
            left right - gripper)
  (:init
    (robby-at rooma) (free left) (free right)
    (ball-at ball1 rooma) (ball-at ball2 rooma)
    (ball-at ball3 rooma) (ball-at ball4 rooma))
  (:goal (and (ball-at ball1 roomb) (ball-at ball2 roomb)
              (ball-at ball3 roomb) (ball-at ball4 roomb))))
