;; Solution 7.6.1: the room with its grid complete; the box in
;; c22 goes up to c12.
(define (problem sokoban-p04)
  (:domain sokoban)
  (:objects
    c11 c12 c13 c14 c21 c22 c23 c24 c31 c32 c33 c34 - cell
    north south east west - dir)
  (:init
    (adjacent c11 c12 east) (adjacent c12 c11 west)
    (adjacent c11 c21 south) (adjacent c21 c11 north)
    (adjacent c12 c13 east) (adjacent c13 c12 west)
    (adjacent c12 c22 south) (adjacent c22 c12 north)
    (adjacent c13 c14 east) (adjacent c14 c13 west)
    (adjacent c13 c23 south) (adjacent c23 c13 north)
    (adjacent c14 c24 south) (adjacent c24 c14 north)
    (adjacent c21 c22 east) (adjacent c22 c21 west)
    (adjacent c21 c31 south) (adjacent c31 c21 north)
    (adjacent c22 c23 east) (adjacent c23 c22 west)
    (adjacent c22 c32 south) (adjacent c32 c22 north)
    (adjacent c23 c24 east) (adjacent c24 c23 west)
    (adjacent c23 c33 south) (adjacent c33 c23 north)
    (adjacent c24 c34 south) (adjacent c34 c24 north)
    (adjacent c31 c32 east) (adjacent c32 c31 west)
    (adjacent c32 c33 east) (adjacent c33 c32 west)
    (adjacent c33 c34 east) (adjacent c34 c33 west)
    (player-at c11) (box-at c22))
  (:goal (box-at c12)))
