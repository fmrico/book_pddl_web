;; Solution 7.1.2: three courses for one table. Only data: the
;; domain is the one of the chapter.
(define (problem waiter-dessert-p01)
  (:domain waiter)
  (:objects t1 - place
            soup1 fish1 cake1 - dish
            s1 s2 - slot)
  (:init
    (waiter-at pass) (empty s1) (empty s2)
    (ready soup1) (ready fish1) (ready cake1)
    (ordered soup1 t1) (ordered fish1 t1) (ordered cake1 t1)
    (before soup1 fish1) (before fish1 cake1))
  (:goal (and (served soup1) (served fish1) (served cake1))))
