;; Solution 7.5.1: the gripper domain, repaired.
(define (domain gripper)
  (:requirements :strips :typing)

  (:types room ball gripper)

  (:predicates
    (robby-at ?r - room)
    (ball-at ?b - ball ?r - room)
    (holding ?g - gripper ?b - ball)
    (free ?g - gripper))

  (:action move
    :parameters (?from ?to - room)
    :precondition (robby-at ?from)
    :effect (and (not (robby-at ?from)) (robby-at ?to)))

  (:action pick
    :parameters (?b - ball ?r - room ?g - gripper)
    :precondition (and (robby-at ?r) (ball-at ?b ?r) (free ?g))
    :effect (and (holding ?g ?b) (not (free ?g))
                 (not (ball-at ?b ?r))))

  (:action drop
    :parameters (?b - ball ?r - room ?g - gripper)
    :precondition (and (robby-at ?r) (holding ?g ?b))
    :effect (and (ball-at ?b ?r) (not (holding ?g ?b))
                 (free ?g))))
