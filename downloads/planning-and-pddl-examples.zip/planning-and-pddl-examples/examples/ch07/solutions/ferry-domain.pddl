;; Solution 7.7.1: a ferry carries cars across a river, two at
;; a time at most.
(define (domain ferry)
  (:requirements :strips :typing :equality
                 :negative-preconditions)

  (:types shore car count)

  (:predicates
    (ferry-at ?s - shore)
    (car-at ?c - car ?s - shore)
    (aboard ?c - car)
    (load ?n - count)               ; cars aboard now
    (next ?n ?m - count))           ; static: ?m is ?n plus one

  (:action sail
    :parameters (?from ?to - shore)
    :precondition (and (ferry-at ?from) (not (= ?from ?to)))
    :effect (and (not (ferry-at ?from)) (ferry-at ?to)))

  (:action board
    :parameters (?c - car ?s - shore ?n ?m - count)
    :precondition (and (ferry-at ?s) (car-at ?c ?s)
                       (load ?n) (next ?n ?m))
    :effect (and (not (car-at ?c ?s)) (aboard ?c)
                 (not (load ?n)) (load ?m)))

  (:action debark
    :parameters (?c - car ?s - shore ?n ?m - count)
    :precondition (and (ferry-at ?s) (aboard ?c)
                       (load ?m) (next ?n ?m))
    :effect (and (not (aboard ?c)) (car-at ?c ?s)
                 (not (load ?m)) (load ?n))))
