;; The tower c-b-a (c on top) must become a-b-c (a on top).
(define (problem blocks-coarse-p01)
  (:domain blocks-coarse)
  (:objects a b c - block)
  (:init (on-table a) (on b a) (on c b) (clear c))
  (:goal (and (on a b) (on b c))))
