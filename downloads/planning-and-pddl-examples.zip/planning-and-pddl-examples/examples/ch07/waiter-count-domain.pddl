;; The waiter with a tray that counts: how many dishes it
;; holds, not in which place each one is.
(define (domain waiter-count)
  (:requirements :strips :typing :equality
                 :negative-preconditions
                 :disjunctive-preconditions
                 :universal-preconditions)

  (:types place dish count)

  (:constants pass - place)

  (:predicates
    (waiter-at ?p - place)
    (ready ?d - dish)
    (on-tray ?d - dish)
    (tray-count ?n - count)         ; dishes on the tray now
    (next ?n ?m - count)            ; static: ?m is ?n plus one
    (served ?d - dish)
    (ordered ?d - dish ?t - place)
    (before ?a ?b - dish))

  (:action move
    :parameters (?from ?to - place)
    :precondition (and (waiter-at ?from) (not (= ?from ?to)))
    :effect (and (not (waiter-at ?from)) (waiter-at ?to)))

  ; One more dish: the count goes one step up the chain. With
  ; the tray full there is no next count, and no load.
  (:action load
    :parameters (?d - dish ?n ?m - count)
    :precondition (and (waiter-at pass) (ready ?d)
                       (tray-count ?n) (next ?n ?m))
    :effect (and (not (ready ?d)) (on-tray ?d)
                 (not (tray-count ?n)) (tray-count ?m)))

  ; One dish less: one step down.
  (:action serve
    :parameters (?d - dish ?t - place ?n ?m - count)
    :precondition (and (waiter-at ?t) (on-tray ?d)
                       (ordered ?d ?t)
                       (tray-count ?m) (next ?n ?m)
                       (forall (?e - dish)
                         (imply (before ?e ?d) (served ?e))))
    :effect (and (not (on-tray ?d)) (served ?d)
                 (not (tray-count ?m)) (tray-count ?n))))
