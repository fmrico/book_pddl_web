;; Two robots and one keycard, which hangs in the lobby. The
;; pharmacy and the ICU are restricted.
(define (problem courier-keycard-p01)
  (:domain courier-keycard)
  (:objects
    r1 r2 - robot
    lobby corridor pharmacy lab ward-a ward-b icu dock - location
    meds1 sample1 - item)
  (:init
    (connected lobby corridor) (connected corridor lobby)
    (connected lobby pharmacy) (connected pharmacy lobby)
    (connected lobby dock) (connected dock lobby)
    (connected corridor lab) (connected lab corridor)
    (connected corridor ward-a) (connected ward-a corridor)
    (connected corridor ward-b) (connected ward-b corridor)
    (connected ward-b icu) (connected icu ward-b)
    (restricted pharmacy) (restricted icu)
    (keycard-at lobby)
    (robot-at r1 dock) (free r1)
    (robot-at r2 ward-b) (free r2)
    (item-at meds1 pharmacy) (item-at sample1 icu))
  (:goal (and (item-at meds1 ward-a) (item-at sample1 lab))))
