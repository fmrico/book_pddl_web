;; Cheat test: the only keycard in two hands. No plan.
(define (problem courier-keycard-p02)
  (:domain courier-keycard)
  (:objects
    r1 r2 - robot
    lobby corridor pharmacy lab ward-a ward-b icu dock - location)
  (:init
    (connected lobby corridor) (connected corridor lobby)
    (connected lobby pharmacy) (connected pharmacy lobby)
    (connected lobby dock) (connected dock lobby)
    (connected corridor lab) (connected lab corridor)
    (connected corridor ward-a) (connected ward-a corridor)
    (connected corridor ward-b) (connected ward-b corridor)
    (connected ward-b icu) (connected icu ward-b)
    (restricted pharmacy) (restricted icu)
    (keycard-at lobby)
    (robot-at r1 dock) (free r1)
    (robot-at r2 ward-b) (free r2))
  (:goal (and (has-keycard r1) (has-keycard r2))))
