;; Trivial: one table, one dish.
(define (problem waiter-p01)
  (:domain waiter)
  (:objects t1 - place
            soup1 - dish
            s1 s2 - slot)
  (:init
    (waiter-at pass) (empty s1) (empty s2)
    (ready soup1) (ordered soup1 t1))
  (:goal (served soup1)))
