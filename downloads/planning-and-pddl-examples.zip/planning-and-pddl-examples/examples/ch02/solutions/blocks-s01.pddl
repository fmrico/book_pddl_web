;; Exercise 2.7.1: turn a tower of four blocks upside down.
(define (problem blocks-s01)
  (:domain blocks)
  (:objects a b c d)
  (:init (on-table a) (on b a) (on c b) (on d c)
         (clear d) (hand-empty))
  (:goal (and (on a b) (on b c) (on c d))))
