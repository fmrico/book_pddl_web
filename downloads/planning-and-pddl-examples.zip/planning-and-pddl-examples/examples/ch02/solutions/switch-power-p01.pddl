;; Exercise 2.4.3: the power is off and two lamps must be lit.
(define (problem switch-power-p01)
  (:domain switch-power)
  (:objects hall desk porch)
  (:init (off hall) (off desk) (off porch) (power-off))
  (:goal (and (on desk) (on porch))))
