;; Exercise 2.7.3: a ferry carries cars between ports, one car at
;; a time.
(define (domain ferry)
  (:requirements :strips)

  (:predicates
    (port ?x) (car ?x)        ; the kinds of things
    (ferry-at ?p)             ; the ferry is in port ?p
    (car-at ?c ?p)            ; car ?c waits in port ?p
    (on-board ?c)             ; car ?c is on the ferry
    (empty-ferry))            ; the ferry carries no car

  (:action sail
    :parameters (?from ?to)
    :precondition (and (port ?from) (port ?to) (ferry-at ?from))
    :effect (and (ferry-at ?to) (not (ferry-at ?from))))

  (:action board
    :parameters (?c ?p)
    :precondition (and (car ?c) (port ?p) (car-at ?c ?p)
                       (ferry-at ?p) (empty-ferry))
    :effect (and (on-board ?c)
                 (not (car-at ?c ?p)) (not (empty-ferry))))

  (:action debark
    :parameters (?c ?p)
    :precondition (and (car ?c) (port ?p) (on-board ?c)
                       (ferry-at ?p))
    :effect (and (car-at ?c ?p) (empty-ferry)
                 (not (on-board ?c)))))
