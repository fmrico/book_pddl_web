;; Exercise 2.5.1: a sample from the lab to the ICU and a meal
;; from the lobby to ward B. The robot starts in the corridor.
(define (problem courier-s01)
  (:domain courier)
  (:objects r1 sample1 meal1
            lobby corridor pharmacy lab ward-a ward-b icu dock)
  (:init
    (robot r1) (item sample1) (item meal1)
    (location lobby) (location corridor) (location pharmacy)
    (location lab) (location ward-a) (location ward-b)
    (location icu) (location dock)
    (connected lobby corridor) (connected corridor lobby)
    (connected lobby pharmacy) (connected pharmacy lobby)
    (connected lobby dock) (connected dock lobby)
    (connected corridor lab) (connected lab corridor)
    (connected corridor ward-a) (connected ward-a corridor)
    (connected corridor ward-b) (connected ward-b corridor)
    (connected ward-b icu) (connected icu ward-b)
    (robot-at r1 corridor) (free r1)
    (item-at sample1 lab) (item-at meal1 lobby))
  (:goal (and (item-at sample1 icu) (item-at meal1 ward-b))))
