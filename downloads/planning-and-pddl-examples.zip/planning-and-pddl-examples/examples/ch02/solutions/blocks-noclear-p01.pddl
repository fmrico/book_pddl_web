;; Exercise 2.7.2: two blocks directly on the same block. No
;; real tower looks like this.
(define (problem blocks-noclear-p01)
  (:domain blocks-noclear)
  (:objects a b c)
  (:init (on-table a) (on-table b) (on-table c)
         (clear a) (clear b) (clear c) (hand-empty))
  (:goal (and (on a c) (on b c))))
