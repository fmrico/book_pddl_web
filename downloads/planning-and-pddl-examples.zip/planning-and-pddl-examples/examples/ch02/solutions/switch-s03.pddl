;; Exercise 2.6.2: a goal that must have no plan, a lamp that is
;; lit and dark at the same time.
(define (problem switch-s03)
  (:domain switch)
  (:objects hall desk porch)
  (:init (on hall) (off desk) (off porch))
  (:goal (and (on desk) (off desk))))
