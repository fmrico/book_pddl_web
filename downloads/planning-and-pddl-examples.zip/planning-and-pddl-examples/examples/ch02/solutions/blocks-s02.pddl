;; Exercise 2.7.2: the same impossible goal for the right domain.
(define (problem blocks-s02)
  (:domain blocks)
  (:objects a b c)
  (:init (on-table a) (on-table b) (on-table c)
         (clear a) (clear b) (clear c) (hand-empty))
  (:goal (and (on a c) (on b c))))
