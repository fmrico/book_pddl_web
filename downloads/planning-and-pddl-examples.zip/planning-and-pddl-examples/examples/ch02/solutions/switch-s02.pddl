;; Exercise 2.4.2: the initial state says nothing about the porch
;; lamp. It is not on and it is not off: no action applies to it.
(define (problem switch-s02)
  (:domain switch)
  (:objects hall desk porch)
  (:init (on hall) (off desk))
  (:goal (on porch)))
