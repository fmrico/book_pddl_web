;; Exercise 2.5.3: r1 holds the medicines in the pharmacy; they
;; must end in the hands of r2, which waits in the lobby.
(define (problem courier-handover-p01)
  (:domain courier-handover)
  (:objects r1 r2 meds1
            lobby corridor pharmacy lab ward-a ward-b icu dock)
  (:init
    (robot r1) (robot r2) (item meds1)
    (location lobby) (location corridor) (location pharmacy)
    (location lab) (location ward-a) (location ward-b)
    (location icu) (location dock)
    (connected lobby corridor) (connected corridor lobby)
    (connected lobby pharmacy) (connected pharmacy lobby)
    (connected lobby dock) (connected dock lobby)
    (connected corridor lab) (connected lab corridor)
    (connected corridor ward-a) (connected ward-a corridor)
    (connected corridor ward-b) (connected ward-b corridor)
    (connected ward-b icu) (connected icu ward-b)
    (robot-at r1 pharmacy) (carrying r1 meds1)
    (robot-at r2 lobby) (free r2))
  (:goal (carrying r2 meds1)))
