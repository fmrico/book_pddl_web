;; Exercise 2.4.3: lamps behind a master switch. A lamp can be
;; switched on only while the power is on.
(define (domain switch-power)
  (:requirements :strips)

  (:predicates
    (on ?l) (off ?l)
    (power-on) (power-off))   ; predicates without parameters

  (:action power-up
    :parameters ()
    :precondition (power-off)
    :effect (and (power-on) (not (power-off))))

  (:action switch-on
    :parameters (?l)
    :precondition (and (off ?l) (power-on))
    :effect (and (on ?l) (not (off ?l))))

  (:action switch-off
    :parameters (?l)
    :precondition (on ?l)
    :effect (and (off ?l) (not (on ?l)))))
