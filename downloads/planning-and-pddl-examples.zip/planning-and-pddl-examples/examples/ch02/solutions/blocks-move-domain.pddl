;; Exercise 2.8.2: blocks world without a hand. Three actions move
;; a block in one step.
(define (domain blocks-move)
  (:requirements :strips)

  (:predicates
    (on ?x ?y) (on-table ?x) (clear ?x))

  (:action move                 ; from block ?from to block ?to
    :parameters (?x ?from ?to)
    :precondition (and (on ?x ?from) (clear ?x) (clear ?to))
    :effect (and (on ?x ?to) (clear ?from)
                 (not (on ?x ?from)) (not (clear ?to))))

  (:action move-to-table        ; from block ?from to the table
    :parameters (?x ?from)
    :precondition (and (on ?x ?from) (clear ?x))
    :effect (and (on-table ?x) (clear ?from)
                 (not (on ?x ?from))))

  (:action move-from-table      ; from the table to block ?to
    :parameters (?x ?to)
    :precondition (and (on-table ?x) (clear ?x) (clear ?to))
    :effect (and (on ?x ?to)
                 (not (on-table ?x)) (not (clear ?to)))))
