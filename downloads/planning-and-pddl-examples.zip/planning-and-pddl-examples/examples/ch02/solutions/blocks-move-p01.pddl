;; Exercise 2.8.2: blocks-p01 for the domain without a hand.
(define (problem blocks-move-p01)
  (:domain blocks-move)
  (:objects a b c)
  (:init (on-table a) (on-table b) (on c a)
         (clear b) (clear c))
  (:goal (and (on a b) (on b c))))
