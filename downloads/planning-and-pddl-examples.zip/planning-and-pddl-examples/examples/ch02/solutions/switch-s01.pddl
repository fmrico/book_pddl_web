;; Exercise 2.4.1: the three lamps must end lit.
(define (problem switch-s01)
  (:domain switch)
  (:objects hall desk porch)
  (:init (on hall) (off desk) (off porch))
  (:goal (and (on hall) (on desk) (on porch))))
