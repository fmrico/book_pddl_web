;; Exercise 2.7.3: two cars cross in opposite directions.
(define (problem ferry-p01)
  (:domain ferry)
  (:objects north south car1 car2)
  (:init (port north) (port south) (car car1) (car car2)
         (ferry-at north) (empty-ferry)
         (car-at car1 north) (car-at car2 south))
  (:goal (and (car-at car1 south) (car-at car2 north))))
