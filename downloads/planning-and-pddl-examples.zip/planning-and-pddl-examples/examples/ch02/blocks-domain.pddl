;; Blocks world with four actions: a hand moves blocks, one at a
;; time, between the table and the top of other blocks.
(define (domain blocks)
  (:requirements :strips)

  (:predicates
    (on ?x ?y)       ; block ?x is on block ?y
    (on-table ?x)    ; block ?x is on the table
    (clear ?x)       ; nothing is on block ?x
    (holding ?x)     ; the hand holds block ?x
    (hand-empty))    ; the hand holds nothing

  (:action pick-up              ; take a block from the table
    :parameters (?x)
    :precondition (and (on-table ?x) (clear ?x) (hand-empty))
    :effect (and (holding ?x)
                 (not (on-table ?x)) (not (clear ?x))
                 (not (hand-empty))))

  (:action put-down             ; leave the block on the table
    :parameters (?x)
    :precondition (holding ?x)
    :effect (and (on-table ?x) (clear ?x) (hand-empty)
                 (not (holding ?x))))

  (:action unstack              ; take ?x from the top of ?y
    :parameters (?x ?y)
    :precondition (and (on ?x ?y) (clear ?x) (hand-empty))
    :effect (and (holding ?x) (clear ?y)
                 (not (on ?x ?y)) (not (clear ?x))
                 (not (hand-empty))))

  (:action stack                ; leave ?x on top of ?y
    :parameters (?x ?y)
    :precondition (and (holding ?x) (clear ?y))
    :effect (and (on ?x ?y) (clear ?x) (hand-empty)
                 (not (holding ?x)) (not (clear ?y)))))
