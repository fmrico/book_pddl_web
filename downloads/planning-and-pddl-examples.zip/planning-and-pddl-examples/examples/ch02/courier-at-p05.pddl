;; The cheat test (courier-p05) for alternative C.
(define (problem courier-at-p05)
  (:domain courier-at)
  (:objects r1 meds1 meds2
            lobby corridor pharmacy lab ward-a ward-b icu dock)
  (:init
    (robot r1) (item meds1) (item meds2)
    (location lobby) (location corridor) (location pharmacy)
    (location lab) (location ward-a) (location ward-b)
    (location icu) (location dock)
    ; the map: every connection in both directions
    (connected lobby corridor) (connected corridor lobby)
    (connected lobby pharmacy) (connected pharmacy lobby)
    (connected lobby dock) (connected dock lobby)
    (connected corridor lab) (connected lab corridor)
    (connected corridor ward-a) (connected ward-a corridor)
    (connected corridor ward-b) (connected ward-b corridor)
    (connected ward-b icu) (connected icu ward-b)
    ; where things are
    (at r1 dock) (free r1)
    (at meds1 pharmacy) (at meds2 pharmacy))
  (:goal (and (at meds1 ward-a) (at meds2 ward-a))))
