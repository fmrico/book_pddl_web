;; courier-p01 for the wrong domain: medicines to ward A.
(define (problem courier-at-notypes-p01)
  (:domain courier-at-notypes)
  (:objects r1 meds1
            lobby corridor pharmacy lab ward-a ward-b icu dock)
  (:init
    (connected lobby corridor) (connected corridor lobby)
    (connected lobby pharmacy) (connected pharmacy lobby)
    (connected lobby dock) (connected dock lobby)
    (connected corridor lab) (connected lab corridor)
    (connected corridor ward-a) (connected ward-a corridor)
    (connected corridor ward-b) (connected ward-b corridor)
    (connected ward-b icu) (connected icu ward-b)
    (at r1 dock) (free r1)
    (at meds1 pharmacy))
  (:goal (at meds1 ward-a)))
