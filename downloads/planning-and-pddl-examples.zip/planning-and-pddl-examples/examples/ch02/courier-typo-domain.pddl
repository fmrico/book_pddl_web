;; WRONG ON PURPOSE: move uses a predicate that is not declared.
(define (domain courier-typo)
  (:requirements :strips)

  (:predicates
    (robot ?x)                ; ?x is a robot
    (location ?x)             ; ?x is a room of the floor
    (item ?x)                 ; ?x is something to carry
    (connected ?from ?to)     ; the robot can go from ?from to ?to
    (robot-at ?r ?l)          ; robot ?r is in ?l
    (item-at ?i ?l)           ; item ?i lies in ?l
    (carrying ?r ?i)          ; robot ?r carries item ?i
    (free ?r))                ; robot ?r carries nothing

  (:action move
    :parameters (?r ?from ?to)
    :precondition (and (robot ?r) (location ?from) (location ?to)
                       (robot-in ?r ?from) (connected ?from ?to))
    :effect (and (not (robot-at ?r ?from))
                 (robot-at ?r ?to)))

  (:action pick
    :parameters (?r ?i ?l)
    :precondition (and (robot ?r) (item ?i) (location ?l)
                       (robot-at ?r ?l) (item-at ?i ?l) (free ?r))
    :effect (and (not (item-at ?i ?l)) (not (free ?r))
                 (carrying ?r ?i)))

  (:action drop
    :parameters (?r ?i ?l)
    :precondition (and (robot ?r) (item ?i) (location ?l)
                       (robot-at ?r ?l) (carrying ?r ?i))
    :effect (and (not (carrying ?r ?i))
                 (item-at ?i ?l) (free ?r))))
