;; A goal that no state satisfies: a on b and b on a.
(define (problem blocks-p02)
  (:domain blocks)
  (:objects a b c)
  (:init (on-table a) (on-table b) (on c a)
         (clear b) (clear c) (hand-empty))
  (:goal (and (on a b) (on b a))))
