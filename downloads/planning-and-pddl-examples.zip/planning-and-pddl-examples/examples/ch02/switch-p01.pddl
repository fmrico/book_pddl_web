;; Three lamps: leave the desk lamp lit and the hall lamp dark.
(define (problem switch-p01)
  (:domain switch)
  (:objects hall desk porch)
  (:init (on hall) (off desk) (off porch))
  (:goal (and (on desk) (off hall))))
