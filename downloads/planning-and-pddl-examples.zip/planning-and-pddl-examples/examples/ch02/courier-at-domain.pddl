;; Alternative C: one predicate (at ?x ?l) for robots and items.
(define (domain courier-at)
  (:requirements :strips)

  (:predicates
    (robot ?x) (location ?x) (item ?x)
    (connected ?from ?to)
    (at ?x ?l)                ; robot or item ?x is in ?l
    (carrying ?r ?i)
    (free ?r))

  (:action move
    :parameters (?r ?from ?to)
    :precondition (and (robot ?r) (location ?from) (location ?to)
                       (at ?r ?from) (connected ?from ?to))
    :effect (and (not (at ?r ?from))
                 (at ?r ?to)))

  (:action pick
    :parameters (?r ?i ?l)
    :precondition (and (robot ?r) (item ?i) (location ?l)
                       (at ?r ?l) (at ?i ?l) (free ?r))
    :effect (and (not (at ?i ?l)) (not (free ?r))
                 (carrying ?r ?i)))

  (:action drop
    :parameters (?r ?i ?l)
    :precondition (and (robot ?r) (item ?i) (location ?l)
                       (at ?r ?l) (carrying ?r ?i))
    :effect (and (not (carrying ?r ?i))
                 (at ?i ?l) (free ?r))))
