;; WRONG ON PURPOSE: three mistakes in a problem of the courier
;; domain: an unknown object, a wrong arity, an unknown predicate.
(define (problem courier-bad-p01)
  (:domain courier)
  (:objects r1 meds1 lobby pharmacy ward-a)
  (:init
    (robot r1) (item meds1)
    (location lobby) (location pharmacy) (location ward-a)
    (connected lobby pharmacy) (connected pharmacy lobby)
    (connected lobby ward-c)
    (robot-at r1) (free r1)
    (item-in meds1 pharmacy))
  (:goal (item-at meds1 ward-a)))
