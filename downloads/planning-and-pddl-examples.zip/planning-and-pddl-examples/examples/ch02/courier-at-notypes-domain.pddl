;; WRONG ON PURPOSE: alternative C without its type predicates.
;; Nothing says that only robots move: the items walk.
(define (domain courier-at-notypes)
  (:requirements :strips)

  (:predicates
    (connected ?from ?to)
    (at ?x ?l)                ; robot or item ?x is in ?l
    (carrying ?r ?i)
    (free ?r))

  (:action move
    :parameters (?r ?from ?to)
    :precondition (and (at ?r ?from) (connected ?from ?to))
    :effect (and (not (at ?r ?from))
                 (at ?r ?to)))

  (:action pick
    :parameters (?r ?i ?l)
    :precondition (and (at ?r ?l) (at ?i ?l) (free ?r))
    :effect (and (not (at ?i ?l)) (not (free ?r))
                 (carrying ?r ?i)))

  (:action drop
    :parameters (?r ?i ?l)
    :precondition (and (at ?r ?l) (carrying ?r ?i))
    :effect (and (not (carrying ?r ?i))
                 (at ?i ?l) (free ?r))))
