;; The cheat test (courier-p05) for alternative B.
(define (problem courier-carry-p05)
  (:domain courier-carry)
  (:objects r1 meds1 meds2
            lobby corridor pharmacy lab ward-a ward-b icu dock)
  (:init
    (robot r1) (item meds1) (item meds2)
    (location lobby) (location corridor) (location pharmacy)
    (location lab) (location ward-a) (location ward-b)
    (location icu) (location dock)
    ; the map: every connection in both directions
    (connected lobby corridor) (connected corridor lobby)
    (connected lobby pharmacy) (connected pharmacy lobby)
    (connected lobby dock) (connected dock lobby)
    (connected corridor lab) (connected lab corridor)
    (connected corridor ward-a) (connected ward-a corridor)
    (connected corridor ward-b) (connected ward-b corridor)
    (connected ward-b icu) (connected icu ward-b)
    ; where things are
    (robot-at r1 dock)
    (item-at meds1 pharmacy) (item-at meds2 pharmacy))
  (:goal (and (item-at meds1 ward-a) (item-at meds2 ward-a))))
