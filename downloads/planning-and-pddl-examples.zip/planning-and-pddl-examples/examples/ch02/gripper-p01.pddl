;; Four balls go from room a to room b.
(define (problem gripper-p01)
  (:domain gripper)
  (:objects room-a room-b ball1 ball2 ball3 ball4 left right)
  (:init
    (room room-a) (room room-b)
    (ball ball1) (ball ball2) (ball ball3) (ball ball4)
    (gripper left) (gripper right)
    (at-robby room-a) (empty left) (empty right)
    (at ball1 room-a) (at ball2 room-a)
    (at ball3 room-a) (at ball4 room-a))
  (:goal (and (at ball1 room-b) (at ball2 room-b)
              (at ball3 room-b) (at ball4 room-b))))
