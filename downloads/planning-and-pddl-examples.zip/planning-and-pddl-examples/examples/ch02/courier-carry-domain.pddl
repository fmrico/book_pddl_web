;; Alternative B: no pick and no drop. The action carry moves the
;; robot and one item together, one room at a time.
(define (domain courier-carry)
  (:requirements :strips)

  (:predicates
    (robot ?x) (location ?x) (item ?x)
    (connected ?from ?to)
    (robot-at ?r ?l)
    (item-at ?i ?l))

  (:action move
    :parameters (?r ?from ?to)
    :precondition (and (robot ?r) (location ?from) (location ?to)
                       (robot-at ?r ?from) (connected ?from ?to))
    :effect (and (not (robot-at ?r ?from))
                 (robot-at ?r ?to)))

  (:action carry
    :parameters (?r ?i ?from ?to)
    :precondition (and (robot ?r) (item ?i)
                       (location ?from) (location ?to)
                       (robot-at ?r ?from) (item-at ?i ?from)
                       (connected ?from ?to))
    :effect (and (not (robot-at ?r ?from)) (robot-at ?r ?to)
                 (not (item-at ?i ?from)) (item-at ?i ?to))))
