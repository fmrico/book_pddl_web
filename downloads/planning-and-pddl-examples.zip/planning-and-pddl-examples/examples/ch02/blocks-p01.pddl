;; Three blocks: c is on a, b is alone. Build the tower a-b-c.
(define (problem blocks-p01)
  (:domain blocks)
  (:objects a b c)
  (:init (on-table a) (on-table b) (on c a)
         (clear b) (clear c) (hand-empty))
  (:goal (and (on a b) (on b c))))
