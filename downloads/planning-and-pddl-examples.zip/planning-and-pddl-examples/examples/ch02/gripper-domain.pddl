;; Gripper: a robot with two grippers carries balls between rooms.
(define (domain gripper)
  (:requirements :strips)

  (:predicates
    (room ?x) (ball ?x) (gripper ?x)   ; the kinds of things
    (at-robby ?r)                      ; the robot is in room ?r
    (at ?b ?r)                         ; ball ?b is in room ?r
    (empty ?g)                         ; gripper ?g holds nothing
    (holds ?g ?b))                     ; gripper ?g holds ball ?b

  (:action move
    :parameters (?from ?to)
    :precondition (and (room ?from) (room ?to) (at-robby ?from))
    :effect (and (at-robby ?to)
                 (not (at-robby ?from))))

  (:action pick
    :parameters (?b ?r ?g)
    :precondition (and (ball ?b) (room ?r) (gripper ?g)
                       (at ?b ?r) (at-robby ?r) (empty ?g))
    :effect (and (holds ?g ?b)
                 (not (at ?b ?r)) (not (empty ?g))))

  (:action drop
    :parameters (?b ?r ?g)
    :precondition (and (ball ?b) (room ?r) (gripper ?g)
                       (holds ?g ?b) (at-robby ?r))
    :effect (and (at ?b ?r) (empty ?g)
                 (not (holds ?g ?b)))))
