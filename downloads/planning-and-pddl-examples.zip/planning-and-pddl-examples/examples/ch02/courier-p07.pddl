;; A problem whose goal already holds in the initial state.
(define (problem courier-p07)
  (:domain courier)
  (:objects r1 meds1 lobby pharmacy)
  (:init
    (robot r1) (item meds1) (location lobby) (location pharmacy)
    (connected lobby pharmacy) (connected pharmacy lobby)
    (robot-at r1 lobby) (free r1)
    (item-at meds1 pharmacy))
  (:goal (item-at meds1 pharmacy)))
