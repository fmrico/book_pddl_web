;; The smallest domain of the book: lamps that are on or off.
(define (domain switch)
  (:requirements :strips)

  (:predicates
    (on ?l)       ; lamp ?l is lit
    (off ?l))     ; lamp ?l is dark

  (:action switch-on
    :parameters (?l)
    :precondition (off ?l)
    :effect (and (on ?l)
                 (not (off ?l))))

  (:action switch-off
    :parameters (?l)
    :precondition (on ?l)
    :effect (and (off ?l)
                 (not (on ?l)))))
