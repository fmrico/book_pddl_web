;; The road trip with a hard limit: the tolls paid may never
;; go over a budget. The limit is a precondition, not a metric.
(define (domain road-trip-budget)
  (:requirements :strips :typing :numeric-fluents)

  (:types car town)

  (:predicates
    (car-at ?c - car ?t - town)
    (road ?from ?to - town)
    (highway ?from ?to - town))

  (:functions
    (road-km ?from ?to - town)     ; length of the free road
    (highway-km ?from ?to - town)  ; length of the highway
    (toll ?from ?to - town)        ; euros to use the highway
    (km-per-liter ?c - car)
    (tolls-paid)                   ; euros
    (toll-budget)                  ; euros, the most to pay
    (fuel-used))                   ; liters

  (:action drive-road
    :parameters (?c - car ?from ?to - town)
    :precondition (and (car-at ?c ?from) (road ?from ?to))
    :effect (and
      (not (car-at ?c ?from)) (car-at ?c ?to)
      (increase (fuel-used)
                (/ (road-km ?from ?to) (km-per-liter ?c)))))

  (:action drive-highway
    :parameters (?c - car ?from ?to - town)
    :precondition (and
      (car-at ?c ?from) (highway ?from ?to)
      (<= (+ (tolls-paid) (toll ?from ?to)) (toll-budget)))
    :effect (and
      (not (car-at ?c ?from)) (car-at ?c ?to)
      (increase (tolls-paid) (toll ?from ?to))
      (increase (fuel-used)
                (/ (highway-km ?from ?to) (km-per-liter ?c))))))
