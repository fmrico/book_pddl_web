;; The courier world with two measures of a plan: the meters
;; covered and the energy used. Each problem says in its
;; metric which one counts, or how to mix them.
(define (domain courier-quality)
  (:requirements :strips :typing :numeric-fluents)

  (:types robot location item)

  (:predicates
    (connected ?from ?to - location)
    (robot-at ?r - robot ?l - location)
    (item-at ?i - item ?l - location)
    (carrying ?r - robot ?i - item)
    (free ?r - robot))

  (:functions
    (distance ?from ?to - location)  ; meters, static
    (consumption ?r - robot)         ; energy per meter, static
    (meters)                         ; covered by all the robots
    (energy-used))                   ; used by all the robots

  (:action move
    :parameters (?r - robot ?from ?to - location)
    :precondition (and (robot-at ?r ?from) (connected ?from ?to))
    :effect (and
      (not (robot-at ?r ?from)) (robot-at ?r ?to)
      (increase (meters) (distance ?from ?to))
      (increase (energy-used)
                (* (distance ?from ?to) (consumption ?r)))))

  (:action pick
    :parameters (?r - robot ?i - item ?l - location)
    :precondition (and (robot-at ?r ?l) (item-at ?i ?l) (free ?r))
    :effect (and (not (item-at ?i ?l)) (not (free ?r))
                 (carrying ?r ?i)))

  (:action drop
    :parameters (?r - robot ?i - item ?l - location)
    :precondition (and (robot-at ?r ?l) (carrying ?r ?i))
    :effect (and (not (carrying ?r ?i))
                 (item-at ?i ?l) (free ?r))))
