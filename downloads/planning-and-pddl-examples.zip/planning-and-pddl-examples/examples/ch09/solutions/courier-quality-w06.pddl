;; Exercise 9.6.1: a unit of energy weighs 0.6 meters.
;; r1 is light (1 unit of energy per meter), r2 heavy (3).
(define (problem courier-quality-w06)
  (:domain courier-quality)
  (:objects
    r1 r2 - robot
    lobby corridor pharmacy lab ward-a ward-b icu dock - location
    meds1 sample1 - item)
  (:init
    (connected lobby corridor) (connected corridor lobby)
    (connected lobby pharmacy) (connected pharmacy lobby)
    (connected lobby dock) (connected dock lobby)
    (connected corridor lab) (connected lab corridor)
    (connected corridor ward-a) (connected ward-a corridor)
    (connected corridor ward-b) (connected ward-b corridor)
    (connected ward-b icu) (connected icu ward-b)
    (= (distance lobby corridor) 10)
    (= (distance corridor lobby) 10)
    (= (distance lobby pharmacy) 6)
    (= (distance pharmacy lobby) 6)
    (= (distance lobby dock) 4) (= (distance dock lobby) 4)
    (= (distance corridor lab) 8) (= (distance lab corridor) 8)
    (= (distance corridor ward-a) 12)
    (= (distance ward-a corridor) 12)
    (= (distance corridor ward-b) 12)
    (= (distance ward-b corridor) 12)
    (= (distance ward-b icu) 5) (= (distance icu ward-b) 5)
    (= (meters) 0) (= (energy-used) 0)
    (robot-at r1 dock) (free r1) (= (consumption r1) 1)
    (robot-at r2 ward-b) (free r2) (= (consumption r2) 3)
    (item-at meds1 pharmacy) (item-at sample1 icu))
  (:goal (and (item-at meds1 ward-a) (item-at sample1 lab)))
  (:metric minimize (+ (meters) (* 0.6 (energy-used)))))
