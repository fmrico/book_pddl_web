;; Exercise 9.7.1: the road trip with the fuel as a hard limit.
;; No stations on the way: what the tank holds must be enough.
(define (domain road-trip-tank)
  (:requirements :strips :typing :numeric-fluents)

  (:types car town)

  (:predicates
    (car-at ?c - car ?t - town)
    (road ?from ?to - town)
    (highway ?from ?to - town))

  (:functions
    (road-km ?from ?to - town)     ; length of the free road
    (highway-km ?from ?to - town)  ; length of the highway
    (toll ?from ?to - town)        ; euros to use the highway
    (km-per-liter ?c - car)
    (tolls-paid)                   ; euros
    (fuel-used)                    ; liters
    (tank ?c - car))               ; liters at the start

  (:action drive-road
    :parameters (?c - car ?from ?to - town)
    :precondition (and
      (car-at ?c ?from) (road ?from ?to)
      (<= (+ (fuel-used)
             (/ (road-km ?from ?to) (km-per-liter ?c)))
          (tank ?c)))
    :effect (and
      (not (car-at ?c ?from)) (car-at ?c ?to)
      (increase (fuel-used)
                (/ (road-km ?from ?to) (km-per-liter ?c)))))

  (:action drive-highway
    :parameters (?c - car ?from ?to - town)
    :precondition (and
      (car-at ?c ?from) (highway ?from ?to)
      (<= (+ (fuel-used)
             (/ (highway-km ?from ?to) (km-per-liter ?c)))
          (tank ?c)))
    :effect (and
      (not (car-at ?c ?from)) (car-at ?c ?to)
      (increase (tolls-paid) (toll ?from ?to))
      (increase (fuel-used)
                (/ (highway-km ?from ?to) (km-per-liter ?c))))))
