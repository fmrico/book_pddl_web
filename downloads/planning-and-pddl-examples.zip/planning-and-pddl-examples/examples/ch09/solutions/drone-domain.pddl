;; Exercise 9.8.2: a drone that carries a parcel between sites.
;; Each flight uses energy; flights over crowded areas add risk.
(define (domain drone)
  (:requirements :strips :typing :numeric-fluents)

  (:types site)

  (:predicates
    (drone-at ?s - site)
    (parcel-at ?s - site)
    (holding)
    (route ?from ?to - site))

  (:functions
    (flight-energy ?from ?to - site)  ; Wh, static
    (flight-risk ?from ?to - site)    ; 0 (fields) to 5 (crowd)
    (energy)                          ; Wh used so far
    (risk))                           ; risk taken so far

  (:action fly
    :parameters (?from ?to - site)
    :precondition (and (drone-at ?from) (route ?from ?to))
    :effect (and
      (not (drone-at ?from)) (drone-at ?to)
      (increase (energy) (flight-energy ?from ?to))
      (increase (risk) (flight-risk ?from ?to))))

  (:action grab
    :parameters (?s - site)
    :precondition (and (drone-at ?s) (parcel-at ?s))
    :effect (and (not (parcel-at ?s)) (holding)))

  (:action release
    :parameters (?s - site)
    :precondition (and (drone-at ?s) (holding))
    :effect (and (not (holding)) (parcel-at ?s))))
