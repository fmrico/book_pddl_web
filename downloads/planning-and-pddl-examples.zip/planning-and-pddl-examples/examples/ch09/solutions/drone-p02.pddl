;; Exercise 9.8.2: from the depot to the clinic, over the square
;; (short, crowded) or around by the river (long, empty).
;; One unit of risk is judged as bad as 2 Wh.
(define (problem drone-p02)
  (:domain drone)
  (:objects depot square river clinic - site)
  (:init
    (drone-at depot) (parcel-at depot)
    (= (energy) 0) (= (risk) 0)
    (route depot square) (= (flight-energy depot square) 12)
    (= (flight-risk depot square) 5)
    (route square clinic) (= (flight-energy square clinic) 10)
    (= (flight-risk square clinic) 3)
    (route depot river) (= (flight-energy depot river) 25)
    (= (flight-risk depot river) 0)
    (route river clinic) (= (flight-energy river clinic) 30)
    (= (flight-risk river clinic) 1))
  (:goal (parcel-at clinic))
  (:metric minimize (+ (energy) (* 2 (risk)))))
