;; Exercise 9.5.1: a third measure of a plan, the number of
;; times that an item is handled (picked or dropped).
(define (domain courier-handlings)
  (:requirements :strips :typing :numeric-fluents)

  (:types robot location item)

  (:predicates
    (connected ?from ?to - location)
    (robot-at ?r - robot ?l - location)
    (item-at ?i - item ?l - location)
    (carrying ?r - robot ?i - item)
    (free ?r - robot))

  (:functions
    (distance ?from ?to - location)  ; meters, static
    (consumption ?r - robot)         ; energy per meter, static
    (meters)                         ; covered by all the robots
    (energy-used)                    ; used by all the robots
    (handlings))                     ; picks and drops so far

  (:action move
    :parameters (?r - robot ?from ?to - location)
    :precondition (and (robot-at ?r ?from) (connected ?from ?to))
    :effect (and
      (not (robot-at ?r ?from)) (robot-at ?r ?to)
      (increase (meters) (distance ?from ?to))
      (increase (energy-used)
                (* (distance ?from ?to) (consumption ?r)))))

  (:action pick
    :parameters (?r - robot ?i - item ?l - location)
    :precondition (and (robot-at ?r ?l) (item-at ?i ?l) (free ?r))
    :effect (and (not (item-at ?i ?l)) (not (free ?r))
                 (carrying ?r ?i)
                 (increase (handlings) 1)))

  (:action drop
    :parameters (?r - robot ?i - item ?l - location)
    :precondition (and (robot-at ?r ?l) (carrying ?r ?i))
    :effect (and (not (carrying ?r ?i))
                 (item-at ?i ?l) (free ?r)
                 (increase (handlings) 1))))
