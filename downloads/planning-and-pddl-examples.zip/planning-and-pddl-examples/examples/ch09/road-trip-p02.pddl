;; The same trip in a loaded van: 8 km per liter.
(define (problem road-trip-p02)
  (:domain road-trip)
  (:objects
    van1 - car
    alba burgo cima ermita - town)
  (:init
    ; the roads are listed in the direction of the trip only
    (road alba burgo) (= (road-km alba burgo) 90)
    (road burgo ermita) (= (road-km burgo ermita) 190)
    (road alba cima) (= (road-km alba cima) 120)
    (road cima ermita) (= (road-km cima ermita) 150)
    (highway alba burgo) (= (highway-km alba burgo) 60)
    (= (toll alba burgo) 4)
    (highway burgo ermita) (= (highway-km burgo ermita) 100)
    (= (toll burgo ermita) 6)
    (highway cima ermita) (= (highway-km cima ermita) 110)
    (= (toll cima ermita) 9)
    (car-at van1 alba) (= (km-per-liter van1) 8)
    (= (tolls-paid) 0) (= (fuel-used) 0))
  (:goal (car-at van1 ermita))
  ; money: the tolls plus the fuel at 2 euros per liter
  (:metric minimize (+ (tolls-paid) (* 2 (fuel-used)))))
