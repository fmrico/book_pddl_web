;; Cooking with prices: a dish needs one ingredient of each
;; kind of its recipe, and any ingredient of the kind will do.
;; Using an ingredient costs its price; cooking costs the gas.
(define (domain kitchen)
  (:requirements :strips :typing :action-costs)

  (:types
    ingredient dish - object
    egg fat sweetener - ingredient
    omelette cake - dish)

  (:predicates
    (in-stock ?i - ingredient)
    (with-egg ?d - dish)
    (with-fat ?d - dish)
    (with-sweetener ?d - dish)
    (ready ?d - dish))

  (:functions
    (total-cost) - number
    (price ?i - ingredient) - number)   ; static data

  (:action add-egg
    :parameters (?e - egg ?d - dish)
    :precondition (in-stock ?e)
    :effect (and (not (in-stock ?e)) (with-egg ?d)
                 (increase (total-cost) (price ?e))))

  (:action add-fat
    :parameters (?f - fat ?d - dish)
    :precondition (in-stock ?f)
    :effect (and (not (in-stock ?f)) (with-fat ?d)
                 (increase (total-cost) (price ?f))))

  (:action add-sweetener
    :parameters (?s - sweetener ?d - cake)
    :precondition (in-stock ?s)
    :effect (and (not (in-stock ?s)) (with-sweetener ?d)
                 (increase (total-cost) (price ?s))))

  (:action fry
    :parameters (?d - omelette)
    :precondition (and (with-egg ?d) (with-fat ?d))
    :effect (and (ready ?d) (increase (total-cost) 1)))

  (:action bake
    :parameters (?d - cake)
    :precondition (and (with-egg ?d) (with-fat ?d)
                       (with-sweetener ?d))
    :effect (and (ready ?d) (increase (total-cost) 2))))
