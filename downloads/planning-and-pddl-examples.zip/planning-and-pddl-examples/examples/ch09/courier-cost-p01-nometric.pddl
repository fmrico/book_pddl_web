;; The problem p01 without its metric: any plan of four
;; actions is as good as another.
(define (problem courier-cost-p01-nometric)
  (:domain courier-cost)
  (:objects
    r1 r2 - robot
    lobby corridor pharmacy lab ward-a ward-b icu dock - location
    meal1 - item)
  (:init
    (connected lobby corridor) (connected corridor lobby)
    (connected lobby pharmacy) (connected pharmacy lobby)
    (connected lobby dock) (connected dock lobby)
    (connected corridor lab) (connected lab corridor)
    (connected corridor ward-a) (connected ward-a corridor)
    (connected corridor ward-b) (connected ward-b corridor)
    (connected ward-b icu) (connected icu ward-b)
    (= (distance lobby corridor) 10)
    (= (distance corridor lobby) 10)
    (= (distance lobby pharmacy) 6)
    (= (distance pharmacy lobby) 6)
    (= (distance lobby dock) 4) (= (distance dock lobby) 4)
    (= (distance corridor lab) 8) (= (distance lab corridor) 8)
    (= (distance corridor ward-a) 12)
    (= (distance ward-a corridor) 12)
    (= (distance corridor ward-b) 12)
    (= (distance ward-b corridor) 12)
    (= (distance ward-b icu) 5) (= (distance icu ward-b) 5)
    (= (total-cost) 0)
    (robot-at r1 pharmacy) (free r1)
    (robot-at r2 corridor) (free r2)
    (item-at meal1 lobby))
  (:goal (item-at meal1 corridor)))
