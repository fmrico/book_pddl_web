;; An omelette and a cake with what the pantry has: which
;; ingredients make the cheapest meal?
(define (problem kitchen-p01)
  (:domain kitchen)
  (:objects
    om1 - omelette
    cake1 - cake
    farm-egg egg1 egg2 - egg
    butter1 oil1 oil2 - fat
    honey1 sugar1 - sweetener)
  (:init
    (= (total-cost) 0)
    (in-stock farm-egg) (= (price farm-egg) 3)
    (in-stock egg1) (= (price egg1) 1)
    (in-stock egg2) (= (price egg2) 1)
    (in-stock butter1) (= (price butter1) 4)
    (in-stock oil1) (= (price oil1) 2)
    (in-stock oil2) (= (price oil2) 2)
    (in-stock honey1) (= (price honey1) 5)
    (in-stock sugar1) (= (price sugar1) 1))
  (:goal (and (ready om1) (ready cake1)))
  (:metric minimize (total-cost)))
