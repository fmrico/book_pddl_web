#!/bin/bash
# Runs every example of the book with Kairos and checks the outcome.
#
#   tools/check_examples.sh          all chapters
#   tools/check_examples.sh ch05     one chapter
#
# Each examples/<chapter>/tests.txt has one test per line ('#' starts a comment):
#
#   solve    DOMAIN PROBLEM EXIT [kairos options...]   plan; with EXIT 0 the plan is validated
#   validate DOMAIN PROBLEM PLAN EXIT                  0 valid, 1 invalid
#   check    EXIT DOMAIN [PROBLEM]                     0 valid, 2 invalid
#
# EXIT is the exit code expected: for solve, 0 solved, 10 unsolvable, 14 no plan found,
# 2 invalid input, 11 timeout. Plans go to build/examples/<chapter>/.
# KAIROS names the planner (default: kairos in the PATH).

set -u
cd "$(dirname "$0")"
KAIROS=${KAIROS:-kairos}
command -v "$KAIROS" >/dev/null || { echo "kairos not found: set KAIROS"; exit 2; }

# Memory cap and hard timeout for every run
run() {
  if command -v systemd-run >/dev/null && systemd-run --user --scope -q true 2>/dev/null; then
    systemd-run --user --scope -q -p MemoryMax=2G timeout -s KILL 120 "$@"
  else
    timeout -s KILL 120 "$@"
  fi
}

fail=0; total=0
for tests in examples/${1:-*}/tests.txt; do
  [ -f "$tests" ] || continue
  dir=$(dirname "$tests"); ch=$(basename "$dir"); out=build/examples/$ch
  mkdir -p "$out"
  while read -r kind a b c rest; do
    case "$kind" in ''|'#'*) continue ;; esac
    total=$((total + 1))
    case "$kind" in
      solve)
        plan=$out/$(basename "$b" .pddl).plan
        rm -f "$plan" "$plan".*
        # shellcheck disable=SC2086
        run "$KAIROS" "$dir/$a" "$dir/$b" --timeout 20 --threads 1 --memory 1024 \
          --output "$plan" $rest 2>"$plan.err"
        got=$?; want=$c
        if [ "$got" = 0 ] && [ "$want" = 0 ]; then
          last=$(ls -v "$plan" "$plan".[0-9]* 2>/dev/null | tail -1)
          run "$KAIROS" validate "$dir/$a" "$dir/$b" "$last" 2>>"$plan.err" || got="invalid plan"
        fi
        what="solve $a $b" ;;
      validate)
        run "$KAIROS" validate "$dir/$a" "$dir/$b" "$dir/$c" 2>"$out/validate.err"
        got=$?; want=$rest; what="validate $a $b $c" ;;
      check)
        # shellcheck disable=SC2086
        run "$KAIROS" check "$dir/$b" ${c:+"$dir/$c"} 2>"$out/check.err"
        got=$?; want=$a; what="check $b $c" ;;
      *) got="unknown test"; want=""; what="$kind" ;;
    esac
    if [ "$got" = "$want" ]; then
      echo "ok    $ch: $what ($got)"
    else
      echo "FAIL  $ch: $what (exit $got, expected $want)"; fail=$((fail + 1))
    fi
  done < "$tests"
done
echo "$total tests, $fail failed"
[ "$fail" = 0 ]
