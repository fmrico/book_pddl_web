Planning and PDDL -- the PDDL examples of the book
Planificacion y PDDL -- los ejemplos PDDL del libro

Every domain, problem and plan printed in the book "Planning and PDDL" (Francisco Martin Rico,
Intelligent Robotics Lab, URJC), one folder per chapter (ch01 ... ch20) and appendix (apA, apB).
Each folder has a tests.txt that says what each file must give: solved, unsolvable, rejected by
the checker, or a valid or invalid plan. The same files are used by the Spanish edition.

Run one example with the Kairos planner (pip install kairos-planner):

    cd examples/ch04
    kairos courier-domain.pddl courier-p01.pddl

Check every example (Linux; KAIROS names the kairos executable if it is not in the PATH):

    ./check_examples.sh          all chapters
    ./check_examples.sh ch05     one chapter

All plans were produced and validated with Kairos 1.0.6.
Book, slides and these examples: https://fmrico.github.io/book_pddl_web/
License: CC BY-NC-ND 4.0, https://creativecommons.org/licenses/by-nc-nd/4.0/
